# MetaboMeister adds a read-only Investigate tab in section Matabo3.6.
# Investigate measures native MS1 spacing/counts once, groups adjacent readings
# by mean intensity, and computes an exact time-range median spectrum using
# sparse values and bounded temporary partitions when needed. Median time
# controls are independent, with a scan stride that skips spectra before reading.
# Display bounds use three decimals; grouping defaults to 40 m/z and 20 time
# readings and reports their typical widths in Da/seconds. Shared native
# mass coordinates are retained; differing axes use an adjustable alignment grid.
# The median uses a bounded SVG display with peak-preserving extrema and
# cached full-detail zoom, avoiding WebGL dependence in RStudio's viewer.
# The light 3D palette and combined/overlaid time-window spectra are retained.
# Investigate explicitly uses Shiny's progress functions so packages loaded
# later cannot mask numeric progress updates for raw-data actions.
# mzR reads raw MS1 scans in small batches; only a bounded grid is sent to the
# 3D plot. Cross-sections use the original scans, not that preview grid.
# Raw handles close on Clear, replacement or session end. Analysis code and
# original numbered section comments are preserved.
# Original numbered section comments are restored in their original order.
# Reorganized tasks include pointers to their current function implementations;
# the removed pseudo-file section is retained as a comment-only historical marker.
# The earlier section-comment restoration did not change executable code.
# Peak edits use a separate analysis copy. Persistent SQLite action history
# supports multi-step Undo/Redo for deletions, integration, baselines and flags;
# restoring a step updates peak tables, the RData snapshot and CSV exports.
# Original analysis folders are preserved. History excludes immutable traces.
# Empty Undo/Redo leaves saved data unchanged. Snapshot writes validate traces
# and tables before peak-data writes, so an empty session cannot overwrite EIEs.
# Saved-analysis loading runs once per connection/file change. Saved traces are
# matched by exact list name or a unique saved label, with checks for missing or
# malformed traces. RData is read once per file; SQLite edits remain authoritative.
# Metadata is shared at Results/<run>/metadata.csv for all saved analyses of
# that raw file. Existing analysis/Data/metadata.csv remains a fallback; the
# shared file takes priority. Merged results stay inside the selected analysis.
# Shared action guards catch ordinary R errors in buttons, uploads, selection
# events and background observers. They show the action/error, log details,
# release loading overlays and keep the session open. Shiny validation remains
# silent/inline; peak transactions handle edit rollback. All helpers stay here.
# PCA panel validation uses shiny::validate/shiny::need explicitly so packages
# loaded after Shiny cannot mask the display check with a different validator.
# Quality/CV stability: validate metadata, QC groups and numeric inputs before
# calculation. PCA uses base R SVD with the previous centering/unit scaling,
# avoiding the failing irlba backend. CVs remain available if PCA is unavailable.
# Modular server refactor: the new-analysis pipeline calls task functions for
# extraction, smoothing, peak processing, filtering, plotting and result exports.
# Helpers use explicit inputs/returns; GUI actions use this session's state.
# Long editing, batch-correction and drug-loading actions are named functions.
# All functions remain in server.R; use the existing matching ui.R.

# Startup workbook defaults: load both bundled Sample Files workbooks into the
# parameter tables for each session. Uploads replace the loaded data; source labels
# identify defaults/replacements. Mass/reference/parameter upload controls share
# one loader with unique input IDs. Clearing a table does not reload defaults.
# Visualization and Downstream Processing show dated-folder labels while keeping
# full paths internally. Downstream defaults to Visualization's selected analysis.
# Existing analysis selects Results/<run> and automatically opens its latest
# Results <date> [number] version. Dates and numeric rerun numbers determine the
# default; choosing an older version remains possible in Visualization.
# New analyses upload real mz5 files. Reopening uses saved filenames and never
# reads raw mz5 contents. File-name generation controls and handlers are removed.
# Run/analysis dropdowns support clearing and reselecting the same analysis.
# README HTML and Plotly startup fixes are retained. Use with matching ui.R.

# Timing instrumentation added for Initialize Run (2026-10-16).
# Records elapsed seconds per input file for reading, calibration, extraction,
# smoothing, peak processing, plotting, RData saving, SQLite writes and exports.
# Shows stage messages in the progress panel and R console, and saves
# run_timings.csv in the Results folder after each stage, including total time
# and partial timings on errors or interrupts. Optional stages are labelled
# "if enabled"; their timings include checking whether that stage is enabled.
# The timing helper is embedded below: no additional R files are required.
# This adds measurement only; the scientific processing steps are unchanged.

#PeakMeister2.0_UI was written by Erick Helmeczi and Liam Surry 
#Initialized 2024-11-12 @McMaster University
#Department of Chemistry and Chemical Biology

#Set maximum file upload size. 
#Set maximum file upload size to 150 GB
options(shiny.maxRequestSize = 150 * 1024^3)
options(shiny.timeout = 600)  #Set timeout to 600 seconds (10 minutes)

#Initialize server
server <- function(input, output, session){ 

  # UI action names used in error messages; event expressions are not evaluated here.
  action_label <- function(event) {
    labels <- c(
      addMassRow = "Add Mass", deletemassrow = "Delete mass row", clearMassList = "Clear Mass List",
      addRefMassRow = "Add Reference Mass", deleterefmassrow = "Delete reference mass row",
      clearRefMassList = "Clear Reference Mass List", addParamRow = "Add Parameter",
      deleteparamrow = "Delete parameter row", clearparam = "Clear Parameters",
      saveProjectInfo = "Save Project Info", clearproject = "Clear Project Info",
      addMTIrow = "Add manual MTI row", deleteMTIrow = "Delete MTI row", clearMTIlist = "Clear MTI List",
      massList = "Load Mass List workbook", massListReference = "Load Reference Mass List workbook",
      massListParameters = "Load Parameters workbook", userMTI = "Load migration-index workbook",
      analysis_mode = "Change analysis mode", mz5Files = "Upload mz5 files",
      existing_run = "Open existing analysis", clearFiles = "Clear Files", initialize = "Initialize Run",
      results_folder = "Select saved analysis", confirm_migration = "Build saved-results database",
      file_selector = "Select visualization file", draw_mode = "Change plot interaction mode",
      plot_table_rows_selected = "Select plot", delete_peak = "Delete Selected Peaks",
      deletemiddlepeaks = "Delete Middle Peaks", deleteallpeaks = "Delete all peaks",
      undo = "Undo peak edit", redo = "Redo peak edit", other_options = "Other plot options",
      regenerateplots = "Regenerate Changed Plots", rebuild_peak_areas_modal = "Rebuild Peak Area CSV",
      rebuild_mig_times_modal = "Rebuild Peak Migration Time CSV",
      manual_integrate = "Manually Adjust Integration", confirm_peak_number = "Confirm peak integration",
      adjust_indiv_baseline = "Adjust Individual Baseline",
      baseline_peak_number_adjustment = "Confirm individual baseline adjustment",
      adjust_all_baselines = "Adjust All Baselines",
      confirm_adjust_all_baselines = "Confirm all baseline adjustments",
      interferences = "Mark Peak Interference", results_folder2 = "Select downstream results",
      load_migration_area = "Load Migration and Peak Area Data", normalize = "Normalize Data",
      confirm_normalize = "Normalize Data", missing_data = "Replace Missing Data",
      connect_metadata = "Connect Metadata to Results", create_control_chart = "Create Control Chart",
      compute_cv = "Calculate CVs", load_batchcorr_packages = "Initialize Batch Correction Packages",
      batch_corr = "Perform Batch Correction", generate_matrix = "Generate Data Matrix for MetaboAnalyst",
      adherence_results = "Load adherence results", drug_databases = "Load Drug Databases",
      confirm_parse_drugbank = "Parse DrugBank"
    )
    if (is.call(event) && identical(event[[1]], as.name("$")) &&
        identical(event[[2]], as.name("input"))) {
      id <- as.character(event[[3]])
      if (id %in% names(labels)) return(unname(labels[id]))
    }
    if (is.call(event) && identical(event[[1]], as.name("plot_event_data"))) return("Plot interaction")
    "Update selected analysis"
  }

  report_action_error <- function(action, error) {
    detail <- conditionMessage(error)
    message(sprintf("[PeakMeister] %s failed: %s", action, detail))
    if (!is.null(conditionCall(error))) {
      message("[PeakMeister] Call: ", paste(deparse(conditionCall(error)), collapse = " "))
    }
    # A failed plotting/database action must not leave a full-screen waiter blocking the app.
    tryCatch({
      if (requireNamespace("waiter", quietly = TRUE)) waiter::waiter_hide()
    }, error = function(e) message("[PeakMeister] Loading overlay cleanup: ", conditionMessage(e)))
    tryCatch(shiny::showNotification(paste0(action, " failed: ", detail),
      type = "error", duration = NULL, closeButton = TRUE, id = "peakmeister-action-error",
      session = session),
      error = function(e) message("[PeakMeister] Could not display notification: ", conditionMessage(e)))
    invisible(NULL)
  }

  # The expression executes in its caller's environment, preserving local state
  # and the existing handler's early returns. Cleanup is only run after failure.
  with_action_error <- function(expr, action, on_error = NULL) {
    tryCatch(force(expr), error = function(e) {
      if (inherits(e, "shiny.silent.error")) stop(e)
      if (!is.null(on_error)) tryCatch(on_error(), error = function(cleanup_error) {
        message("[PeakMeister] Action cleanup: ", conditionMessage(cleanup_error))
      })
      report_action_error(action, e)
      invisible(NULL)
    })
  }

  # Quote once and forward Shiny options unchanged (priority, ignoreInit, once, etc.).
  observe_action <- function(eventExpr, handlerExpr, ...,
                             event.env = parent.frame(), event.quoted = FALSE,
                             handler.env = parent.frame(), handler.quoted = FALSE,
                             label = NULL, on_error = NULL) {
    event <- if (event.quoted) eventExpr else substitute(eventExpr)
    handler <- if (handler.quoted) handlerExpr else substitute(handlerExpr)
    guarded <- substitute(with_action_error(HANDLER, ACTION, on_error = CLEANUP),
      list(HANDLER = handler, ACTION = action_label(event), CLEANUP = on_error))
    shiny::observeEvent(event, guarded, event.env = event.env, event.quoted = TRUE,
      handler.env = handler.env, handler.quoted = TRUE, label = label, ...)
  }

  observe_updates <- function(x, ..., env = parent.frame(), quoted = FALSE, label = NULL) {
    expression <- if (quoted) x else substitute(x)
    guarded <- substitute(with_action_error(EXPR, "Refresh interface"), list(EXPR = expression))
    shiny::observe(guarded, env = env, quoted = TRUE, label = label, ...)
  }
  
  #Initialize plotly_data as an empty reactive variable
  plotly_data <- reactiveVal(list())
  
  #Reactive values to store marker positions
  line_positions <- reactiveValues(red = 2, blue = 4)
  
  ####1. About tab####
  # Keep the standalone HTML document intact instead of parsing it as Markdown.
  readme_dir <- tempfile("peakmeister-readme-")
  dir.create(readme_dir)
  readme_resource <- basename(readme_dir)
  session$onSessionEnded(function() {
    if (readme_resource %in% names(shiny::resourcePaths())) {
      shiny::removeResourcePath(readme_resource)
    }
    unlink(readme_dir, recursive = TRUE)
  })
  #Functions for "About" tab page -> reading information from markdown files
  output$disclaimerContent <- renderUI({
    includeMarkdown("docs/DISCLAIMER.md")
  })
  output$readmeContent <- renderUI({
    rmarkdown::render("docs/README.md", output_file = "README.html",
      output_dir = readme_dir, output_options = list(self_contained = TRUE),
      quiet = TRUE, envir = new.env(parent = globalenv()))
    shiny::addResourcePath(readme_resource, readme_dir)
    tags$iframe(src = paste0(readme_resource, "/README.html"),
      title = "PeakMeister README", style = "width:100%; height:75vh; border:0;")
  })
  output$updatesContent <- renderUI({
    includeMarkdown("docs/UPDATES.md")
  })
  output$licenseContent <- renderUI({
    includeMarkdown("docs/LICENSE.md")
  })
####2. User supplied inputs tab####
 #Load data from user supplied Excel file using sheet names
  
  #####2.1 Initialize environment#####
  #Initialize reactive values as empty
  #Reactive values for mass list
  massData <- reactiveVal(data.frame(
    name = character(),
    mz = numeric(),
    extraction.window.ppm = numeric(),
    interference = character(),
    interference.comigration.threshold.seconds = numeric(),
    minimim.peak.width.seconds = numeric(),
    migration.window.seconds = numeric(),
    peak.space.tolerance.percent = numeric(),
    snr.threshold = numeric(),
    smoothing.kernel = character(),
    smoothing.strength = numeric(),
    stringsAsFactors = FALSE
  ))
  
  #Reactive values for reference mass list
  refMassListData <- reactiveVal(data.frame(
    name = character(),
    mz = numeric(),
    extraction.window.ppm = numeric(),
    class = character(),
    min.mt.min = numeric(),
    max.mt.min = numeric(),
    peak.fwhm.tolerance.multiplier = numeric(),
    peak.space.tolerance.percent = numeric(),
    smoothing.kernel = character(),
    smoothing.strength = numeric(),
    stringsAsFactors = FALSE
  ))
  
  #reactive values for paramaters
  parametersData <- reactiveVal(data.frame(
    number.of.injections = numeric(),
    ref.mass.one = numeric(),
    ref.mass.two = numeric(),
    ref.mass.window.ppm = numeric(),
    ref.mass.minimum.counts = numeric(),
    apply.mass.calibration = character(),
    apply.smoothing = character(),
    plot.format = character(),
    Manual.Indexes = character(),
    stringsAsFactors = FALSE
  ))
  #May need to include peak migfration times into these? Not sure???
  
  #Reactive values for manual MTI list
  userMTI <- reactiveVal(data.frame(
    name = character(),
    left_is = character(),
    right_is = character(),
    description = character(),
    stringsAsFactors = FALSE
  ))
  
  mass_workbook_source <- reactiveVal("No workbook loaded.")
  migration_workbook_source <- reactiveVal("No workbook loaded.")

  load_mass_workbook <- function(path, source) {
    # Read every sheet before replacing any table, so failed uploads keep prior data.
    masses <- as.data.frame(readxl::read_excel(path, sheet = "Mass List"))
    references <- as.data.frame(readxl::read_excel(path, sheet = "Reference Mass List"))
    parameters <- as.data.frame(readxl::read_excel(path, sheet = "Parameters"))
    massData(masses)
    refMassListData(references)
    parametersData(parameters)
    mass_workbook_source(paste("Source workbook:", source))
  }

  load_migration_workbook <- function(path, source) {
    indexes <- as.data.frame(readxl::read_excel(path, sheet = "User Supplied Migration Indexes"))
    userMTI(indexes)
    migration_workbook_source(paste("Source workbook:", source))
  }

  load_default_workbook <- function(path, loader, source_status) {
    tryCatch(loader(path, paste0(path, " (default)")), error = function(e) {
      source_status(paste("Default workbook unavailable:", path))
      showNotification(paste("Could not load default workbook:", path, conditionMessage(e)),
        type = "warning", duration = 10)
    })
  }
  load_default_workbook(file.path("Sample Files", "Mass List and Parameters.xlsx"),
    load_mass_workbook, mass_workbook_source)
  load_default_workbook(file.path("Sample Files", "User Supplied Migration Indexes.xlsx"),
    load_migration_workbook, migration_workbook_source)

  output$mass_workbook_source <- renderText(mass_workbook_source())
  output$reference_workbook_source <- renderText(mass_workbook_source())
  output$parameters_workbook_source <- renderText(mass_workbook_source())
  output$migration_workbook_source <- renderText(migration_workbook_source())

  #Render editable tables
  output$massListData <- DT::renderDataTable({ massData() }, editable = TRUE)
  output$refMassListData <- DT::renderDataTable({ refMassListData() }, editable = TRUE)
  output$parametersData <- DT::renderDataTable({ parametersData() }, editable = TRUE)
  output$userMTIdata <- DT::renderDataTable({userMTIdata()}, editable = TRUE)
  
  #####2.2 Data Table Input#####
  # Each subtab can replace the same three-sheet workbook.
  replace_mass_workbook <- function(file) {
    req(file)
    tryCatch(load_mass_workbook(file$datapath, file$name), error = function(e) {
      showNotification(paste("Could not load workbook:", conditionMessage(e)), type = "error")
    })
  }
  observe_action(input$massList, replace_mass_workbook(input$massList))
  observe_action(input$massListReference, replace_mass_workbook(input$massListReference))
  observe_action(input$massListParameters, replace_mass_workbook(input$massListParameters))

  #####2.3 Manual Mass List Input#####
  #Add a row in the table 
  observe_action(input$addMassRow, {
    newRow <- data.frame(
      #Input values for table 
      name = input$name,
      mz = input$mz,
      extraction.window.ppm = input$extraction.window.ppm,
      interference = input$interference,
      interference.comigration.threshold.seconds = input$interference.comigration.threshold.seconds,
      minimim.peak.width.seconds = input$minimim.peak.width.seconds,
      migration.window.seconds = input$migration.window.seconds,
      peak.space.tolerance.percent = input$peak.space.tolerance.percent,
      snr.threshold = input$snr.threshold,
      smoothing.kernel = input$smoothing.kernel,
      smoothing.strength = input$smoothing.strength,
      peak.1.mt = input$peak.1.mt,
      peak.2.mt = input$peak.2.mt,
      peak.3.mt = input$peak.3.mt,
      peak.4.mt = input$peak.4.mt,
      peak.5.mt = input$peak.5.mt,
      peak.6.mt = input$peak.6.mt,
      peak.7.mt = input$peak.7.mt,
      peak.8.mt = input$peak.8.mt,
      peak.9.mt = input$peak.9.mt,
      peak.10.mt = input$peak.10.mt,
      peak.11.mt = input$peak.11.mt,
      peak.12.mt = input$peak.12.mt,
      peak.13.mt = input$peak.13.mt,
      stringsAsFactors = FALSE
    )
    #Update dataset 
    updatedData <- rbind(massData(), newRow)
    massData(updatedData)
    
    #Clear inputs after adding allowing users to enter new ones
    updateTextInput(session, "name", value = "")
    updateNumericInput(session, "mz", value = 0)
    updateNumericInput(session, "extraction.window.ppm", value = 0)
    updateTextInput(session, "interference", value = "")
    updateNumericInput(session, "interference.comigration.threshold.seconds", value = 0)
    updateNumericInput(session, "minimim.peak.width.seconds", value = 0)
    updateNumericInput(session, "migration.window.seconds", value = 0)
    updateNumericInput(session, "peak.space.tolerance.percent", value = 0)
    updateNumericInput(session, "snr.threshold", value = 0)
    updateTextInput(session, "smoothing.kernel", value = "")
    updateNumericInput(session, "smoothing.strength", value = 0)
    
    #Clear peaks inputs
    lapply(1:13, function(i) {
      updateNumericInput(session, paste0("peak.", i, ".mt"), value = 0)
    })
  })
  
  #Delete selected row in Mass List server function 
  observe_action(input$deletemassrow, {
    selected_row <- input$massListData_rows_selected
    if (length(selected_row) > 0) {
      updatedData <- massData()[-selected_row, ]
      massData(updatedData)} else {
      showNotification("Please select a row to delete.", type = "error")}})
  #Server function for clearing data table
  observe_action(input$clearMassList, {
    massData(data.frame())
    showNotification("Table has been reset.", type = "message")})
  #Data table output
  output$massListData <- DT::renderDataTable({
    DT::datatable(massData(), selection = 'single', editable = TRUE)})
  
  #####2.4 Manual Reference Mass Input#####
  observe_action(input$addRefMassRow, {
    newRow <- data.frame(
      #Input values for table
      name = input$name,
      mz = input$mz,
      extraction.window.ppm = input$extraction.window.ppm,
      class = input$class,
      min.mt.min = input$min.mt.min,
      max.mt.min = input$max.mt.min,
      peak.fwhm.tolerance.multiplier = input$peak.fwhm.tolerance.multiplier,
      peak.space.tolerance.percent = input$peak.space.tolerance.percent,
      smoothing.kernel = input$smoothing.kernel,
      smoothing.strength = input$smoothing.strength,
      peak.1.mt = input$peak.1.mt,
      peak.2.mt = input$peak.2.mt,
      peak.3.mt = input$peak.3.mt,
      peak.4.mt = input$peak.4.mt,
      peak.5.mt = input$peak.5.mt,
      peak.6.mt = input$peak.6.mt,
      peak.7.mt = input$peak.7.mt,
      peak.8.mt = input$peak.8.mt,
      peak.9.mt = input$peak.9.mt,
      peak.10.mt = input$peak.10.mt,
      peak.11.mt = input$peak.11.mt,
      peak.12.mt = input$peak.12.mt,
      peak.13.mt = input$peak.13.mt,
      stringsAsFactors = FALSE
    )
    #Update dataset
    updatedData <- rbind(refMassListData(), newRow)
    refMassListData(updatedData)
    
    #Clear inputs after adding
    updateTextInput(session, "name", value = "")
    updateNumericInput(session, "mz", value = 0)
    updateNumericInput(session, "extraction.window.ppm", value = 0)
    updateTextInput(session, "class", value = "")
    updateNumericInput(session, "min.mt.min", value = 0)
    updateNumericInput(session, "max.mt.min", value = 0)
    updateNumericInput(session, "peak.fwhm.tolerance.multiplier", value = 0)
    updateNumericInput(session, "peak.space.tolerance.percent", value = 0)
    updateTextInput(session, "smoothing.kernel", value = "")
    updateNumericInput(session, "smoothing.strength", value = 0)
    
    #Clear peaks inputs
    lapply(1:13, function(i) {
      updateNumericInput(session, paste0("ref.peak.", i, ".mt"), value = 0)
    })
  })
  
  #Deleting a selected row in reference mass list
  observe_action(input$deleterefmassrow, {
    selected_row <- input$refMassListData_rows_selected
    if (length(selected_row) > 0) {
      updatedData <- refMassListData()[-selected_row, ]
      refMassListData(updatedData)
    } else {
      showNotification("Please select a row to delete.", type = "error")}})
  #Clearing the reference mass list
  observe_action(input$clearRefMassList, {
    refMassListData(data.frame())
    showNotification("Reference Mass List has been cleared.", type = "message")})
  #Data table output
  output$refMassListData <- DT::renderDataTable({
    DT::datatable(refMassListData(), selection = 'single', editable = TRUE)})
  
  #####2.5 Manual Parameters Input#####
  observe_action(input$addParamRow, {
    newRow <- data.frame(
      #Input values for table
      number.of.injections = input$number.of.injections,
      ref.mass.one = input$ref.mass.one,
      ref.mass.two = input$ref.mass.two,
      ref.mass.window.ppm = input$ref.mass.window.ppm,
      ref.mass.minimum.counts = input$ref.mass.minimum.counts,
      apply.mass.calibration = input$apply.mass.calibration,
      apply.smoothing = input$apply.smoothing,
      plot.format = input$plot.format,
      Manual.Indexes = input$Manual.Indexes,
      stringsAsFactors = FALSE
    )
    #Update dataset
    updatedData <- rbind(parametersData(), newRow)
    parametersData(updatedData)
    
    #Clear input values when user adds more paramaters 
    updateNumericInput(session, "number.of.injections", value = 0)
    updateNumericInput(session, "ref.mass.one", value = 0)
    updateNumericInput(session, "ref.mass.two", value = 0)
    updateNumericInput(session, "ref.mass.window.ppm", value = 0)
    updateNumericInput(session, "ref.mass.minimum.counts", value = 0)
    updateCheckboxInput(session, "apply.mass.calibration", value = FALSE)
    updateCheckboxInput(session, "apply.smoothing", value = FALSE)
    updateTextInput(session, "plot.format", value = "")
    updateCheckboxInput(session, "Manual.Indexes", value = FALSE)
  })
  
  #Deleting selected parameter row
  observe_action(input$deleteparamrow, {
    selected_row <- input$parametersData_rows_selected
    if (length(selected_row) > 0) {
      updatedData <- parametersData()[-selected_row, ]
      parametersData(updatedData)
    } else {
      showNotification("Please select a row to delete.", type = "error")}})
  #Clearing the parameters list
  observe_action(input$clearparam, {
    parametersData(data.frame())
    showNotification("Parameters List has been cleared.", type = "message")})
  #Data table output
  output$parametersData <- DT::renderDataTable({
    DT::datatable(parametersData(), selection = 'single', editable = TRUE)})
  
  #####2.6 Project information input#####
  #The idea behind this tab is to automatically generate a metadata file on the project information that is included with the analysis. Makes environment more reproducible and traceable. Additionally, project information will be saved into the generated results folder so results are easier to identify/organize on your computer. 
  
  #Generate reactive values for information
  projectName <- reactiveVal("")
  projectDescription <- reactiveVal("")
  projectSupervisor <- reactiveVal("")
  projectContact <- reactiveVal("")
  #Update reactive values when someone clicks Save project info)
  observe_action(input$saveProjectInfo, {
    projectName(input$projectName)  
    projectDescription(input$projectDescription)  
    projectSupervisor(input$projectSupervisor)  
    projectContact(input$projectContact)  
  })
  #Display output information from reactive variables
  output$currentProjectInfo <- renderText({
    paste("Project Name:", projectName(), 
          "\nProject Description:", projectDescription(), 
          "\nProject Supervisor:", projectSupervisor(), 
          "\nProject Contact:", projectContact())
  })
  
  #Server function for clearing project information when button is clicked
  observe_action(input$clearproject, {
    #Clear the input fields
    updateTextInput(session, "projectName", value = "")
    updateTextInput(session, "projectDescription", value = "")
    updateTextInput(session, "projectSupervisor", value = "")
    updateTextInput(session, "projectContact", value = "")
    #Reset reactive values
    projectName("")
    projectDescription("")
    projectSupervisor("")
    projectContact("")
    showNotification("Project information has been cleared.", type = "message")
  })
  
  #####2.7 Manual MTI input#####
  
  # Uploaded migration indexes replace the startup workbook.
  observe_action(input$userMTI, {
    req(input$userMTI)
    tryCatch(load_migration_workbook(input$userMTI$datapath, input$userMTI$name), error = function(e) {
      showNotification(paste("Could not load migration indexes:", conditionMessage(e)), type = "error")
    })
  })

  #Manual Data Input
  observe_action(input$addMTIrow, {
    newRow <- data.frame(
      name = input$name,
      left_is = input$left_is,
      right_is = input$right_is,
      description = input$description,
      `1` = input$peak.1.mt,
      `2` = input$peak.2.mt,
      `3` = input$peak.3.mt,
      `4` = input$peak.4.mt,
      `5` = input$peak.5.mt,
      `6` = input$peak.6.mt,
      `7` = input$peak.7.mt,
      `8` = input$peak.8.mt,
      `9` = input$peak.9.mt,
      `10` = input$peak.10.mt,
      `11` = input$peak.11.mt,
      `12` = input$peak.12.mt,
      `13` = input$peak.13.mt,
      stringsAsFactors = FALSE
    )
    #Update dataset
    updatedData <- rbind(userMTI(), newRow)
    userMTI(updatedData)
    
    #Clear inputs values when user adds more things
    updateTextInput(session, "name", value = "")
    updateTextInput(session, "left_is", value = "")
    updateTextInput(session, "right_is", value = "")
    updateTextInput(session, "description", value = "")
    lapply(1:13, function(i) {
      updateNumericInput(session, paste0("ref.peak.", i, ".mt"), value = 0)
    })
  })
  
  #Delete selected MTI row
  observe_action(input$deleteMTIrow, {
    selected_row <- input$userMTIdata_rows_selected
    if (length(selected_row) > 0) {
      updatedData <- userMTI()[-selected_row, ]
      userMTI(updatedData)
    } else {
      showNotification("Please select a row to delete.", type = "error")
    }
  })
  
  #Clearing the MTI list
  observe_action(input$clearMTIlist, {
    userMTI(data.frame())
    showNotification("User Supplied Migration Indexes list has been cleared.", type = "message")
  })
  
  #Data table output for userMTI information
  output$userMTIdata <- DT::renderDataTable({
    DT::datatable(userMTI(), selection = 'single', editable = TRUE)})
  
  
  #####2.8 Save input information#####
  #Function for saving datatable once user has uploaded their values
  output$downloadData <- downloadHandler(
    #Save data datble as excel sheet with name "Mass List and Parameters"
    #Will add function to save it with a project identifier as well for organizational purposes
    filename = function() {
      paste("Mass List and Parameters", Sys.Date(), ".xlsx", sep = "")
    },
    content = function(file) {
      with_action_error({
        #Create a list of data frames for each sheet
        write_xlsx(list(
          Parameters = parametersData(),
          'Mass List' = massData(),
          'Reference Mass List' = refMassListData()
        ), path = file)
      }, "Save Table (.xlsx)", on_error = function() unlink(file))
    }
  )
  
  ####3. Engine tab####
  #####3.1 mz5 file upload#####
  ######3.1.1 Upload real .mz5 files######
  empty_mz5_files <- function() {
    data.frame(FileName = character(), FilePath = character(), Source = character(),
               stringsAsFactors = FALSE)
  }
  uploadedmz5 <- reactiveVal(empty_mz5_files())
  selected_saved_run <- reactiveVal(character())
  analysis_mode <- reactive({
    if (identical(input$analysis_mode, "existing")) "existing" else "new"
  })

  reset_raw_selection <- function() shinyjs::reset("mz5Files")
  request_new_analysis <- function() shinyjs::click("initialize")

  # Reject ambiguous names before constructing paths or matching stored records.
  valid_mz5_names <- function(names) {
    is.character(names) && length(names) > 0L && !anyNA(names) &&
      all(nzchar(names)) && !anyDuplicated(names) &&
      all(grepl("\\.mz5$", names, ignore.case = TRUE)) &&
      !any(grepl("[/\\\\]", names))
  }

  mz5_result_parent <- function(filename) {
    if (length(filename) != 1L || !valid_mz5_names(filename)) stop("Select a valid mz5 filename.")
    stem <- sub("\\.mz5$", "", filename, ignore.case = TRUE)
    if (stem %in% c("", ".", "..")) stop("The mz5 filename must have a nonempty name.")
    file.path(".", "Results", stem)
  }

  # Inspect directory names and saved-data presence only; never read raw mz5 data.
  saved_run_files <- function(run) {
    if (length(run) != 1L || is.na(run) || !nzchar(run) ||
        run %in% c(".", "..") || grepl("[/\\\\]", run)) return(character())
    parent <- mz5_result_parent(paste0(run, ".mz5"))
    if (!dir.exists(parent)) return(character())
    versions <- list.dirs(parent, full.names = TRUE, recursive = FALSE)
    versions <- versions[grepl("^Results", basename(versions))]
    files <- unlist(lapply(versions, function(folder) {
      data_dirs <- list.dirs(file.path(folder, "Data"), full.names = TRUE, recursive = FALSE)
      names <- basename(data_dirs)
      keep <- grepl("\\.mz5$", names, ignore.case = TRUE) &
        sub("\\.mz5$", "", names, ignore.case = TRUE) == run &
        file.exists(file.path(data_dirs, "plot_list_data.RData"))
      names[keep]
    }), use.names = FALSE)
    sort(unique(as.character(files)))
  }

  list_saved_runs <- function() {
    if (!dir.exists("./Results")) return(character())
    runs <- basename(list.dirs("./Results", full.names = TRUE, recursive = FALSE))
    sort(runs[vapply(runs, function(run) length(saved_run_files(run)) > 0L, logical(1))])
  }
  saved_runs <- reactivePoll(5000, session,
    checkFunc = list_saved_runs, valueFunc = list_saved_runs)

  observe_updates({
    runs <- saved_runs()
    current <- isolate(selected_saved_run())
    updateSelectInput(session, "existing_run",
      choices = c("Select a run" = "", stats::setNames(runs, runs)),
      selected = if (analysis_mode() == "existing" && length(current) == 1L &&
                     current %in% runs) current else "")
  })

  create_results_folder <- function(filename) {
    parent <- mz5_result_parent(filename)
    if (!dir.exists(parent) && !dir.create(parent, recursive = TRUE)) {
      stop("Could not create the results parent folder: ", parent)
    }
    count <- 1L
    repeat {
      leaf <- paste("Results", Sys.Date(), if (count == 1L) "" else count)
      folder <- file.path(parent, trimws(leaf))
      if (!file.exists(folder) && dir.create(folder, showWarnings = FALSE)) return(folder)
      if (!file.exists(folder)) stop("Could not create the Results folder: ", folder)
      count <- count + 1L
    }
  }

  prepare_results_folder <- function(folder, masses, references, parameters, indexes = NULL) {
    for (name in c("Plots", "Data")) dir.create(file.path(folder, name), showWarnings = FALSE)
    if (parameters$plot.format == "Metabolite") {
      for (name in c(references$name, masses$name)) {
        dir.create(file.path(folder, "Plots", name), showWarnings = FALSE)
      }
    }
    write_xlsx(list(Parameters = parameters, 'Mass List' = masses,
                    'Reference Mass List' = references),
               path = file.path(folder, paste0("Mass List and Parameters", Sys.Date(), ".xlsx")))
    if (!is.null(indexes)) {
      write.csv(indexes, file.path(folder, "Migration Index Summary.csv"), row.names = FALSE)
    }
  }

  # Only inspect saved result files/database; never open raw files.
  check_saved_analysis <- function(folder, names) {
    if (!valid_mz5_names(names)) stop("Select valid, distinct mz5 filenames.")
    if (length(folder) != 1L || is.na(folder) ||
        !folder %in% list_results_folders(names[1], selected_saved_run())) {
      stop("Select an available saved Results folder.")
    }
    paths <- file.path(folder, "Data", names, "plot_list_data.RData")
    missing <- names[!file.exists(paths)]
    if (length(missing)) {
      stop("No saved results found for: ", paste(missing, collapse = ", "),
           ". Select the matching saved analysis.")
    }
    # If no database exists, the existing migration dialog will offer to build it.
    if (db_exists(folder)) {
      con <- DBI::dbConnect(RSQLite::SQLite(), get_db_path(folder), flags = RSQLite::SQLITE_RO)
      on.exit(DBI::dbDisconnect(con), add = TRUE)
      stored <- DBI::dbGetQuery(con, "SELECT DISTINCT file_name FROM plot_axis_data")$file_name
      missing <- names[!sub("\\.mz5$", "", names) %in% stored]
      if (length(missing)) stop("Files are missing from the saved database: ", paste(missing, collapse = ", "))
    }
    invisible(TRUE)
  }

  output$fileTable <- DT::renderDataTable({
    DT::datatable(uploadedmz5()[, "FileName", drop = FALSE], options = list(pageLength = 5))
  })
  output$show_visualization_file_selector <- renderText({
    if (analysis_mode() == "new") "true" else "false"
  })
  outputOptions(output, "show_visualization_file_selector", suspendWhenHidden = FALSE)

  observe_action(input$analysis_mode, {
    uploadedmz5(empty_mz5_files())
    selected_saved_run(character())
    updateSelectInput(session, "existing_run", selected = "")
    reset_raw_selection()
  }, ignoreInit = TRUE, priority = 100)

  observe_action(input$mz5Files, {
    if (analysis_mode() != "new") return()
    req(input$mz5Files)
    newFiles <- data.frame(FileName = input$mz5Files$name,
                           FilePath = input$mz5Files$datapath, Source = "upload",
                           stringsAsFactors = FALSE)
    # Preserve uploads from this mode only; saved selections cannot become raw inputs.
    current <- uploadedmz5()
    current <- current[current$Source == "upload", , drop = FALSE]
    uploadedmz5(rbind(current, newFiles))
    if (isTRUE(input$autorun)) request_new_analysis()
  })

  observe_action(input$existing_run, {
    if (analysis_mode() != "existing") return()
    run <- input$existing_run
    uploadedmz5(empty_mz5_files())
    selected_saved_run(character())
    if (is.null(run) || identical(run, "")) return()
    if (length(run) != 1L || is.na(run) || !run %in% list_saved_runs()) {
      showNotification("Select an available run folder under Results.", type = "error")
      return()
    }
    names <- saved_run_files(run)
    if (!valid_mz5_names(names)) {
      showNotification("No matching saved data found in this run folder.", type = "error")
      return()
    }
    selected_saved_run(run)
    uploadedmz5(data.frame(FileName = names, FilePath = NA_character_,
                           Source = "saved_run", stringsAsFactors = FALSE))
  }, ignoreNULL = FALSE)

  observe_action(input$clearFiles, {
    uploadedmz5(empty_mz5_files())
    selected_saved_run(character())
    updateSelectInput(session, "existing_run", selected = "")
    reset_raw_selection()
  })

  ######3.1.2 Upload file names and generate pseudo .mz5 files######
  # Removed: filename-table inputs and pseudo .mz5 generation were deleted.
  # Engine -> Open existing analysis now selects a saved run folder instead.
  # This historical marker does not restore the removed controls or handlers.

  #####3.2 Initialze Run Button - Main Content######
  # Reorganized: Initialize Run is split into the task functions below,
  # run_new_analysis() and process_mz5_file(). The input$initialize observer
  # follows those helpers, after section 3.12.3. This marker retains its
  # original position before migration-index calculation.
  # Processing task functions:
  # Data functions receive ordinary tables/objects and return their results.
  # GUI action functions below retain this session's reactive state.

  new_run_timer <- function(path, notify = function(stage, file) NULL) {
    rows <- data.frame(file = character(), stage = character(), status = character(),
                       started_at = character(), elapsed_seconds = numeric(),
                       detail = character(), stringsAsFactors = FALSE)
    run_start <- proc.time()[["elapsed"]]
    run_wall <- format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
    active <- NULL
    finished <- FALSE
    persist <- function() write.csv(rows, path, row.names = FALSE)
    record <- function(file, stage, status, wall, elapsed, detail = "") {
      rows[nrow(rows) + 1L, ] <<- list(file, stage, status, wall, elapsed, detail)
      persist()
      message(sprintf("[Timing] %s | %s | %s | %.3f seconds", file, stage, status, elapsed))
    }
    close_stage <- function(status = "completed", detail = "") {
      if (!is.null(active)) {
        record(active$file, active$stage, status, active$wall,
               proc.time()[["elapsed"]] - active$start, detail)
        active <<- NULL
      }
    }
    persist()
    list(
      stage = function(stage, file = "") {
        stopifnot(!finished)
        close_stage()
        active <<- list(file = file, stage = stage,
                        wall = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
                        start = proc.time()[["elapsed"]])
        message(sprintf("[Timing] Starting %s%s", stage,
                        if (nzchar(file)) paste0(" | ", file) else ""))
        notify(stage, file)
      },
      end_stage = function() close_stage(),
      finish = function(status = "completed", detail = "") {
        if (finished) return(invisible(NULL))
        close_stage(status, detail)
        record("", "TOTAL RUN (includes all stages)", status, run_wall,
               proc.time()[["elapsed"]] - run_start, detail)
        finished <<- TRUE
        invisible(rows)
      }
    )
  }

  # Validate names and calculate migration indexes, including manual overrides.
  prepare_analysis_parameters <- function(mass_df, is_df, parameters_df, user_mti_df) {
    #Create a vector of metabolite and internal standard names
    name_vec <- c(is_df$name, mass_df$name)

    #Check for duplicate metabolite and internal standard names
    if (sum(duplicated(name_vec)) > 0) {
      stop("Mass List and Parameters contain duplicated metabolite or internal standard names.")
    }

    #Determine the number of metabolites and internal standards
    num_of_metabolites <- nrow(mass_df)
    num_of_is <- nrow(is_df)

    #Get the number of injections
    num_of_injections <- parameters_df$number.of.injections[1]


    #####3.3 Migration Index Calculation#####

    #Summarize user supplied migration time data
    metabolites_mt_df <- data.frame(name = mass_df$name, mass_df[, c((ncol(mass_df) - num_of_injections + 1):ncol(mass_df))])
    is_mt_df <- subset(is_df, is_df$class == "Reference")
    is_mt_df <- data.frame(name = is_mt_df$name, is_mt_df[, c((ncol(is_mt_df) - num_of_injections + 1):ncol(is_mt_df))])

    #Determine IS on the left
    is_left_vec <- character(num_of_metabolites)

    for (m in 1:nrow(metabolites_mt_df)) {
      is_temp <- (metabolites_mt_df[m, 2] - (is_mt_df[, 2]))
      is_temp <- set_names(is_temp, is_mt_df$name)
      is_temp <- is_temp[which(sign(is_temp) == 1 | sign(is_temp) == 0)] %>%
        which.min() %>%
        names()

      if (length(is_temp) == 0) {
        is_temp <- "none"
      }

      is_left_vec[m] <- is_temp
    }

    #Determine IS on the right
    is_right_vec <- character(num_of_metabolites)

    for (m in 1:nrow(metabolites_mt_df)) {
      is_temp <- (metabolites_mt_df[m, 2] - (is_mt_df[, 2]))
      is_temp <- set_names(is_temp, is_mt_df$name)
      is_temp <- is_temp[which(sign(is_temp) == -1 | sign(is_temp) == 0)] %>%
        which.max() %>%
        names()

      if (length(is_temp) == 0) {
        is_temp <- "none"
      }

      is_right_vec[m] <- is_temp
    }

    #Compute migration index
    mi_df <- matrix(NA, ncol = (num_of_injections + 1), nrow = nrow(metabolites_mt_df)) %>%
      as.data.frame()
    mi_df[, 1] <- metabolites_mt_df$name

    summary_vec <- character(nrow(metabolites_mt_df))

    for (m in 1:nrow(metabolites_mt_df)) {
      for (i in 2:(num_of_injections + 1)) {
        left <- is_left_vec[m]
        right <- is_right_vec[m]

        if (left == "none") {
          mi_df[m, i] <- metabolites_mt_df[m, i] / is_mt_df[which(is_mt_df$name == right), i]
          summary_vec[m] <- right
          next
        }

        if (right == "none") {
          mi_df[m, i] <- metabolites_mt_df[m, i] / is_mt_df[which(is_mt_df$name == left), i]
          summary_vec[m] <- left
          next
        }

        if (metabolites_mt_df[m, 2] / is_mt_df[which(is_mt_df$name == left), 2] < 1.01) {
          mi_df[m, i] <- metabolites_mt_df[m, i] / is_mt_df[which(is_mt_df$name == left), i]
          summary_vec[m] <- left
          is_right_vec[m] <- "none"
          next
        }

        if (metabolites_mt_df[m, 2] / is_mt_df[which(is_mt_df$name == right), 2] > 0.99) {
          mi_df[m, i] <- metabolites_mt_df[m, i] / is_mt_df[which(is_mt_df$name == right), i]
          summary_vec[m] <- right
          is_left_vec[m] <- "none"
          next
        }

        mi_df[m, i] <- (metabolites_mt_df[m, i] - is_mt_df[which(is_mt_df$name == left), i]) / 
          (is_mt_df[which(is_mt_df$name == right), i] - is_mt_df[which(is_mt_df$name == left), i])
        summary_vec[m] <- "mi"
      }
    }

    #Store results in one data frame
    colnames(mi_df)[2:ncol(mi_df)] <- c(1:num_of_injections)
    mi_df <- cbind(name = mass_df$name,
                   left_is = is_left_vec,
                   right_is = is_right_vec,
                   description = summary_vec,
                   mi_df[2:ncol(mi_df)])
    #####3.4 User Supplied MTIs#####

    user_mti_df <- user_mti_df

    if (parameters_df$Manual.Indexes == "Yes") {

        names <- unique(c(user_mti_df$name, user_mti_df$left_is, user_mti_df$right_is, user_mti_df$description))

        if (all(names %in% c(name_vec, "mi", "none")) == FALSE) {
          stop("Names detected in User Supplied Migration Indexes.csv not found in Mass List and Parameters.")
        }

        if (ncol(user_mti_df) != (4 + num_of_injections)) {
          stop(paste("Make sure User Supplied Migration Indexes.csv contains migration time indexes for all", num_of_injections, "injections."))
        }

        for (i in 1:nrow(user_mti_df)) {
          row <- which(mi_df$name == user_mti_df$name[i])

          if (length(row) == 0) {
            stop(paste("Metabolite", user_mti_df$name[i], "from User Supplied Migration Indexes.csv is not in Mass List and Parameters."))
          }

          mi_df[row, 2:ncol(mi_df)] <- user_mti_df[i, 2:ncol(user_mti_df)]
        }
      }

    list(mass_df = mass_df, is_df = is_df, parameters_df = parameters_df,
         name_vec = name_vec, num_of_metabolites = num_of_metabolites,
         num_of_is = num_of_is, num_of_injections = num_of_injections, mi_df = mi_df)
  }

  #####3.5 Data File Analysis#####
  # Reorganized: raw-file reading starts here; process_mz5_file() below
  # coordinates the per-file folders, temporary copy and subsequent tasks.
  # Read one copied raw file and unlock its spectra for calibration.
  read_mz5_data <- function(temporary_file, total_steps) {
    #Read copied data file and update progress bar
    incProgress(1/total_steps, detail = paste("Reading Data File"))
    print("Reading Data File")

    run_data <- readMSData(
      file = temporary_file,
      pdata = NULL,
      msLevel = 1,
      verbose = isMSnbaseVerbose(),
      centroided. = FALSE,
      smoothed. = FALSE,
      cache. = 0,
      mode = "inMemory"
    )

    print("File Reading Complete")

    #Unlock "assayData" environment
    env_binding_unlock(run_data@assayData)

    run_data
  }

  #####3.6 Perform Mass Calibration#####
  # Apply optional lock-mass calibration; return the run object.
  calibrate_masses <- function(run_data, parameters_df, total_steps) {
    calibration_response <- parameters_df$apply.mass.calibration

    #Confirm response is "Yes" or "No". Otherwise, produce an error.

    if(calibration_response != "Yes" & calibration_response != "No"){
      stop(paste("apply.mass.calibration parameter should be 'Yes' or 'No'. ", "'", calibration_response, "' is not an acceptable input.", sep = ""))
    }

    #Check if mass calibration should be applied

    if (calibration_response == "No"){

      print("Skipping Mass Calibration")

    }

    if (calibration_response == "Yes"){

      #Update progress bar
      incProgress(1/total_steps, detail = paste("Performing Mass Calibration"))

      print("Performing Mass Calibration")

      run_data <- local({

        #Define mass window and minimum lock mass counts

        mass_window <- parameters_df$ref.mass.window.ppm[1]

        minimum_counts <- parameters_df$ref.mass.minimum.counts[1]

        #Define a function to calculate 1. experimental m/z of lock masses, 2. the corresponding mass error, and 3. the index of the lock mass
        #The lock mass value is currently the most intense point in the mass window plus an adjustment to better predict the lock mass value.

        calibration_parameters <- function(spectrum, lock_mass, minimum_counts, mass_window) {

          lock_mass_range <- c((lock_mass - lock_mass * mass_window / 1000000),
                               (lock_mass + lock_mass * mass_window / 1000000))

          #Find the index of the most intense point in the lock mass window

          max_intensity_index <- spectrum %>%
            filter(mz >= lock_mass_range[1] & mz <= lock_mass_range[2]) %>%
            slice_max(intensity) %>%
            pull(index)

          if(length(max_intensity_index) == 1){
            if(spectrum$intensity[max_intensity_index] > minimum_counts){

              #Create a data frame with all four points
              line_points <- data.frame("mz" = c(spectrum$mz[(max_intensity_index - 2):(max_intensity_index - 1)],
                                                 spectrum$mz[(max_intensity_index + 1):(max_intensity_index + 2)]),
                                        "intensity" = c(spectrum$intensity[(max_intensity_index - 2):(max_intensity_index - 1)],
                                                        spectrum$intensity[(max_intensity_index + 1):(max_intensity_index + 2)]))

              #Create a model for all four points
              model_left <- lm(formula = intensity ~ mz, data = line_points[c(1,2),])
              model_right <- lm(formula = intensity ~ mz, data = line_points[c(3,4),])

              #Get the coefficients for both models
              coefficients_left <- c(model_left$coefficients["mz"], model_left$coefficients["(Intercept)"])
              coefficients_right <- c(model_right$coefficients["mz"], model_right$coefficients["(Intercept)"])

              #Calculate the slope and intercept
              slope <- coefficients_left[1] - coefficients_right[1]
              intercept <- coefficients_right[2] - coefficients_left[2]

              #Solve for the experimental_mz
              experimental_mz <- solve(slope, intercept)

              experimental_mass_diff <- lock_mass - experimental_mz

              return(c(experimental_mz, experimental_mass_diff, max_intensity_index))
            }
          }
        }

        #Loop through each spectrum to build a model and perform the mass calibration

        for (s in 1:end(rtime(run_data))[1]){

          spectrum_name <- ls(run_data@assayData)[s]

          spectrum <- data.frame(index = 1:length(run_data@assayData[[spectrum_name]]@mz),
                                 mz = run_data@assayData[[spectrum_name]]@mz,
                                 intensity = run_data@assayData[[spectrum_name]]@intensity)

          #Lower lock mass

          lock_mass <- parameters_df$ref.mass.one[1]

          cal_para_1 <- calibration_parameters(spectrum = spectrum,
                                               lock_mass = lock_mass,
                                               minimum_counts = minimum_counts,
                                               mass_window = mass_window)

          #Upper lock mass

          lock_mass <- parameters_df$ref.mass.two[1]

          cal_para_2 <- calibration_parameters(spectrum = spectrum,
                                               lock_mass = lock_mass,
                                               minimum_counts = minimum_counts,
                                               mass_window = mass_window)

          if (is.null(cal_para_1) | is.null(cal_para_2)){
            next
          }

          ######3.6.1 Develop correction model######

          model_data <- data.frame("x" = c(cal_para_1[1], cal_para_2[1]),
                                   "y" = c(cal_para_1[2], cal_para_2[2]))

          model <- lm(y ~ x, model_data)

          ######3.6.2 Apply correction model######

          correction_vector <- c(model[["coefficients"]][["x"]] * spectrum$mz) + model[["coefficients"]][["(Intercept)"]]

          correction_vector[1:cal_para_1[3]] <- cal_para_1[2]

          correction_vector[cal_para_2[3]:length(correction_vector)] <- cal_para_2[2]

          run_data@assayData[[spectrum_name]]@mz <- run_data@assayData[[spectrum_name]]@mz + correction_vector

        }

        run_data

      })
    }


    print("Mass Calibration Complete")

    run_data
  }

  #####Matabo3.6 Investigate raw m/z, time and intensity#####
  # This independent, read-only workflow uses an Engine upload or its own raw
  # upload. It never starts analysis, calibrates spectra or writes result files.
  investigate_raw <- reactiveVal(NULL)
  investigate_grid <- reactiveVal(NULL)
  investigate_trace <- reactiveVal(NULL)
  investigate_median <- reactiveVal(NULL)
  investigate_median_view <- reactiveVal(NULL)
  investigate_median_time_custom <- reactiveVal(FALSE)

  ######Matabo3.6.1 Raw-file metadata, validation and bounded scan reading######
  investigate_range <- function(values, label, nonnegative = TRUE) {
    if (!is.numeric(values) || length(values) != 2L || any(!is.finite(values)) ||
        values[1] >= values[2] || (nonnegative && values[1] < 0)) {
      stop(label, " must have finite minimum and maximum values, with minimum < maximum.", call. = FALSE)
    }
    as.numeric(values)
  }

  investigate_window_limits <- function(center, window, unit) {
    if (length(center) != 1L || !is.finite(center) || center <= 0 ||
        length(window) != 1L || !is.finite(window) || window <= 0 ||
        length(unit) != 1L || !unit %in% c("ppm", "Da")) {
      stop("Choose a positive centre m/z and a positive ± window in ppm or Da.", call. = FALSE)
    }
    half_width <- if (unit == "ppm") center * window / 1e6 else window
    investigate_range(c(max(0, center - half_width), center + half_width), "m/z window")
  }

  investigate_clean_scan <- function(scan) {
    if (is.null(scan) || !length(scan)) return(matrix(numeric(), ncol = 2L))
    scan <- as.matrix(scan)
    if (!is.numeric(scan) || ncol(scan) < 2L) stop("The raw reader returned an invalid spectrum.")
    scan <- scan[, 1:2, drop = FALSE]
    scan[is.finite(scan[, 1]) & scan[, 1] >= 0 & is.finite(scan[, 2]), , drop = FALSE]
  }

  investigate_open_raw <- function(path, name,
      opener = function(path) mzR::openMSfile(path, backend = "pwiz"),
      read_header = mzR::header, read_peaks = mzR::peaks,
      closer = function(handle) mzR::close(handle), progress = function(fraction) NULL) {
    if (length(path) != 1L || is.na(path) || !file.exists(path)) stop("Select an available raw .mz5 file.")
    if (length(name) != 1L || !grepl("\\.mz5$", name, ignore.case = TRUE)) stop("Select a real .mz5 file.")
    handle <- opener(path)
    ready <- FALSE
    on.exit(if (!ready) try(closer(handle), silent = TRUE), add = TRUE)
    header <- as.data.frame(read_header(handle))
    if (!all(c("msLevel", "retentionTime") %in% names(header))) stop("The file has no usable scan metadata.")
    scans <- which(header$msLevel == 1L & is.finite(header$retentionTime) & header$retentionTime >= 0)
    if (!length(scans)) stop("The file contains no MS1 scans with valid acquisition times.")
    scans <- scans[order(header$retentionTime[scans])]
    times <- header$retentionTime[scans] / 60
    time_range <- range(times)
    if (diff(time_range) == 0) time_range <- c(max(0, time_range[1] - 1/120), time_range[2] + 1/120)
    raw <- list(handle = handle, name = name, scans = scans, times = times,
      time_range = time_range, read_peaks = read_peaks, closer = closer)
    raw <- investigate_measure_sampling(raw, progress)
    ready <- TRUE
    raw
  }

  investigate_close_raw <- function(raw) {
    if (!is.null(raw)) tryCatch(raw$closer(raw$handle), error = function(e) {
      message("[MetaboMeister] Closing Investigate file: ", conditionMessage(e))
    })
    invisible(NULL)
  }

  investigate_walk_scans <- function(raw, time_range, callback, progress = function(fraction) NULL) {
    selected <- which(raw$times >= time_range[1] & raw$times <= time_range[2])
    if (!length(selected)) stop("No MS1 scans fall inside the selected time range.", call. = FALSE)
    # Eight spectra at a time bounds memory independently of total file size.
    for (start in seq.int(1L, length(selected), by = 8L)) {
      batch <- selected[start:min(start + 7L, length(selected))]
      spectra <- raw$read_peaks(raw$handle, scans = raw$scans[batch])
      if (is.matrix(spectra) || is.data.frame(spectra)) spectra <- list(spectra)
      if (!is.list(spectra) || length(spectra) != length(batch)) stop("The raw reader returned an incomplete scan batch.")
      for (j in seq_along(batch)) callback(investigate_clean_scan(spectra[[j]]), batch[j])
      progress(min(start + 7L, length(selected)) / length(selected))
    }
    selected
  }

  ######Matabo3.6.2 Native sampling, grouped means and exact median spectrum######
  # Measure actual within-spectrum sampling once; do not confuse it with an
  # instrument's resolving power or with the adjustable display/alignment grid.
  investigate_measure_sampling <- function(raw, progress = function(fraction) NULL) {
    reference <- NULL; shared <- TRUE; counts <- integer(length(raw$scans))
    minimum <- Inf; observed <- c(Inf, -Inf); points <- 0
    investigate_walk_scans(raw, raw$time_range, function(scan, index) {
      axis <- unname(scan[, 1])
      if (is.unsorted(axis, strictly = TRUE)) axis <- sort(unique(axis))
      counts[index] <<- length(axis); points <<- points + nrow(scan)
      if (!length(axis)) return()
      observed <<- c(min(observed[1], axis[1]), max(observed[2], tail(axis, 1)))
      if (length(axis) > 1L) minimum <<- min(minimum, diff(axis))
      if (is.null(reference)) reference <<- axis else if (!identical(axis, reference)) shared <<- FALSE
    }, progress)
    if (!length(reference)) stop("No finite MS1 measurements were found in this file.")
    delta_time <- diff(sort(unique(raw$times)))
    raw$sampling <- list(shared = shared, mz_axis = if (shared) reference else NULL,
      mz_count_range = range(counts), mz_delta = if (is.finite(minimum)) minimum else NA_real_,
      time_count = length(raw$times), time_unique = length(unique(raw$times)),
      time_delta = if (length(delta_time)) min(delta_time) else NA_real_, points = points)
    raw$mz_range <- observed
    if (diff(raw$mz_range) == 0) raw$mz_range <- c(max(0, observed[1] - 0.01), observed[2] + 0.01)
    raw$range_source <- "all valid MS1 measurements"
    # Limit the default alignment axis to about 200,000 positions; this is an
    # adjustable analysis grid, never reported as measured sampling spacing.
    raw$alignment_width <- max(if (is.finite(minimum)) minimum else 0,
      diff(raw$mz_range)/200000)
    raw
  }

  investigate_mass_axis <- function(raw, mz_range, alignment_width = NULL) {
    mz_range <- investigate_range(mz_range, "m/z range")
    if (isTRUE(raw$sampling$shared)) {
      axis <- raw$sampling$mz_axis
      axis <- axis[axis >= mz_range[1] & axis <= mz_range[2]]
      if (!length(axis)) stop("No recorded m/z positions fall inside the selected range.")
      return(list(mz = axis, native = TRUE, mz_range = mz_range, width = NULL))
    }
    width <- if (is.null(alignment_width)) raw$alignment_width else alignment_width
    if (!is.numeric(width) || length(width) != 1L || !is.finite(width) || width <= 0) {
      stop("Enter a positive alignment-grid width in Da.")
    }
    count <- ceiling(diff(mz_range)/width - 16 * .Machine$double.eps * max(1, diff(mz_range)/width))
    if (count < 1 || count > 2e6) stop("The alignment grid must have 1–2,000,000 positions. Increase its width or narrow the m/z range.")
    edges <- mz_range[1] + seq.int(0, count) * width
    edges[length(edges)] <- mz_range[2]
    list(mz = head(edges, -1) + diff(edges)/2, edges = edges,
      native = FALSE, mz_range = mz_range, width = width)
  }

  # One intensity per scan and mass position. Duplicate native points or
  # multiple points in an alignment cell are averaged before time aggregation.
  investigate_align_scan <- function(scan, axis) {
    scan <- scan[scan[, 1] >= axis$mz_range[1] & scan[, 1] <= axis$mz_range[2], , drop = FALSE]
    if (!nrow(scan)) return(list(columns = integer(), values = numeric(), points = 0L))
    columns <- if (axis$native) match(scan[, 1], axis$mz) else
      findInterval(scan[, 1], axis$edges, all.inside = TRUE)
    if (anyNA(columns)) stop("The file's m/z coordinates changed after loading. Reload the raw file.")
    if (!anyDuplicated(columns)) return(list(columns = columns, values = scan[, 2], points = nrow(scan)))
    totals <- rowsum(cbind(value = scan[, 2], count = 1), columns, reorder = FALSE)
    list(columns = as.integer(rownames(totals)), values = totals[, 1]/totals[, 2], points = nrow(scan))
  }

  investigate_group_factors <- function(mz_group, time_group) {
    valid <- function(value) is.numeric(value) && length(value) == 1L &&
      is.finite(value) && value >= 1 && value <= 1e9 && value == floor(value)
    if (!valid(mz_group) || !valid(time_group)) stop("Enter positive whole grouping factors (1–1,000,000,000).")
    c(mz = as.integer(mz_group), time = as.integer(time_group))
  }

  investigate_group_plan <- function(raw, mz_range, time_range, mz_group, time_group, alignment_width = NULL) {
    factors <- investigate_group_factors(mz_group, time_group)
    time_range <- investigate_range(time_range, "3D time range")
    selected <- which(raw$times >= time_range[1] & raw$times <= time_range[2])
    if (!length(selected)) stop("No MS1 scans fall inside the selected time range.")
    axis <- investigate_mass_axis(raw, mz_range, alignment_width)
    counts <- c(mz = ceiling(length(axis$mz)/factors[1]), time = ceiling(length(selected)/factors[2]))
    if (prod(counts) > 1e6) stop("The preview is too large (over 1,000,000 cells). Increase grouping factors or narrow the ranges.")
    list(axis = axis, selected = selected, factors = factors, counts = counts, time_range = time_range)
  }

  investigate_build_grid <- function(raw, mz_range, time_range, mz_group = 1L,
                                      time_group = 1L, alignment_width = NULL,
                                      progress = function(fraction) NULL) {
    plan <- investigate_group_plan(raw, mz_range, time_range, mz_group, time_group, alignment_width)
    axis <- plan$axis; selected <- plan$selected
    mass_groups <- (seq_along(axis$mz) - 1L) %/% plan$factors[1] + 1L
    time_groups <- (seq_along(selected) - 1L) %/% plan$factors[2] + 1L
    mass_counts <- tabulate(mass_groups); time_counts <- tabulate(time_groups)
    z <- matrix(0, nrow = length(time_counts), ncol = length(mass_counts)); points <- 0
    row_for_scan <- integer(length(raw$scans)); row_for_scan[selected] <- time_groups
    investigate_walk_scans(raw, time_range, function(scan, index) {
      aligned <- investigate_align_scan(scan, axis)
      points <<- points + aligned$points
      if (!length(aligned$columns)) return()
      sums <- rowsum(aligned$values, mass_groups[aligned$columns], reorder = FALSE)
      columns <- as.integer(rownames(sums)); row <- row_for_scan[index]
      z[row, columns] <<- z[row, columns] + sums[, 1]
    }, progress)
    if (!points) stop("No m/z measurements fall inside the selected 3D ranges.")
    # Include implicit zeros at missing positions and empty scans. Last groups
    # use their actual size rather than the requested (possibly larger) factor.
    z <- z / outer(time_counts, mass_counts)
    list(mz = as.numeric(rowsum(axis$mz, mass_groups, reorder = FALSE))/mass_counts,
      time = as.numeric(rowsum(raw$times[selected], time_groups, reorder = FALSE))/time_counts,
      z = z, mz_range = axis$mz_range, time_range = time_range,
      factors = plan$factors, mass_positions = length(axis$mz), native = axis$native,
      alignment_width = axis$width, points = points, scans = length(selected))
  }

  # Exact median with implicit zeros. Partial sorting selects only the central
  # ranks; it does not sort every time point at each mass position.
  investigate_zero_median <- function(values, scans) {
    values <- values[values != 0]
    if (!length(values)) return(0)
    zeros <- scans - length(values); negative <- sum(values < 0)
    ranks <- c((scans + 1) %/% 2, (scans + 2) %/% 2)
    in_zero <- ranks > negative & ranks <= negative + zeros
    needed <- ranks[!in_zero] - ifelse(ranks[!in_zero] > negative, zeros, 0)
    answer <- numeric(2)
    if (length(needed)) answer[!in_zero] <- sort(values, partial = unique(needed))[needed]
    mean(answer)
  }

  investigate_median_spectrum <- function(raw, mz_range, time_range, alignment_width = NULL,
                                          progress = function(fraction) NULL, cache_bytes = 32 * 1024^2,
                                          scan_step = 1L) {
    time_range <- investigate_range(time_range, "Median time range")
    if (!is.numeric(scan_step) || length(scan_step) != 1L || !is.finite(scan_step) ||
        scan_step < 1 || scan_step > 1e9 || scan_step != floor(scan_step)) {
      stop("Enter a positive whole median scan factor (1–1,000,000,000).")
    }
    eligible <- which(raw$times >= time_range[1] & raw$times <= time_range[2])
    if (!length(eligible)) stop("No MS1 scans fall inside the selected time range.")
    selected <- eligible[seq.int(1L, length(eligible), by = scan_step)]
    # Subset metadata BEFORE both streaming passes, so skipped spectra are never
    # read, aligned or added as implicit zeros to the sampled median.
    view <- raw; view$scans <- raw$scans[selected]; view$times <- raw$times[selected]
    axis <- investigate_mass_axis(raw, mz_range, alignment_width)
    n <- length(selected); mass_count <- length(axis$mz)
    positive <- negative <- numeric(mass_count); values <- numeric(mass_count)
    cache <- vector("list", length(view$scans)); cached <- TRUE; entries <- 0
    # Budget includes vector/list/grouping overhead, not only the 12-byte pair.
    capacity <- max(1, floor(cache_bytes/64))
    investigate_walk_scans(view, time_range, function(scan, index) {
      aligned <- investigate_align_scan(scan, axis)
      keep <- aligned$values != 0; columns <- aligned$columns[keep]; intensity <- aligned$values[keep]
      pos <- columns[intensity > 0]; neg <- columns[intensity < 0]
      positive[pos] <<- positive[pos] + 1; negative[neg] <<- negative[neg] + 1
      entries <<- entries + length(columns)
      if (cached && entries > capacity) { cache <<- NULL; cached <<- FALSE }
      if (cached) cache[[index]] <<- list(columns = columns, values = intensity)
    }, function(fraction) progress(fraction * 0.6))
    candidates <- which(positive > floor((n - 1)/2) | negative > floor((n - 1)/2))
    finish <- function(method) {
      progress(1)
      list(data = data.frame(mz = axis$mz, intensity = values), mz_range = axis$mz_range,
        time_range = time_range, scans = n, available_scans = length(eligible),
        scan_step = scan_step, selected_scans = view$scans, selected_times = view$times, native = axis$native,
        alignment_width = axis$width, method = method)
    }
    # A signal seen in fewer than half the scans has an exact zero median.
    # Most transient peaks need neither a dense matrix nor any sorting.
    if (!length(candidates)) return(finish("implicit-zero counts"))
    calculate <- function(columns, intensity) {
      groups <- split(intensity, columns)
      for (name in names(groups)) values[as.integer(name)] <<- investigate_zero_median(groups[[name]], n)
    }
    if (cached) {
      chunks <- lapply(cache, function(chunk) {
        keep <- chunk$columns %in% candidates
        list(columns = chunk$columns[keep], values = chunk$values[keep])
      })
      calculate(unlist(lapply(chunks, `[[`, "columns"), use.names = FALSE),
        unlist(lapply(chunks, `[[`, "values"), use.names = FALSE))
      return(finish("cached sparse values"))
    }
    # Large data: one extra raw pass, then bounded temporary partitions. Never
    # allocate scans × masses or reread the raw file once per mass. The files
    # contain candidate nonzero values only and are removed even on failure.
    counts <- positive[candidates] + negative[candidates]
    target <- max(capacity, max(counts))
    partition <- ceiling(cumsum(counts)/target)
    partition <- match(partition, unique(partition))
    file_for_mass <- integer(mass_count); file_for_mass[candidates] <- partition
    sizes <- as.numeric(rowsum(counts, partition, reorder = FALSE))
    directory <- tempfile("metabomeister-median-"); dir.create(directory)
    paths <- file.path(directory, paste0(seq_along(sizes), ".bin"))
    connections <- list(); recent <- integer()
    on.exit({
      for (connection in connections) try(close(connection), silent = TRUE)
      unlink(directory, recursive = TRUE)
    }, add = TRUE)
    connection_for <- function(id) {
      name <- as.character(id)
      if (is.null(connections[[name]])) {
        if (length(connections) >= 16L) {
          old <- as.character(recent[1]); close(connections[[old]])
          connections[[old]] <<- NULL; recent <<- recent[-1]
        }
        connections[[name]] <<- file(paths[id], "ab")
      }
      recent <<- c(recent[recent != id], id)
      connections[[name]]
    }
    investigate_walk_scans(view, time_range, function(scan, index) {
      aligned <- investigate_align_scan(scan, axis)
      keep <- aligned$values != 0 & file_for_mass[aligned$columns] > 0L
      columns <- aligned$columns[keep]; intensity <- aligned$values[keep]
      groups <- split(seq_along(columns), file_for_mass[columns])
      for (name in names(groups)) {
        take <- groups[[name]]; connection <- connection_for(as.integer(name))
        writeBin(as.integer(length(take)), connection)
        writeBin(as.integer(columns[take]), connection); writeBin(as.double(intensity[take]), connection)
      }
    }, function(fraction) progress(0.6 + fraction * 0.3))
    for (connection in connections) close(connection)
    connections <- list()
    for (id in seq_along(paths)) {
      columns <- integer(sizes[id]); intensity <- numeric(sizes[id]); position <- 0L
      connection <- file(paths[id], "rb")
      tryCatch({
        repeat {
          size <- readBin(connection, integer(), n = 1L)
          if (!length(size)) break
          take <- seq.int(position + 1L, position + size)
          columns[take] <- readBin(connection, integer(), n = size)
          intensity[take] <- readBin(connection, double(), n = size)
          position <- position + size
        }
      }, finally = close(connection))
      if (position != sizes[id]) stop("The median cache is incomplete. Please retry.")
      calculate(columns, intensity)
      unlink(paths[id]); progress(0.9 + 0.1 * id/length(paths))
    }
    finish("partitioned sparse values")
  }

  # Matabo3.6.2 Render a bounded SVG overview independently of WebGL. The
  # full computed median remains cached; zoom selects its original points.
  investigate_median_view_data <- function(spectrum, view = NULL, max_points = 4000L) {
    if (is.null(view)) view <- list(x = spectrum$mz_range, y = spectrum$intensity_range)
    x_range <- investigate_range(view$x, "Median view m/z range", nonnegative = FALSE)
    y_range <- investigate_range(view$y, "Median view intensity range", nonnegative = FALSE)
    x <- spectrum$data$mz; y <- spectrum$data$intensity; n <- length(x)
    if (!is.numeric(max_points) || length(max_points) != 1L || !is.finite(max_points) ||
        max_points < 4 || max_points != floor(max_points)) stop("Median display point limit must be a whole number of at least 4.")
    # findInterval works on the sorted native/aligned mass axis. Include a
    # neighbour at each boundary to keep lines continuous while panning.
    first <- findInterval(x_range[1], x, left.open = TRUE) + 1L
    last <- findInterval(x_range[2], x)
    visible <- max(0L, last - first + 1L)
    context <- c(if (first > 1L) min(n, first - 1L), if (last < n) max(1L, last + 1L))
    inside <- if (visible) seq.int(first, last) else integer()
    if (length(inside) > max_points - 2L) {
      buckets <- floor((max_points - 2L)/2L)
      cells <- findInterval(x[inside], seq(x_range[1], x_range[2], length.out = buckets + 1L), all.inside = TRUE)
      # Retain both extrema at their actual mass positions, in original order.
      # Do not average intensities or discard a narrow peak between stride points.
      inside <- unlist(lapply(split(inside, cells), function(rows) {
        values <- y[rows]
        rows[c(which.min(values), which.max(values))]
      }), use.names = FALSE)
    }
    rows <- sort(unique(c(context, inside)))
    list(data = spectrum$data[rows, , drop = FALSE], x_range = x_range, y_range = y_range,
      shown = sum(x[rows] >= x_range[1] & x[rows] <= x_range[2]), visible = visible,
      total = n, key = spectrum$key)
  }

  investigate_median_zoom <- function(event, spectrum, view = NULL) {
    if (is.null(view)) view <- list(x = spectrum$mz_range, y = spectrum$intensity_range)
    read_axis <- function(axis, current, full) {
      if (isTRUE(event[[paste0(axis, ".autorange")]])) return(full)
      limits <- event[[paste0(axis, ".range")]]
      if (is.null(limits)) {
        lower <- event[[paste0(axis, ".range[0]")]]
        upper <- event[[paste0(axis, ".range[1]")]]
        if (is.null(lower) || is.null(upper)) return(current)
        limits <- c(lower, upper)
      }
      limits <- unlist(limits, use.names = FALSE)
      if (!is.numeric(limits) || length(limits) != 2L || any(!is.finite(limits)) || limits[1] >= limits[2]) return(current)
      as.numeric(limits)
    }
    list(x = read_axis("xaxis", view$x, spectrum$mz_range),
      y = read_axis("yaxis", view$y, spectrum$intensity_range))
  }

  investigate_plot_median <- function(display) {
    plot <- plotly::plot_ly(x = display$data$mz, y = display$data$intensity,
      type = "scatter", source = "metabomeister_median",
      mode = if (nrow(display$data) == 1L) "markers" else "lines",
      line = list(color = "#198a71", simplify = FALSE), name = "Median MS1 intensity",
      hovertemplate = "m/z: %{x:.7f}<br>Median intensity: %{y:.6g}<extra></extra>") %>%
      plotly::layout(uirevision = paste(display$key, collapse = ":"), dragmode = "zoom",
        xaxis = list(title = "m/z", range = display$x_range),
        yaxis = list(title = "Median intensity (ion counts)", range = display$y_range),
        margin = list(l = 70, r = 20, b = 55, t = 20)) %>%
      plotly::config(scrollZoom = TRUE, displaylogo = FALSE, displayModeBar = TRUE,
        modeBarButtonsToRemove = c("select2d", "lasso2d")) %>%
      plotly::event_register("plotly_relayout")
    # Hover stays entirely in the browser; only view changes need an R response.
    plot <- plotly::event_unregister(plot, "plotly_hover")
    plotly::event_unregister(plot, "plotly_unhover")
  }

  investigate_extract_slice <- function(raw, center, window, unit, time_range,
                                         aggregation = "mean", progress = function(fraction) NULL) {
    mz_range <- investigate_window_limits(center, window, unit)
    time_range <- investigate_range(time_range, "Cross-section time range")
    if (length(aggregation) != 1L || !aggregation %in% c("mean", "sum", "max")) stop("Choose mean, sum or maximum intensity.")
    values <- numeric(length(raw$scans))
    selected <- investigate_walk_scans(raw, time_range, function(scan, index) {
      intensity <- scan[scan[, 1] >= mz_range[1] & scan[, 1] <= mz_range[2], 2]
      values[index] <<- if (!length(intensity)) 0 else switch(aggregation,
        mean = mean(intensity), sum = sum(intensity), max = max(intensity))
    }, progress)
    list(axis = "mz", data = data.frame(time = raw$times[selected], intensity = values[selected]),
      center = center, window = window, unit = unit, mz_range = mz_range,
      time_range = time_range, aggregation = aggregation)
  }

  # Matabo3.6.2 Time slices combine scans on an explicit mass grid or overlay
  # original spectra, ordered by distance from the requested acquisition time.
  investigate_extract_time_slice <- function(raw, center, mz_range,
                                               mode = "combine", window_seconds = 5,
                                               mz_bin_width = 0.01, n_spectra = 5,
                                               progress = function(fraction) NULL) {
    if (!is.numeric(center) || length(center) != 1L || !is.finite(center) ||
        center < min(raw$times) || center > max(raw$times)) {
      stop("Choose a slice time inside the loaded run's acquisition-time range.", call. = FALSE)
    }
    mz_range <- investigate_range(mz_range, "Spectrum m/z range")
    if (!is.numeric(window_seconds) || length(window_seconds) != 1L ||
        !is.finite(window_seconds) || window_seconds <= 0) stop("Enter a positive ± time window in seconds.")
    if (length(mode) != 1L || !mode %in% c("combine", "overlay")) stop("Choose Combine or Overlay for the time slice.")
    time_range <- c(max(0, center - window_seconds/60), center + window_seconds/60)
    selected <- which(raw$times >= time_range[1] & raw$times <= time_range[2])
    if (!length(selected)) stop("No MS1 scans fall inside the selected time window. Increase the window or choose another time.")
    if (mode == "overlay") {
      if (!is.numeric(n_spectra) || length(n_spectra) != 1L || !is.finite(n_spectra) ||
          n_spectra < 2 || n_spectra > 20 || n_spectra != floor(n_spectra)) stop("Enter a whole spectrum count between 2 and 20.")
      selected <- head(selected[order(abs(raw$times[selected] - center), raw$times[selected])], n_spectra)
      spectra <- vector("list", length(selected))
    } else {
      if (!is.numeric(mz_bin_width) || length(mz_bin_width) != 1L ||
          !is.finite(mz_bin_width) || mz_bin_width <= 0) stop("Enter a positive combined-spectrum m/z bin width.")
      bins <- ceiling(diff(mz_range)/mz_bin_width)
      if (!is.finite(bins) || bins > 1e6) stop("The combined spectrum exceeds 1,000,000 m/z bins. Increase its bin width or narrow its m/z range.")
      edges <- mz_range[1] + (0:bins) * mz_bin_width
      tolerance <- 8 * .Machine$double.eps * max(1, abs(mz_range))
      if (length(edges) > 2L && edges[length(edges) - 1L] >= mz_range[2] - tolerance) {
        edges <- head(edges, -1L)
        bins <- length(edges) - 1L
      }
      edges[length(edges)] <- mz_range[2]
      totals <- numeric(bins)
    }
    view <- raw
    view$scans <- raw$scans[selected]; view$times <- raw$times[selected]
    points <- 0
    investigate_walk_scans(view, time_range, function(scan, index) {
      scan <- scan[scan[, 1] >= mz_range[1] & scan[, 1] <= mz_range[2], , drop = FALSE]
      if (!nrow(scan)) return()
      points <<- points + nrow(scan)
      if (mode == "overlay") {
        scan <- scan[order(scan[, 1]), , drop = FALSE]
        spectra[[index]] <<- list(time = view$times[index], scan = view$scans[index],
          distance_seconds = abs(view$times[index] - center) * 60,
          data = data.frame(mz = scan[, 1], intensity = scan[, 2]))
      } else {
        mass_bin <- findInterval(scan[, 1], edges, all.inside = TRUE)
        per_scan_mean <- tapply(scan[, 2], mass_bin, mean)
        columns <- as.integer(names(per_scan_mean))
        totals[columns] <<- totals[columns] + as.numeric(per_scan_mean)
      }
    }, progress)
    if (!points) stop("No selected MS1 spectra have measurements inside the chosen m/z range.")
    result <- list(axis = "time", mode = mode, requested_time = center,
      window_seconds = window_seconds, time_range = time_range,
      selected_times = view$times, scan_count = length(selected), mz_range = mz_range)
    if (mode == "overlay") {
      result$spectra <- Filter(Negate(is.null), spectra)
    } else {
      result$mz_bin_width <- mz_bin_width
      result$data <- data.frame(mz = head(edges, -1) + diff(edges)/2,
        intensity = totals/length(selected))
    }
    result
  }

  investigate_intensity_range <- function(values) {
    limits <- range(c(0, values[is.finite(values)]))
    if (diff(limits) == 0) return(c(0, 1))
    c(if (limits[1] < 0) limits[1] * 1.05 else 0,
      if (limits[2] > 0) limits[2] * 1.05 else 0)
  }

  investigate_camera <- function() list(eye = list(x = 1.6, y = 1.6, z = 1.1))

  investigate_plot_grid <- function(grid, band = NULL, logarithmic = FALSE, time_band = NULL) {
    transform <- if (logarithmic) function(x) log10(1 + pmax(x, 0)) else identity
    limits <- transform(grid$intensity_range)
    if (diff(limits) == 0) limits <- c(0, 1)
    if (length(grid$mz) >= 2L && length(grid$time) >= 2L) {
      plot <- plotly::plot_ly(x = grid$mz, y = grid$time, z = transform(grid$z),
      surfacecolor = grid$z, type = "surface",
      colorscale = list(list(0, "#dbeefe"), list(0.2, "#84cfef"), list(0.4, "#42c6b1"),
        list(0.6, "#f4db63"), list(0.8, "#f99a47"), list(1, "#e3483c")),
      lighting = list(ambient = 0.85, diffuse = 0.75, roughness = 0.8, specular = 0.05),
      source = "metabomeister_investigate", colorbar = list(title = "Ion counts"),
      hovertemplate = "m/z: %{x:.5f}<br>Time: %{y:.4f} min<br>Mean intensity: %{surfacecolor:.4g}<extra></extra>")
    } else {
      coordinates <- expand.grid(time = grid$time, mz = grid$mz)
      plot <- plotly::plot_ly(x = coordinates$mz, y = coordinates$time,
        z = as.numeric(transform(grid$z)), type = "scatter3d", mode = "lines+markers",
        marker = list(color = "#249fc5", size = 4), line = list(color = "#249fc5"),
        customdata = as.numeric(grid$z), source = "metabomeister_investigate",
        hovertemplate = "m/z: %{x:.6f}<br>Time: %{y:.5f} min<br>Mean intensity: %{customdata:.5g}<extra></extra>")
    }
    if (!is.null(time_band) && all(is.finite(time_band)) &&
        time_band[2] >= grid$time_range[1] && time_band[1] <= grid$time_range[2]) {
      time_band <- pmax(grid$time_range[1], pmin(grid$time_range[2], time_band))
      marker_x <- c(grid$mz_range[1], grid$mz_range[2], grid$mz_range[2], grid$mz_range[1])
      marker_y <- c(time_band[1], time_band[1], time_band[2], time_band[2])
      marker_name <- "Selected time"
    } else if (!is.null(band) && band[2] >= grid$mz_range[1] && band[1] <= grid$mz_range[2]) {
      band <- pmax(grid$mz_range[1], pmin(grid$mz_range[2], band))
      marker_x <- c(band[1], band[2], band[2], band[1])
      marker_y <- c(grid$time_range[1], grid$time_range[1], grid$time_range[2], grid$time_range[2])
      marker_name <- "Selected m/z window"
    } else marker_name <- NULL
    if (!is.null(marker_name)) {
      plot <- plotly::add_trace(plot, type = "mesh3d", inherit = FALSE,
        x = marker_x, y = marker_y,
        z = rep(limits[1] + diff(limits) * 0.002, 4), i = c(0, 0), j = c(1, 2), k = c(2, 3),
        color = I("#f59e0b"), opacity = 0.7, showscale = FALSE, hoverinfo = "skip", name = marker_name)
    }
    plot <- plotly::layout(plot, uirevision = paste(grid$key, collapse = ":"),
      scene = list(xaxis = list(title = "m/z", range = grid$mz_range),
        yaxis = list(title = "Time (min)", range = grid$time_range),
        zaxis = list(title = if (logarithmic) "log10(1 + intensity)" else "Intensity (ion counts)", range = limits),
        camera = investigate_camera(), dragmode = "orbit", aspectmode = "manual",
        aspectratio = list(x = 1.3, y = 1.3, z = 0.8)), margin = list(l = 0, r = 0, b = 0, t = 25))
    plotly::event_register(plotly::config(plot, scrollZoom = TRUE, displaylogo = FALSE), "plotly_click")
  }

  investigate_plot_slice <- function(trace) {
    time_slice <- identical(trace$axis, "time")
    x_range <- if (time_slice) trace$mz_range else trace$time_range
    overlay <- time_slice && identical(trace$mode, "overlay")
    y_title <- if (time_slice) {
      if (overlay) "Intensity (ion counts)" else "Mean intensity (ion counts)"
    } else paste(trace$aggregation, "intensity (ion counts)")
    if (overlay) {
      plot <- plotly::plot_ly()
      palette <- grDevices::hcl.colors(max(3L, length(trace$spectra)), "Dark 3")
      for (i in seq_along(trace$spectra)) {
        spectrum <- trace$spectra[[i]]
        label <- paste0(i, ": ", format(spectrum$time, digits = 7), " min (Δ",
          format(signif(spectrum$distance_seconds, 4), trim = TRUE), " s)")
        plot <- plotly::add_trace(plot, x = spectrum$data$mz, y = spectrum$data$intensity,
          type = "scattergl", mode = if (nrow(spectrum$data) == 1L) "markers" else "lines",
          name = label, line = list(color = palette[i]),
          hovertemplate = paste0("Time: ", format(spectrum$time, digits = 7),
            " min<br>m/z: %{x:.6f}<br>Intensity: %{y:.5g}<extra>%{fullData.name}</extra>"))
      }
    } else {
      x <- if (time_slice) trace$data$mz else trace$data$time
      plot <- plotly::plot_ly(x = x, y = trace$data$intensity, type = "scattergl",
        mode = if (length(x) == 1L) "markers" else "lines",
        line = list(color = "#24547b"), name = if (time_slice) "Combined MS1 spectrum" else paste(trace$aggregation, "intensity"),
        hovertemplate = if (time_slice) "m/z: %{x:.6f}<br>Mean intensity: %{y:.5g}<extra></extra>" else
          "Time: %{x:.4f} min<br>Intensity: %{y:.5g}<extra></extra>")
    }
    plot %>%
      plotly::layout(uirevision = paste(trace$key, collapse = ":"),
        xaxis = list(title = if (time_slice) "m/z" else "Time (min)", range = x_range),
        yaxis = list(title = y_title, range = trace$intensity_range),
        showlegend = overlay, legend = list(title = list(text = "Nearest → farthest"), font = list(size = 11)),
        margin = list(l = 70, r = 20, b = 55, t = 20)) %>%
      plotly::config(scrollZoom = TRUE, displaylogo = FALSE)
  }

  investigate_display_range <- function(limits) {
    # Round outward to three decimals so no endpoint scan/mass is lost.
    c(floor(limits[1] * 1000)/1000, ceiling(limits[2] * 1000)/1000)
  }

  ######Matabo3.6.3 File selection, range controls and guarded GUI actions######
  observe_updates({
    files <- uploadedmz5()
    files <- files[files$Source == "upload" & !is.na(files$FilePath) & file.exists(files$FilePath), , drop = FALSE]
    current <- isolate(input$investigate_engine_file)
    paths <- files$FilePath
    updateSelectInput(session, "investigate_engine_file",
      choices = c("Select a raw upload" = "", stats::setNames(paths, files$FileName)),
      selected = if (length(current) == 1L && current %in% paths) current else if (length(paths)) paths[1] else "")
  })

  observe_action(input$investigate_clear, {
    investigate_close_raw(investigate_raw())
    investigate_raw(NULL); investigate_grid(NULL); investigate_trace(NULL); investigate_median(NULL); investigate_median_view(NULL); investigate_median_time_custom(FALSE)
  })
  session$onSessionEnded(function() investigate_close_raw(isolate(investigate_raw())))

  observe_action(input$investigate_load, {
    with_action_error({
      investigate_close_raw(investigate_raw())
      investigate_raw(NULL); investigate_grid(NULL); investigate_trace(NULL); investigate_median(NULL); investigate_median_view(NULL); investigate_median_time_custom(FALSE)
      if (identical(input$investigate_source, "upload")) {
        file <- input$investigate_raw_file
        if (is.null(file) || !nrow(file)) stop("Select the original .mz5 file in Investigate first.")
        path <- file$datapath[1]; name <- file$name[1]
      } else {
        files <- uploadedmz5()
        selected <- which(files$Source == "upload" & files$FilePath == input$investigate_engine_file)
        if (!length(selected)) stop("No Engine raw upload is selected. Upload a .mz5 in Engine or select another file here.")
        path <- files$FilePath[selected[1]]; name <- files$FileName[selected[1]]
      }
      raw <- shiny::withProgress(message = "Measuring native MS1 sampling (one pass)", value = 0, {
        investigate_open_raw(path, name, progress = function(fraction) shiny::setProgress(value = fraction))
      })
      investigate_raw(raw)
      mz_bounds <- investigate_display_range(raw$mz_range)
      time_bounds <- investigate_display_range(raw$time_range)
      defaults <- list(investigate_mz_min = mz_bounds[1], investigate_mz_max = mz_bounds[2],
        investigate_time_min = time_bounds[1], investigate_time_max = time_bounds[2],
        investigate_median_time_min = time_bounds[1], investigate_median_time_max = time_bounds[2],
        investigate_slice_time_min = time_bounds[1], investigate_slice_time_max = time_bounds[2],
        investigate_time_center = raw$times[ceiling(length(raw$times)/2)],
        investigate_spectrum_mz_min = mz_bounds[1], investigate_spectrum_mz_max = mz_bounds[2])
      defaults$investigate_mz_group <- 40
      defaults$investigate_time_group <- 20
      defaults$investigate_alignment_width <- raw$alignment_width
      targets <- suppressWarnings(as.numeric(c(refMassListData()$mz, massData()$mz)))
      targets <- targets[is.finite(targets) & targets >= raw$mz_range[1] & targets <= raw$mz_range[2]]
      defaults$investigate_center <- if (length(targets)) targets[1] else mean(raw$mz_range)
      for (id in names(defaults)) updateNumericInput(session, id, value = defaults[[id]])
    }, "Investigate: load raw file")
  })

  # Only explicit typing/pasting in a median time field detaches its defaults.
  # NumericInput update messages arrive asynchronously and must not count as edits.
  observe_action(input$investigate_median_time_edited, {
    investigate_median_time_custom(TRUE)
  })
  observe_updates({
    req(investigate_raw())
    limits <- c(input$investigate_time_min, input$investigate_time_max)
    if (!is.numeric(limits) || length(limits) != 2L || any(!is.finite(limits))) return()
    if (!isolate(investigate_median_time_custom())) {
      updateNumericInput(session, "investigate_median_time_min", value = limits[1])
      updateNumericInput(session, "investigate_median_time_max", value = limits[2])
    }
  })

  observe_action(input$investigate_draw_3d, {
    with_action_error({
      raw <- investigate_raw()
      if (is.null(raw)) stop("Load a raw .mz5 file first.")
      previous <- investigate_grid(); investigate_grid(NULL)
      mz_range <- investigate_range(c(input$investigate_mz_min, input$investigate_mz_max), "3D m/z range")
      time_range <- investigate_range(c(input$investigate_time_min, input$investigate_time_max), "3D time range")
      limits <- if (isTRUE(input$investigate_auto_z)) NULL else investigate_range(
        c(input$investigate_z_min, input$investigate_z_max), "3D intensity range", nonnegative = FALSE)
      width <- if (raw$sampling$shared) NULL else input$investigate_alignment_width
      key <- c(raw$name, mz_range, time_range, input$investigate_mz_group, input$investigate_time_group, width)
      grid <- if (!is.null(previous) && identical(previous$key, key)) previous else {
        shiny::withProgress(message = "Building raw 3D preview", value = 0, {
          investigate_build_grid(raw, mz_range, time_range,
            input$investigate_mz_group, input$investigate_time_group, alignment_width = width,
            progress = function(fraction) shiny::setProgress(value = fraction))
        })
      }
      grid$key <- key
      grid$intensity_range <- if (is.null(limits)) investigate_intensity_range(grid$z) else limits
      investigate_grid(grid)
    }, "Investigate: draw 3D preview")
  })

  observe_action(input$investigate_draw_slice, {
    with_action_error({
      raw <- investigate_raw()
      if (is.null(raw)) stop("Load a raw .mz5 file first.")
      previous <- investigate_trace(); investigate_trace(NULL)
      limits <- if (isTRUE(input$investigate_auto_y)) NULL else investigate_range(
        c(input$investigate_y_min, input$investigate_y_max), "Trace intensity range", nonnegative = FALSE)
      time_slice <- identical(input$investigate_slice_axis, "time")
      if (time_slice) {
        mz_range <- investigate_range(c(input$investigate_spectrum_mz_min, input$investigate_spectrum_mz_max), "Spectrum m/z range")
        key <- c("time", raw$name, input$investigate_time_center, mz_range,
          input$investigate_time_mode, input$investigate_time_window,
          if (identical(input$investigate_time_mode, "overlay")) input$investigate_spectrum_count else input$investigate_spectrum_bin_width)
      } else {
        time_range <- investigate_range(c(input$investigate_slice_time_min, input$investigate_slice_time_max), "Cross-section time range")
        key <- c("mz", raw$name, input$investigate_center, input$investigate_window,
          input$investigate_unit, time_range, input$investigate_aggregation)
      }
      trace <- if (!is.null(previous) && identical(previous$key, key)) previous else {
        shiny::withProgress(message = "Extracting original MS1 scans", value = 0, {
          if (time_slice) investigate_extract_time_slice(raw, input$investigate_time_center, mz_range,
            mode = input$investigate_time_mode, window_seconds = input$investigate_time_window,
            mz_bin_width = input$investigate_spectrum_bin_width, n_spectra = input$investigate_spectrum_count,
            progress = function(fraction) shiny::setProgress(value = fraction)) else
              investigate_extract_slice(raw, input$investigate_center, input$investigate_window,
                input$investigate_unit, time_range, input$investigate_aggregation,
                progress = function(fraction) shiny::setProgress(value = fraction))
        })
      }
      trace$key <- key
      intensities <- if (time_slice && identical(trace$mode, "overlay")) {
        unlist(lapply(trace$spectra, function(spectrum) range(spectrum$data$intensity)), use.names = FALSE)
      } else trace$data$intensity
      trace$intensity_range <- if (is.null(limits)) investigate_intensity_range(intensities) else limits
      investigate_trace(trace)
    }, "Investigate: extract m/z cross-section")
  })

  observe_action(input$investigate_draw_median, {
    with_action_error({
      raw <- investigate_raw()
      if (is.null(raw)) stop("Load a raw .mz5 file first.")
      mz_range <- investigate_range(c(input$investigate_mz_min, input$investigate_mz_max), "Median m/z range")
      time_range <- investigate_range(c(input$investigate_median_time_min, input$investigate_median_time_max), "Median time range")
      width <- if (raw$sampling$shared) NULL else input$investigate_alignment_width
      key <- c(raw$name, mz_range, time_range, width, input$investigate_median_step)
      previous <- investigate_median()
      spectrum <- if (!is.null(previous) && identical(previous$key, key)) previous else {
        investigate_median(NULL); investigate_median_view(NULL)
        shiny::withProgress(message = "Exact median across selected MS1 scans", value = 0, {
          investigate_median_spectrum(raw, mz_range, time_range, width, scan_step = input$investigate_median_step,
            progress = function(fraction) shiny::setProgress(value = fraction))
        })
      }
      spectrum$key <- key
      spectrum$intensity_range <- investigate_intensity_range(spectrum$data$intensity)
      investigate_median(spectrum)
    }, "Investigate: median spectrum")
  })
  observe_action(input$investigate_reset_median, {
    req(investigate_median())
    spectrum <- investigate_median()
    investigate_median_view(NULL)
    display <- investigate_median_view_data(spectrum)
    proxy <- plotly::plotlyProxy("investigate_median_plot", session)
    proxy %>% plotly::plotlyProxyInvoke("restyle",
      list(x = list(display$data$mz), y = list(display$data$intensity)), list(0L))
    proxy %>% plotly::plotlyProxyInvoke("relayout",
      list("xaxis.range" = spectrum$mz_range, "yaxis.range" = spectrum$intensity_range))
  })

  observe_action(plot_event_data("plotly_relayout", "metabomeister_median"), {
    spectrum <- investigate_median()
    req(spectrum)
    current <- investigate_median_view()
    next_view <- investigate_median_zoom(plot_event_data("plotly_relayout", "metabomeister_median"), spectrum, current)
    effective <- if (is.null(current)) list(x = spectrum$mz_range, y = spectrum$intensity_range) else current
    # Plotly may emit autosize/identical range messages after rendering. Ignore
    # these to avoid a relayout/render loop and preserve the user's zoom.
    if (!isTRUE(all.equal(next_view, effective, tolerance = 1e-12))) {
      investigate_median_view(next_view)
      display <- investigate_median_display()
      # Replace trace coordinates only. Rebuilding the whole widget here can
      # interrupt a second drag while the first zoom response is arriving.
      plotly::plotlyProxy("investigate_median_plot", session) %>% plotly::plotlyProxyInvoke("restyle",
        list(x = list(display$data$mz), y = list(display$data$intensity)), list(0L))
    }
  })

  observe_action(input$investigate_reset_3d, {
    req(investigate_grid())
    grid <- investigate_grid()
    limits <- grid$intensity_range
    if (isTRUE(input$investigate_log_z)) limits <- log10(1 + pmax(limits, 0))
    if (diff(limits) == 0) limits <- c(0, 1)
    plotly::plotlyProxy("investigate_3d", session) %>% plotly::plotlyProxyInvoke("relayout",
      list("scene.camera" = investigate_camera(), "scene.xaxis.range" = grid$mz_range,
        "scene.yaxis.range" = grid$time_range, "scene.zaxis.range" = limits))
  })
  observe_action(input$investigate_reset_slice, {
    req(investigate_trace())
    trace <- investigate_trace()
    plotly::plotlyProxy("investigate_slice", session) %>% plotly::plotlyProxyInvoke("relayout",
      list("xaxis.range" = if (identical(trace$axis, "time")) trace$mz_range else trace$time_range,
        "yaxis.range" = trace$intensity_range))
  })
  observe_action(plot_event_data("plotly_click", "metabomeister_investigate"), {
    click <- plot_event_data("plotly_click", "metabomeister_investigate")
    if (!is.null(click) && length(click$x) && is.finite(click$x[1]) &&
        (!"curveNumber" %in% names(click) || click$curveNumber[1] == 0L)) {
      if (identical(input$investigate_slice_axis, "time") && length(click$y) && is.finite(click$y[1])) {
        updateNumericInput(session, "investigate_time_center", value = as.numeric(click$y[1]))
      } else updateNumericInput(session, "investigate_center", value = as.numeric(click$x[1]))
    }
  })

  ######Matabo3.6.4 Interactive plots and data provenance######
  output$investigate_needs_alignment <- reactive({
    raw <- investigate_raw()
    !is.null(raw) && !isTRUE(raw$sampling$shared)
  })
  outputOptions(output, "investigate_needs_alignment", suspendWhenHidden = FALSE)
  investigate_number <- function(x) {
    if (length(x) != 1L || !is.finite(x)) "not available" else format(signif(x, 8), trim = TRUE, scientific = FALSE)
  }
  output$investigate_status <- renderText({
    raw <- investigate_raw()
    if (is.null(raw)) return("Load a raw file to measure native MS1 sampling once, then choose a plot.")
    sampling <- raw$sampling
    mass_count <- if (sampling$shared) paste0(length(sampling$mz_axis), " shared native m/z positions") else
      paste0("m/z positions vary: ", paste(sampling$mz_count_range, collapse = "–"),
        " per spectrum; no single shared native m/z axis")
    paste0("Loaded: ", raw$name, " | ", sampling$time_count, " MS1 time slices (",
      sampling$time_unique, " distinct times)\n",
      "m/z: ", paste(round(raw$mz_range, 3), collapse = " to "), " | Time: ",
      paste(round(range(raw$times), 3), collapse = " to "), " min\n",
      mass_count, "\nMinimum native Δm/z within a spectrum: ",
      investigate_number(sampling$mz_delta), " Da; minimum Δt: ",
      investigate_number(sampling$time_delta), " min (", investigate_number(sampling$time_delta * 60), " s).")
  })
  output$investigate_grid_status <- renderText({
    grid <- investigate_grid()
    if (is.null(grid)) return("No 3D preview drawn yet.")
    paste0(format(grid$points, big.mark = ","), " measurements; ", grid$mass_positions,
      if (grid$native) " native m/z positions" else " aligned m/z positions",
      " × ", grid$scans, " MS1 scans → ", ncol(grid$z), " × ", nrow(grid$z),
      " grouped positions. Factors: m/z ", grid$factors[1], ", time ", grid$factors[2],
      ". Mean intensity; missing positions contribute zero. Raw, uncalibrated data.")
  })
  output$investigate_group_widths <- renderText({
    raw <- investigate_raw()
    if (is.null(raw)) return("")
    tryCatch({
      factors <- investigate_group_factors(input$investigate_mz_group, input$investigate_time_group)
      axis <- investigate_mass_axis(raw, c(input$investigate_mz_min, input$investigate_mz_max),
        input$investigate_alignment_width)
      mz_step <- if (axis$native && length(axis$mz) > 1L) median(diff(axis$mz)) else axis$width
      times <- raw$times[raw$times >= input$investigate_time_min & raw$times <= input$investigate_time_max]
      intervals <- diff(sort(unique(times))) * 60
      time_step <- if (length(intervals)) median(intervals) else NA_real_
      paste0("Per full group: m/z ", if (length(mz_step) && is.finite(mz_step))
        paste0(if (axis$native) "≈ " else "", investigate_number(factors[1] * mz_step), " Da") else "width unavailable",
        "; time ", if (is.finite(time_step)) paste0("≈ ", investigate_number(factors[2] * time_step), " s") else "width unavailable",
        ". Time uses the typical scan interval", if (axis$native) "; m/z uses the typical native spacing" else "",
        ". Last groups may be smaller.")
    }, error = function(e) conditionMessage(e))
  })
  output$investigate_group_status <- renderText({
    raw <- investigate_raw()
    if (is.null(raw)) return("Load a raw file to see the grouping widths in Da and seconds.")
    tryCatch({
      plan <- investigate_group_plan(raw, c(input$investigate_mz_min, input$investigate_mz_max),
        c(input$investigate_time_min, input$investigate_time_max), input$investigate_mz_group,
        input$investigate_time_group, input$investigate_alignment_width)
      paste0(length(plan$axis$mz), if (plan$axis$native) " native" else " aligned", " m/z positions × ",
        length(plan$selected), " scans → ", plan$counts[1], " × ", plan$counts[2],
        " display positions. Last groups can be smaller.",
        if (!plan$axis$native) paste0(" Alignment width: ", investigate_number(plan$axis$width), " Da (not native spacing)."))
    }, error = function(e) conditionMessage(e))
  })
  output$investigate_median_status <- renderText({
    spectrum <- investigate_median()
    if (is.null(spectrum)) return("No median spectrum calculated yet. Choose its time range and scan factor, then calculate.")
    raw <- investigate_raw()
    current <- c(raw$name, input$investigate_mz_min, input$investigate_mz_max,
      input$investigate_median_time_min, input$investigate_median_time_max,
      if (!spectrum$native) input$investigate_alignment_width, input$investigate_median_step)
    paste0("Median of ", spectrum$scans, " / ", spectrum$available_scans, " MS1 scans (factor ", spectrum$scan_step,
      ") in ", paste(round(spectrum$time_range, 3), collapse = "–"),
      " min; ", nrow(spectrum$data), if (spectrum$native) " native m/z positions." else
        paste0(" aligned positions (", investigate_number(spectrum$alignment_width), " Da)."),
      " Missing signal contributes zero; independent of 3D grouping. ",
      if (all(spectrum$data$intensity == 0)) "All medians are zero: no mass position has a nonzero central intensity. " else "",
      if (!identical(current, spectrum$key)) "Ranges or scan factor have changed; click Calculate median spectrum to update.")
  })
  output$investigate_slice_status <- renderText({
    trace <- investigate_trace()
    if (is.null(trace)) return("No cross-section extracted yet.")
    if (identical(trace$axis, "time")) {
      details <- if (identical(trace$mode, "overlay")) paste0(length(trace$spectra),
        " original spectra shown nearest to farthest; ", trace$scan_count,
        " scans selected. Colours identify actual acquisition times; no mass binning.") else
          paste0(trace$scan_count, " MS1 spectra combined; m/z bin width ",
            trace$mz_bin_width, " Da. Mean of per-scan bin intensities; absent bins contribute zero.")
      return(paste0("Time: ", format(trace$requested_time, digits = 7), " ± ",
        trace$window_seconds/60, " min (±", trace$window_seconds, " s). ", details))
    }
    paste0("m/z ", format(trace$center, digits = 8), " ± ", trace$window, " ", trace$unit,
      " [", paste(format(trace$mz_range, digits = 9), collapse = ", "), "]; ",
      trace$aggregation, " intensity; ", nrow(trace$data), " original MS1 scans. No smoothing or peak fitting.")
  })
  output$investigate_3d <- plotly::renderPlotly({
    grid <- investigate_grid()
    shiny::validate(shiny::need(!is.null(grid), "Load a raw file and draw the 3D preview."))
    time_band <- NULL; band <- NULL
    if (identical(input$investigate_slice_axis, "time")) {
      center <- input$investigate_time_center
      window <- input$investigate_time_window
      if (is.numeric(center) && length(center) == 1L && is.finite(center) &&
          is.numeric(window) && length(window) == 1L && is.finite(window) && window > 0) {
        time_band <- center + c(-1, 1) * window/60
      }
    } else band <- tryCatch(investigate_window_limits(input$investigate_center,
      input$investigate_window, input$investigate_unit), error = function(e) NULL)
    investigate_plot_grid(grid, band, isTRUE(input$investigate_log_z), time_band = time_band)
  })
  output$investigate_slice <- plotly::renderPlotly({
    trace <- investigate_trace()
    shiny::validate(shiny::need(!is.null(trace), "Choose an m/z window and plot its cross-section."))
    investigate_plot_slice(trace)
  })
  investigate_median_display <- reactive({
    spectrum <- investigate_median()
    if (is.null(spectrum)) return(NULL)
    investigate_median_view_data(spectrum, investigate_median_view())
  })
  output$investigate_median_display_status <- renderText({
    display <- investigate_median_display()
    if (is.null(display)) return("")
    paste0("Showing ", format(display$shown, big.mark = ","), " of ",
      format(display$visible, big.mark = ","), " median positions in this view. ",
      if (display$shown < display$visible) "Peak-preserving overview; zoom for full detail. " else "All points in this view are shown. ",
      "Drag a rectangle to zoom; Reset median view restores the full range.")
  })
  output$investigate_median_plot <- plotly::renderPlotly({
    spectrum <- investigate_median()
    shiny::validate(shiny::need(!is.null(spectrum), "Click Calculate median spectrum."))
    investigate_plot_median(isolate(investigate_median_display()))
  })
  #####Matabo3.6 End Investigate raw m/z, time and intensity#####

  #####3.7 Extract Electropherograms#####
  # Build extraction windows and sort the spectra used for extraction.
  prepare_extraction_spectra <- function(run_data, is_df, mass_df, total_steps) {
    #Update progress bar
    incProgress(1/total_steps, detail = paste("Extracting Electropherograms"))

    print("Extracting Electropherograms")

    #Define mass error in ppm

    mass_error_vec <- c(is_df$extraction.window.ppm, mass_df$extraction.window.ppm)

    #Create a matrix of minimum and maximum m/z values for each internal standard and metabolite
    mz_vec <- c(is_df$mz, mass_df$mz)
    min <- mz_vec - mz_vec * mass_error_vec / 1000000
    max <- mz_vec + mz_vec * mass_error_vec / 1000000
    mzr <- matrix(c(min, max), ncol = 2)

    #Process/check for correcting any unsorted MZ values in extracted spectra in the MSnExp obj. No clue why this occurs but it can be corrected.
    #Extract the spectra from the assayData environment stored in the run_data MSnExp
    assay_data_env <- assayData(run_data)

    #List all the objects in the assayData environment
    spectra_names <- ls(assay_data_env)

    #Create synthetic environment to merge with the real assayData environment component in run_data after spectra have been sorted
    sorted_assay_data_env <- new.env()

    #Loop through each spectrum in run_data and check if m/z values are unsorted AND if m/z values are negative.
    for (i in spectra_names) {
      spectrum <- get(i, assay_data_env)

      mz_values <- mz(spectrum)
      intensity_values <- intensity(spectrum)

      #Find any negative m/z values and replace them.
      valid_idx <- mz_values >= 0
      mz_values <- mz_values[valid_idx]
      intensity_values <- intensity_values[valid_idx]

      if (length(mz_values) == 0) {
        cat("Spectrum", i, "has no valid MZ values after removing negatives\n")
        next
      }


      #Check if m/z values are unsorted
      if (is.unsorted(mz_values)) {
        cat("Spectrum", i, "has unsorted MZ values\n")

        #Sort the problematic spectrum

        order_idx <- order(mz_values)

        #Create a sorted Spectrum1 object which will then be merged into the original run_data assayData. This allows for correction of the unsorted spectra.
        sorted_spectrum <- new("Spectrum1",
                               mz = mz_values[order_idx],
                               intensity = intensity_values[order_idx],
                               rt = rtime(spectrum),
                               tic = sum(intensity_values[order_idx]),
                               centroided = centroided(spectrum),
                               fromFile = fromFile(spectrum))

        #Confirm spectra is sorted
        cat("Sorted Spectrum", i, "\n")
      } else {
        #If already sorted, keep the original spectrum
        sorted_spectrum <- spectrum
      }

      #Store the sorted spectrum in the new environment
      assign(i, sorted_spectrum, sorted_assay_data_env)
    }

    #Directly update the assayData slot of run_data
    slot(run_data, "assayData") <- sorted_assay_data_env

    list(run_data = run_data, mzr = mzr, mz_vec = mz_vec)
  }

  # Extract mean-intensity electropherograms for the requested mass windows.
  extract_electropherograms <- function(run_data, mzr) {
    #Extract electropherograms
    electropherograms <- chromatogram(run_data,
                                      mz = mzr,
                                      rt = c(0,end(rtime(run_data))),
                                      aggregationFun = "mean",
                                      missing = 0,
                                      msLevel = 1)

    electropherograms
  }

  # Convert extracted traces to the migration-time/intensity table.
  build_eie_dataframe <- function(electropherograms, name_vec) {
    eie_df <- data.frame("mt.seconds" = electropherograms[1]@rtime)

    for (n in 1:length(name_vec)){
      temp_df <- data.frame(electropherograms[n]@intensity)
      colnames(temp_df) <- paste(name_vec[n], "intensity", sep = " ")
      eie_df <- cbind(eie_df,temp_df)
    }

    print("Extraction Complete")

    eie_df
  }

  #####3.8 Smooth Intensity Vectors#####
  # Optionally smooth the intensity columns; temporary objects stay local.
  smooth_electropherograms <- function(eie_df, is_df, mass_df, parameters_df, name_vec, total_steps) {
    smoothing_response <- parameters_df$apply.smoothing
    if (smoothing_response != "Yes" & smoothing_response != "No") {
      stop(paste("apply.smoothing parameter should be 'Yes' or 'No'. ", "'", smoothing_response, "' is not an acceptable input.", sep = ""))
    }
    if (smoothing_response == "No") {
      print("Skipping Smoothing")
    }
    if (smoothing_response == "Yes") {
      incProgress(1/total_steps, detail = "Smoothing Electropherograms")
      print("Smoothing Electropherograms")
      smoothing_kernel_vec <- c(is_df$smoothing.kernel, mass_df$smoothing.kernel)
      smoothing_strength_vec <- c(is_df$smoothing.strength, mass_df$smoothing.strength)
      for (n in 1:length(name_vec)) {
        Smooth <- with(eie_df,
          ksmooth(x = mt.seconds, y = eie_df[, n + 1],
                  kernel = smoothing_kernel_vec[n],
                  bandwidth = smoothing_strength_vec[n]))
        eie_df[, n + 1] <- Smooth[["y"]]
      }
    }
    print("Electropherograms Smoothing Complete")
    eie_df
  }

  #####3.9 Internal Standard Peak Detection, Integration, and Filtering#####
  # Detect, integrate and filter the internal-standard peaks.
  process_internal_standard_peaks <- function(eie_df, is_df, parameters_df, name_vec, num_of_is, num_of_injections, total_steps) {
    #Update progress bar
    incProgress(1/total_steps, detail = paste("Performing Peak Picking and Filtering for Internal Standards"))

    print("Performing Peak Picking and Filtering for Internal Standards")

    ######3.9.1 Peak detection######

    is_peaks_df <- local({

      n <- 1

      for (s in 1:num_of_is){

        rle_output <- eie_df[,s+1] %>%
          diff() %>%
          sign() %>%
          rle()

        consecutive_runs <- which(rle_output$lengths > n & rle_output$values == 1)
        consecutive_runs <- subset(consecutive_runs, (consecutive_runs + 1) %in% (which(rle_output$lengths > n)) == TRUE)

        run_lengths <- cumsum(rle_output$lengths) + 1

        start <- eie_df$mt.seconds[run_lengths[consecutive_runs - 1]]
        apex <- eie_df$mt.seconds[run_lengths[consecutive_runs]]
        end <- eie_df$mt.seconds[run_lengths[consecutive_runs + 1]]

        #For FWHM calculations I will also add intensity values here as well

        start_intensity <- eie_df[run_lengths[consecutive_runs - 1], (s+1)]
        apex_intensity <- eie_df[run_lengths[consecutive_runs], (s+1)]
        end_intensity <- eie_df[run_lengths[consecutive_runs + 1], (s+1)]

        #Account for peaks that start immediately during the analysis

        if(length(start) != length(apex)){
          start <- append(start, 0, 0)
          start_intensity <- append(start_intensity, 0, 0)
        }

        #Create a data frame containing the start, apex, and end migration times of each peak

        peak_df <- data.frame(start,
                              apex,
                              end,
                              start_intensity,
                              apex_intensity,
                              end_intensity)

        ######3.9.2 Migration time filtering######

        #Filter peaks that are outside migration time limits

        peak_df <- subset(peak_df, peak_df$apex >= is_df$min.mt.min[s] * 60 & peak_df$apex <= is_df$max.mt.min[s] * 60)

        ######3.9.3 Integrate peaks######

        peak_area_vector = c(1:nrow(peak_df))

        #If the length of peak_area_vector is less than the number of injections,
        #print an error and suggest a solution

        if (length(peak_area_vector) < num_of_injections){
          cat(paste("Warning: ", name_vec[s], " EIE contains insufficient data. If an error occurs try:
      1. Increasing the extraction.window.ppm parameter
      2. Adjusting min.mt.min and max.mt.min parameters", sep =""))
        }

        for (p in 1:nrow(peak_df)){

          peak_area_vector[p] <- AUC(eie_df$mt.seconds,
                                     eie_df[,s+1],
                                     method = "trapezoid",
                                     from = peak_df[p,1],
                                     to = peak_df[p,3],
                                     absolutearea = FALSE,
                                     na.rm = FALSE)

          #Perform baseline correction

          peak_area_vector[p] <- peak_area_vector[p] - (peak_df[p,3] - peak_df[p,1]) * min(peak_df[p,4], peak_df[p,6])
        }

        peak_df <- cbind(peak_df, peak_area_vector)

        #rename peak_df columns

        colnames(peak_df) <- c(paste(name_vec[s], "start.seconds", sep = "."),
                               paste(name_vec[s], "apex.seconds", sep = "."),
                               paste(name_vec[s], "end.seconds", sep = "."),
                               paste(name_vec[s], "start_intensity", sep = "."),
                               paste(name_vec[s], "apex_intensity", sep = "."),
                               paste(name_vec[s], "end_intensity", sep = "."),
                               paste(name_vec[s], "peak.area", sep = "."))

        #Retain peak_df for future filtering steps

        peak_df_fill <- peak_df

        ######3.9.4 FWHM filtering######

        #Do not not apply the FWHM filter if the number of injections is equal to 1

        if (parameters_df$number.of.injections != 1) {

          #Find the peak intensity at half the peak height

          intensity_fwhm <- peak_df[,4] + (peak_df[,5] - peak_df[,4])/2

          #Find the migration times closest to these intensities within each peak

          fwhm_vec <- vector()
          single_eie <- eie_df[,c(1,s+1)]

          for(p in 1:nrow(peak_df)){

            single_eie_temp <- subset(single_eie, single_eie$mt.seconds >= peak_df[p,1] & single_eie$mt.seconds <= peak_df[p,2])
            fwhm_mt_left <- single_eie_temp$mt.seconds[which.min(abs(single_eie_temp[,2] - intensity_fwhm[p]))]

            single_eie_temp <- subset(single_eie, single_eie$mt.seconds <= peak_df[p,3] & single_eie$mt.seconds >= peak_df[p,2])
            fwhm_mt_right <- single_eie_temp$mt.seconds[which.min(abs(single_eie_temp[,2] - intensity_fwhm[p]))]

            fwhm_vec <- append(fwhm_vec, fwhm_mt_right - fwhm_mt_left)

          }

          peak_df$fwhm <- fwhm_vec

          #Determine the fwhm of the peaks (n = num_of_injections) with the greatest area

          df_temp <- peak_df[order(-peak_df[,8]),]
          df_temp <- df_temp[1:num_of_injections,]

          fwhm_cutoff <- median(df_temp$fwhm)

          peak_df <- subset(peak_df, peak_df$fwhm <= (fwhm_cutoff * is_df$peak.fwhm.tolerance.multiplier[s]))
          peak_df <- peak_df[,c(1:7)]

        }

        #subset peak_df so that only the peaks (n = number.of.injections) with the greatest area are kept

        cut_off <- sort(peak_df[,7], decreasing = TRUE)[num_of_injections]

        peak_df <- subset(peak_df, peak_df[,7] >= cut_off)

        ######3.9.5 Peak space filtering######

        #Do not apply peak space filtering if the number of injections is equal to 1

        if(num_of_injections != 1){

          #Determine the upper and lower migration time limits for space between peaks

          median_space <- peak_df[,2] %>%
            diff() %>%
            median()

          median_space_tol <- is_df$peak.space.tolerance.percent[s] / 100

          median_space_lower_lim <- median_space - median_space * median_space_tol
          median_space_upper_lim <- median_space + median_space * median_space_tol

          #Check if peaks migrate within the tolerance limits

          peak_space_tol_check <- between(diff(peak_df[,2]), median_space_lower_lim, median_space_upper_lim)

          if(all(peak_space_tol_check) != TRUE){
            bad_space <- which(peak_space_tol_check == FALSE)
          }else{
            bad_space <- NA
          }

          ######3.9.6 Scenario 1######
          #Only one bad space is detected

          if(length(bad_space) == 1 & is.na(bad_space[1]) == FALSE){

            false_peak_diff <- peak_df[num_of_injections, 2] - peak_df[(num_of_injections - 1), 2]

            #This algorithm always assumes the final peak is false - likely due to carryover
            #It is possible the first peak is false but this seems less likely
            #Final peak only removed if case 1 does not produce a duplicate

            #Case 1- An interior peak is missing (usually a blank)

            if(bad_space != (num_of_injections - 1)){

              #Since the we know the bad space is not at the end, use the space after the bad space to find the expected apex

              expected_peak_apex <- peak_df[bad_space[1],2] + peak_df[(bad_space[1] + 2),2] - peak_df[(bad_space[1] + 1),2]

            }

            #Case 2 -  Final space is false and less than median - suspect that true final peak was missed

            if(bad_space == (num_of_injections - 1) & false_peak_diff < median_space_upper_lim){
              expected_peak_apex <- peak_df[(num_of_injections - 1 ),2] + median_space
            }

            #Case 3 - Final space is false and greater than median - suspect that peak 1 was missed

            if(bad_space == (num_of_injections - 1) & false_peak_diff > median_space_lower_lim){
              expected_peak_apex <- peak_df[1,2] - median_space
            }

            peak <- which.min(abs(peak_df_fill[,2] - expected_peak_apex))

            #If the nearest peak is too far from the expected migration time use a place holder

            if (abs(peak_df_fill[peak,2] - expected_peak_apex) > (median_space / 2)){

              nearest_mt <- (eie_df$mt.seconds - expected_peak_apex) %>%
                abs() %>%
                which.min(.)

              peaks <- data.frame(eie_df[nearest_mt,1],
                                  eie_df[nearest_mt,1],
                                  eie_df[nearest_mt,1],
                                  eie_df[nearest_mt,s + 1],
                                  eie_df[nearest_mt,s + 1],
                                  eie_df[nearest_mt,s + 1],
                                  0)

              colnames(peaks) <- colnames(peak_df)

              peak_df <- rbind(peak_df, peaks)

              peak_df <- peak_df[order(peak_df[,2]),]

            }else{

              peak_df <- rbind(peak_df, peak_df_fill[peak,])

              peak_df <- peak_df[order(peak_df[,2]),]

            }

            #Remove bad peak

            if (any(duplicated(peak_df[,2]))){

              peak_df <- peak_df[-c(which(duplicated(peak_df[,2]))),]

            }else{

              peak_df <- peak_df[1:(num_of_injections),]

            }
          }

          ######3.9.7 Scenario 2######
          #Two or three bad spaces are detected

          if(length(bad_space) == 2 | length(bad_space) == 3){

            peaks_to_check <- c(bad_space, (bad_space + 1)) %>%
              unique() %>%
              sort()

            #Outside peaks must be checked last

            peaks_to_check <- c(peaks_to_check[-1], peaks_to_check[1])

            #Loop through each suspect bad peak and remove them iteratively until the number of bad spaces reaches 1

            for (p in 1:length(peaks_to_check)){

              num_bad_space <- peak_df[,2] %>%
                .[-c(peaks_to_check[p])] %>%
                diff(.) %>%
                between (median_space_lower_lim, median_space_upper_lim)
              num_bad_space <- length(which(num_bad_space == FALSE))

              if (num_bad_space == 1){
                peak_df <- peak_df[-c(peaks_to_check[p]),]
                break
              }
            }

            #To avoid errors where removing a peak results in 0 bad spaces only fill
            #in gap if nrow(peak_df) == number of injections - 1

            if(nrow(peak_df) == (num_of_injections - 1)){

              #Find the peak gap and calculate the expected migration time for the missing peak

              gap <- which(between(diff(peak_df[,2]), median_space_lower_lim, median_space_upper_lim) == FALSE)

              expected_peak_apex <- (peak_df[(gap[1] + 1),2] - peak_df[gap[1],2])/2 + peak_df[gap[1],2]

              #Find the nearest peak in the peak_df_fill data frame to the expected migration time
              #Avoid duplicate peaks by not using exisitng peaks in peak_df

              peak_df_fill <- subset(peak_df_fill, !(peak_df_fill[,2] %in% peak_df[,2]))

              peak <- which.min(abs(peak_df_fill[,2] - expected_peak_apex))
              peak_df <- rbind(peak_df, peak_df_fill[peak,])

              peak_df <- peak_df[order(peak_df[,2]),]

            }
          }
        }

        #Summarize peak_df data in is.peak_df

        if(s == 1){
          is_peaks_df = peak_df
        }else{
          is_peaks_df = cbind(is_peaks_df, peak_df)
        }
      }

      is_peaks_df

    })

    print("Peak Picking and Filtering for Internal Standards Complete")

    is_peaks_df
  }

  #####3.10 Metabolite  Peak Detection, Integration, and Filtering#####
  # Detect, integrate and align metabolite peaks using the reference peaks/indexes.
  process_metabolite_peaks <- function(eie_df, mass_df, is_df, is_mt_df, mi_df, name_vec, num_of_is, num_of_injections, total_steps) {
    #Update progress bar
    incProgress(1/total_steps, detail = paste("Performing Peak Picking and Filtering for Analytes"))

    print("Performing Peak Picking and Filtering for Analytes")

    ######3.10.1 Peak detection######

    metabolite_peaks_df <- local ({

      for (m in (num_of_is + 1):length(name_vec)){

        peak_df <- data.frame()

        #Determine the start, apex, and end of peaks. Use the user defined value "n" to detect peaks.
        #If n results in fewer peaks then injection, decrease n by 1 and repeat

        n <- 1

        rle_output <- eie_df[,m + 1] %>%
          diff() %>%
          sign() %>%
          rle()

        consecutive_runs <- which(rle_output$lengths > n & rle_output$values == 1)
        consecutive_runs <- subset(consecutive_runs, (consecutive_runs + 1) %in% (which(rle_output$lengths > n)) == TRUE)

        run_lengths <- cumsum(rle_output$lengths) + 1

        start <- eie_df$mt.seconds[run_lengths[consecutive_runs - 1]]
        apex <- eie_df$mt.seconds[run_lengths[consecutive_runs]]
        end <- eie_df$mt.seconds[run_lengths[consecutive_runs + 1]]

        #I will also add intensity values here as well

        start_intensity <- eie_df[run_lengths[consecutive_runs - 1], (m+1)]
        apex_intensity <- eie_df[run_lengths[consecutive_runs], (m+1)]
        end_intensity <- eie_df[run_lengths[consecutive_runs + 1], (m+1)]

        #Account for peaks that start immediately during the analysis

        if(length(start) != length(apex)){
          start <- append(start, 0, 0)
          start_intensity <- append(start_intensity, 0, 0)
        }

        #Create a data frame containing the start, apex, and end migration times of each
        #peak in addition to required intensities for FWHM calculations

        peak_df <- data.frame(start,
                              apex,
                              end,
                              start_intensity,
                              apex_intensity,
                              end_intensity)

        ######3.10.2 Filter peaks by peak width######

        #Define a minimum peak width cut off in seconds. Remove peaks with a width <= cutoff

        min_width_cut_off <- mass_df$minimim.peak.width.seconds[m - num_of_is]

        peak_df <- subset(peak_df, (peak_df$end - peak_df$start) >= min_width_cut_off)

        ######3.10.3 Integrate peaks######

        peak_area_vector = c(1:nrow(peak_df))

        #If the length of peak_area_vector is less than the number of injections,
        #print an error and suggest a solution

        if (length(peak_area_vector) < num_of_injections){
          cat(paste("Warning: ", name_vec[m], " EIE contains insufficient data. If an error occurs try:
      1. Increasing the extraction.window.ppm parameter
      2. Decreasing the minimim.peak.width.seconds parameter", sep =""))
        }

        for (p in 1:nrow(peak_df)){

          peak_area_vector[p] <- AUC(eie_df$mt.seconds,
                                     eie_df[,m+1],
                                     method = "trapezoid",
                                     from = peak_df[p,1],
                                     to = peak_df[p,3],
                                     absolutearea = FALSE,
                                     na.rm = FALSE)

          peak_area_vector[p] <- peak_area_vector[p] - (peak_df[p,3] - peak_df[p,1]) * min(peak_df[p,4], peak_df[p,6])
        }

        peak_df <- cbind(peak_df, peak_area_vector)

        #rename peak_df columns

        colnames(peak_df) <- c(paste(name_vec[m], "start.seconds", sep = "."),
                               paste(name_vec[m], "apex.seconds", sep = "."),
                               paste(name_vec[m], "end.seconds", sep = "."),
                               paste(name_vec[m], "start_intensity", sep = "."),
                               paste(name_vec[m], "apex_intensity", sep = "."),
                               paste(name_vec[m], "end_intensity", sep = "."),
                               paste(name_vec[m], "peak.area", sep = "."))

        ######3.10.4 Filter peaks######

        #Filter peaks based on smallest mt difference

        #Determine the expected migration times of the metabolites

        n <- m - num_of_is
        left_is <- paste(mi_df$left_is[n], ".apex.seconds", sep ="")
        right_is <- paste(mi_df$right_is[n], ".apex.seconds", sep ="")
        rmt_is <- paste(mi_df$description[n], ".apex.seconds", sep ="")

        if(mi_df$description[n] == "mi"){

          mf_vec <- mi_df[n,5:ncol(mi_df)] %>%
            unlist() %>%
            unname()

          expected_mt <- mf_vec * (is_mt_df[,which(colnames(is_mt_df) == right_is)] - is_mt_df[,which(colnames(is_mt_df) == left_is)]) + is_mt_df[,which(colnames(is_mt_df) == left_is)]

        }else{

          mf_vec <- mi_df[n,5:ncol(mi_df)] %>%
            unlist() %>%
            unname()

          expected_mt <- mf_vec * is_mt_df[,which(colnames(is_mt_df) == rmt_is)]

        }

        #Filter peak_df for peaks within migration time tolerance

        migration_window <- mass_df$migration.window.seconds[m - num_of_is]

        for (i in 1:num_of_injections){

          peaks <- peak_df %>%
            filter(., peak_df[,2] <= expected_mt[i] + migration_window &
                     peak_df[,2] >= expected_mt[i] - migration_window)

          #If more than one peak is found choose the nearest one

          if(nrow(peaks) > 1){
            peaks <- (peak_df[,2] - expected_mt[i]) %>%
              abs() %>%
              which.min(.)
            peaks <- peak_df[peaks,]
          }

          #If no peak is found, generate a place holder

          if(nrow(peaks) == 0){

            nearest_mt <- (eie_df$mt.seconds - expected_mt[i]) %>%
              abs() %>%
              which.min(.)

            peaks <- data.frame(eie_df[nearest_mt,1],
                                eie_df[nearest_mt,1],
                                eie_df[nearest_mt,1],
                                eie_df[nearest_mt,m + 1],
                                eie_df[nearest_mt,m + 1],
                                eie_df[nearest_mt,m + 1],
                                0)

            colnames(peaks) <- colnames(peak_df)
          }

          if(i == 1){
            filtered_peaks_df <- peaks
          }else{
            filtered_peaks_df <- rbind(filtered_peaks_df, peaks)
          }
        }

        ######3.10.5 Filter peaks outside of run time limits######

        #Set a place holder for peaks where the expected migration time > total run time

        total_run_time <- eie_df$mt.seconds[nrow(eie_df)]

        late_peaks <- (expected_mt > total_run_time) %>%
          which()

        #Find migration times to use as placeholders that do not belong to other identified peaks

        mt <- tail(eie_df$mt.seconds, n = 15)

        mt <- mt[!(mt %in% filtered_peaks_df[,2])]

        for (i in late_peaks){
          mt_temp <- mt[i]
          filtered_peaks_df[i,] <- c(mt_temp,
                                     mt_temp,
                                     mt_temp,
                                     eie_df[which(eie_df$mt.seconds == mt_temp) ,m + 1],
                                     eie_df[which(eie_df$mt.seconds == mt_temp) ,m + 1],
                                     eie_df[which(eie_df$mt.seconds == mt_temp) ,m + 1],
                                     0)
        }


        ######3.10.6 Filter duplicated peaks######

        #If the same peak is assigned to multiple injection numbers, reapply rmt filter with more austere rmt tolerances
        #New rmt tolerance will be the original / count, which starts at 2 and increases by 1 each iteration

        count = 2

        while (any(duplicated(filtered_peaks_df[,2])) & count < 100){

          strict_migration_window <- migration_window/count

          #find rows with duplicated values

          duplicate_location <- filtered_peaks_df[,2] %>%
            duplicated() %>%
            which()

          duplicate_rows <- which(filtered_peaks_df[,2] %in% filtered_peaks_df[duplicate_location,2])

          #reapply filtering for these peaks with the more strict rmt tolerance

          for (r in duplicate_rows){

            peaks <- peak_df %>%
              filter(., peak_df[,2] <= expected_mt[r] + strict_migration_window &
                       peak_df[,2] >= expected_mt[r] - strict_migration_window)

            #If more than one peak is found choose the nearest one

            if(nrow(peaks) > 1){
              peaks <- (peak_df[,2] - expected_mt[r]) %>%
                abs() %>%
                which.min(.)
              peaks <- peak_df[peaks,]
            }

            #If no peak is found, generate a place holder

            if(nrow(peaks) == 0){

              nearest_mt <- (eie_df$mt.seconds - expected_mt[r]) %>%
                abs() %>%
                which.min(.)

              peaks <- data.frame(eie_df[nearest_mt,1],
                                  eie_df[nearest_mt,1],
                                  eie_df[nearest_mt,1],
                                  eie_df[nearest_mt,m + 1],
                                  eie_df[nearest_mt,m + 1],
                                  eie_df[nearest_mt,m + 1],
                                  0)

              colnames(peaks) <- colnames(peak_df)
            }

            filtered_peaks_df[r,] <- peaks

          }

          count = count + 1
        }

        #If the duplicate peak filter fails (count = 100) then generate a place holder peak_df
        #and generate a warning that the filter failed. This filter fails when two or more expected migration
        #times are too close to each other.

        if (count == 100){

          mt.temp <- eie_df$mt.seconds[seq(1, num_of_injections * 10, 10)]

          filtered_peaks_df[,c(1:3)] <- mt.temp
          filtered_peaks_df[,c(4:7)] <- 0

        }

        ######3.10.7 Filter using peak spaces######

        #Do not apply peak space filtering if the number of injections is equal to 1

        if(num_of_injections != 1){

          #Get peak space tolerance

          space_tol <- mass_df$peak.space.tolerance.percent[m - num_of_is] / 100

          #Make a vector containing all the expected space lengths

          space_vec <- expected_mt %>%
            diff()

          #Define upper and lower peak space limits

          space_lower_lim <- space_vec - space_vec * space_tol
          space_upper_lim <- space_vec + space_vec * space_tol

          #Check if peaks migrate within the tolerance limits

          peak_space_tol_check <- between(diff(filtered_peaks_df[,2]), space_lower_lim, space_upper_lim)

          if(all(peak_space_tol_check) != TRUE){
            bad_space <- which(peak_space_tol_check == FALSE)
          }else{
            bad_space <- NA
          }

          #identify which peaks are potentially incorrectly assigned (bad peaks)
          #these are peaks before and after each bad space

          bad_peaks <- c(bad_space, bad_space + 1) %>%
            unique() %>%
            sort()

          #Define a count that will be used to modify the peak space tolerance

          count = 4

          #Keep unaltered filtered peaks data frame for the event that the peak space algorithm fails

          filtered_peaks_df_retain <- filtered_peaks_df

          #set count limit to determine when the algorithm fails

          count_limit = 100

          #Identify bad peaks, and replace them with peaks meeting peak space criteria
          #If the number of bad peaks is equal to the number of injections, do not apply this filter

          while(length(bad_peaks) > 0 & length(bad_peaks) < (num_of_injections - 1) & count < count_limit){

            #define remaining peaks which are correctly assigned (good peaks)

            good_peaks <- c(1:num_of_injections) %>%
              setdiff(., c(bad_peaks))

            #Use the median of the expected peak space times to find peaks

            peak_tolerance <- expected_mt %>%
              diff() %>%
              median () / count

            for (b in 1:length(bad_peaks)){

              #find the nearest good peak neighbor for each bad peak

              nearest_good_peak <- (good_peaks - bad_peaks[b]) %>%
                abs() %>%
                which.min()

              #calculate the expected migration time

              expected_mt <- filtered_peaks_df[good_peaks[nearest_good_peak], 2] -
                (good_peaks[nearest_good_peak] - bad_peaks[b]) * median(space_vec)

              #find peaks nearest to the expected migration time within the tolerance

              peaks <- peak_df %>%
                filter(., peak_df[,2] <= expected_mt + peak_tolerance & peak_df[,2] >= expected_mt - peak_tolerance)

              #if more than one peak is found, select the closest one

              if(nrow(peaks) > 1){
                peaks <- (peak_df[,2] - expected_mt) %>%
                  abs() %>%
                  which.min(.)
                peaks <- peak_df[peaks,]
              }

              #if no peaks are found, define a place holder

              if(nrow(peaks) == 0){

                nearest_mt <- (eie_df$mt.seconds - expected_mt) %>%
                  abs() %>%
                  which.min(.)

                peaks <- data.frame(eie_df[nearest_mt,1],
                                    eie_df[nearest_mt,1],
                                    eie_df[nearest_mt,1],
                                    eie_df[nearest_mt,m + 1],
                                    eie_df[nearest_mt,m + 1],
                                    eie_df[nearest_mt,m + 1],
                                    0)

                colnames(peaks) <- colnames(peak_df)

                filtered_peaks_df[bad_peaks[b],] <- peaks
              }

              #if only one peak is found

              filtered_peaks_df[bad_peaks[b],] <- peaks

            }

            count = count + 1

            duplicate_location <- filtered_peaks_df[,2] %>%
              duplicated() %>%
              which()

            #bad peaks correspond to any rows that are not unique

            bad_peaks <- which(filtered_peaks_df[,2] %in% filtered_peaks_df[duplicate_location,2])

          }

          #if algorithm failed, revert back to filtered_peaks_df

          if (count == count_limit){

            filtered_peaks_df <- filtered_peaks_df_retain

          }
        }

        #Summarize filtered.peak_df data in metabolite_peak_df

        if(m == (num_of_is + 1)){
          metabolite_peaks_df = filtered_peaks_df
        }else{
          metabolite_peaks_df = cbind(metabolite_peaks_df, filtered_peaks_df)
        }

      }

      metabolite_peaks_df

    })

    metabolite_peaks_df
  }

  ######3.10.8 Filter peaks below LOD######
  # Annotate metabolite peaks below the noise threshold or with no detection.
  flag_peaks_below_lod <- function(eie_df, metabolite_peaks_df, mass_df, num_of_is, num_of_metabolites, num_of_injections) {
    #Build a data frame to store comments for each metabolite peak

    comment_df <- matrix(nrow = num_of_injections, ncol = num_of_metabolites, "") %>%
      as.data.frame

    colnames(comment_df) <- mass_df$name

    #Loop through each metabolite and see if its area is below the LOD threshold

    for (m in 1:num_of_metabolites){

      #Determine the noise of the electropherogram
      #Fine the noise levels in 60 seconds intervals

      region_start <- seq(1, nrow(eie_df), 60)
      region_end <- seq(60, nrow(eie_df), 60)
      length(region_start) <- length(region_end)

      #Generate a vector to store noise data

      noise_vec <- rep(NA, length(region_start))

      #Define a function to calculate noise

      noise_calculation <- function(temp_noise) {
        mean(temp_noise) + mass_df$snr.threshold[m] * sd(temp_noise)
      }

      #Calculate the noise in each region

      for (r in 1:length(region_start)){
        temp_noise <- eie_df[region_start[r]:region_end[r], m + num_of_is + 1]
        noise_vec[r] <- noise_calculation(temp_noise)
      }

      #Define the noise as the 20th percentile noise region

      noise <- noise_vec %>%
        sort()

      noise <- noise[as.integer(length(noise)/5)]

      peak_area_df <- metabolite_peaks_df[,seq(7, ncol(metabolite_peaks_df), 7)]

      comment_df[,m] <- ifelse(peak_area_df[,m] < noise, "<LOD", comment_df[,m])

      ###Annotate injections that are not detected

      comment_df[,m] <- ifelse(peak_area_df[,m] == 0, "NPD", comment_df[,m])

    }

    comment_df
  }

  ######3.10.9 Filter interfered peaks######
  # Flag co-migration interference and combine standard/metabolite tables.
  flag_interfered_peaks <- function(comment_df, is_peaks_df, metabolite_peaks_df, mass_df, is_df, name_vec, num_of_metabolites, num_of_injections) {
    #Build an interference data frame since some are metabolites and some are internal standards

    interference_df <- cbind(is_peaks_df[,seq(2, ncol(is_peaks_df), 7)],
                             metabolite_peaks_df[,seq(2, ncol(metabolite_peaks_df), 7)])

    for (m in 1:num_of_metabolites){

      #Skip metabolites with no reported interference

      if(is.na(mass_df$interference[m])){
        next
      }

      #Get the names of the interferences from mass_df

      interferences <- strsplit(mass_df$interference[m], ", ") %>%
        unlist()

      for (k in 1:length(interferences)){

        interference <- paste(interferences[k], ".apex.seconds", sep = "")

        #Check if interference appears as a metabolite or internal standard.
        #If not, provide a warning

        if(!(interferences[k] %in% name_vec)){
          print(paste("Error: ", "Interference ", interferences[k], " is not an analyte or internal standard", sep = ""))
        }

        #Check if a interference window was provided. If not, produce an error.

        if(is.na(mass_df$interference.comigration.threshold.seconds[m])){
          print(paste("Error: No interference.comigration.threshold.seconds provided for ", mass_df$name[m], sep = ""))
        }

        #See if there is any overlap between the metabolite peak and its interference

        metabolite_name <- paste(mass_df$name[m], ".apex.seconds", sep = "")

        for (i in 1:num_of_injections){
          for (j in 1:num_of_injections){

            diff_temp <- (metabolite_peaks_df[i,metabolite_name] - interference_df[j,interference]) %>%
              abs()

            comment_df[i,mass_df$name[m]] <- ifelse(diff_temp < mass_df$interference.comigration.threshold.seconds[m], "Interfered", comment_df[i,mass_df$name[m]])
          }
        }
      }
    }

    #Combine internal standard and metabolite data frames for plotting

    peaks_df <- cbind(is_peaks_df, metabolite_peaks_df)

    #update comment data frame account for internal standards

    is_comment_df <- matrix(nrow = num_of_injections, ncol = nrow(is_df), "") %>%
      as.data.frame()

    colnames(is_comment_df) <- is_df$name

    comment_df <- cbind(is_comment_df, comment_df)


    print("Peak Picking and Filtering for Analytes Complete")

    list(peaks_df = peaks_df, comment_df = comment_df)
  }

  #####3.11 Plotting#####
  # Build annotations, integration ribbons and axes for every trace.
  build_plot_data <- function(eie_df, peaks_df, comment_df, name_vec, mz_vec, num_of_injections) {
    #Make a list to save plots to

    plot_list <- vector("list", length(name_vec))
    names(plot_list) <- name_vec

    for (n in 1:length(name_vec)){

      ######3.11.1 Create annotation and peak fill data frame######

      peak_mt_df <- peaks_df[,seq(from = 2, to = ncol(peaks_df), by = 7)]

      ann_df <- data.frame("peak.number" = c(1:num_of_injections),
                           "comment" = comment_df[,n],
                           "peak.apex.seconds" = peak_mt_df[,n],
                           "peak.height.counts" = eie_df[which(eie_df$mt.seconds %in% (peak_mt_df[,n])),n+1])

      #Create peak fill data frame

      pf_df <- data.frame("peak.number" = 1,
                          "mt.seconds" = eie_df[,1],
                          "intensity" = eie_df[,n+1])

      mt_vec <- vector()
      start_df <- peaks_df[,seq(from = 1, to = ncol(peaks_df), by = 7)]
      end_df <- peaks_df[,seq(from = 3, to = ncol(peaks_df), by = 7)]

      for (i in 1:num_of_injections){

        #Create a migration time vector to track where peaks elute

        if(comment_df[i,n] == ""){
          mt_vec_temp <- eie_df$mt.seconds[between(eie_df$mt.seconds, start_df[i,n], end_df[i,n])]
          mt_vec <- append(mt_vec, mt_vec_temp)

          #Update peak.number in pf_df

          pf_df$peak.number <- ifelse(pf_df$mt.seconds >= start_df[i,n], i, pf_df$peak.number)
          pf_df$peak.number <- as.factor(pf_df$peak.number)
        }else{
          next
        }
      }

      pf_df$intensity <- ifelse(pf_df$mt.seconds %in% mt_vec == TRUE, pf_df$intensity , 0)

      ##Add baseline intensity

      pf_df$baseline <- 0

      for (i in 1:num_of_injections){
        if(comment_df[i,n] == ""){
          lower_intensity <- min(c(peaks_df[i, n * 7 - 3], peaks_df[i, n * 7 - 1]))
          pf_df$baseline <- ifelse(pf_df$mt.seconds >= start_df[i,n] & pf_df$mt.seconds <= end_df[i,n], lower_intensity, pf_df$baseline)
        }else{
          next
        }
      }

      #Only retain filling data required for plotting

      pf_df <- subset(pf_df, pf_df$intensity != 0)

      #Save variables to a list

      plot_list[[name_vec[n]]] <- list("eie_data" = eie_df[,c(1,(n + 1))], 
                                       "annotation_data" = ann_df, 
                                       "integration_data" = pf_df,
                                       "label_data" = c(name_vec[n],
                                                        mz_vec[n]),
                                       "x_axis_data" = c(start_df[1,n],
                                                         end_df[num_of_injections,n]),
                                       "y_axis_data" = c(max(ann_df$peak.height.counts), 
                                                         max(eie_df[,(n + 1)])))

    }

    plot_list
  }

  ######3.11.2 Create plot function for ggplots######
  # Save PNG plots in the existing Sample or Metabolite folder layout.
  save_static_plots <- function(plot_list, eie_df, mi_df, parameters_df, name_vec, num_of_is, file_name, file_stem, raw_path) {
    plot_function <- function(eie_data, annotation_data, integration_data, label_data, x_axis_data, y_axis_data){

      extra_space <- ifelse(x_axis_data[1] > 70, 1, 0)

      ggplot(data = eie_data) +
        geom_line(aes(x = mt.seconds / 60, y = eie_data[,2]), colour = "grey50") +
        theme_classic() +
        coord_cartesian(xlim = c(x_axis_data[1] / 60 - extra_space, x_axis_data[2] / 60 + extra_space),
                        ylim = c(0, 1.5 * y_axis_data[1])) +
        scale_y_continuous(name = "Ion Counts",
                           labels = function(x) format(x, scientific = TRUE),
                           expand = c(0,0),
                           breaks = scales::pretty_breaks(n = 10)) +
        scale_x_continuous(name = "Migration Time (Minutes)",
                           breaks = scales::pretty_breaks(n = 10))+
        ggtitle(paste(label_data[1], " EIE", " (m/z = ", label_data[2],")",sep = ""),
                subtitle = paste("Data File: ", raw_path)) +
        geom_ribbon(data = integration_data,
                    aes(x = mt.seconds/60, ymax = intensity, ymin = baseline, fill = peak.number),
                    alpha =0.4) +
        geom_text(data = annotation_data,
                  label = annotation_data$peak.number,
                  size  = font_size_1,
                  family = "sans",
                  aes(x = peak.apex.seconds/60,
                      y = peak.height.counts + 0.1 * y_axis_data[1])) +
        geom_text(data = annotation_data,
                  label = annotation_data$comment,
                  size  = font_size_1,
                  family = "sans",
                  aes(x = peak.apex.seconds/60,
                      y = peak.height.counts + 0.2 * y_axis_data[1])) +
        theme(legend.position = "none",
              text = element_text(size = font_size_2, family = "sans"))

    }

    ######3.11.3 Create Plot Function for making plotly plots######
    # Reorganized: the Plotly factory is now nested in build_interactive_plots(),
    # in section 3.11.6 below. Keep this marker in its original section order
    # without moving executable code out of its current task functions.

    ######3.11.4 Initialize Saving Locations and Folders######
    # Shared Plots/Data setup is in prepare_results_folder(); Sample plot
    # subfolders are created here, and Metabolite folders by that helper.
    if (parameters_df$plot.format == "Sample"){


      #Create sub-folders

      dir.create(file.path(file_name, "Plots", "Analytes"), showWarnings = FALSE)
      dir.create(file.path(file_name, "Plots", "Internal Standards"), showWarnings = FALSE)

      dir.create(path = paste(file_name, "/Plots/", "Internal Standards", "/", file_stem, sep = ""),
                 showWarnings = TRUE)

      dir.create(path = paste(file_name, "/Plots/", "Analytes", "/", file_stem, sep = ""),
                 showWarnings = TRUE)

      ######3.11.5 Save plots as ggplots######
      #Save Internal Standard Plots

      plotly_plots <- list()

      for (n in 1:num_of_is){

        folder <- "Internal Standards"
        name <- name_vec[n]

        font_size_1 <- 7
        font_size_2 <- 25

        ggsave(filename = paste(n, "_", name,".png",sep=""),
               width = 16,
               height = 9,
               plot = plot_function(eie_data = plot_list[[n]][[1]],
                                    annotation_data = plot_list[[n]][[2]],
                                    integration_data = plot_list[[n]][[3]],
                                    label_data = plot_list[[n]][[4]],
                                    x_axis_data = plot_list[[n]][[5]],
                                    y_axis_data = plot_list[[n]][[6]]),
               path = paste(file_name, "/Plots/", folder, "/", file_stem, sep = ""))

      }

      #Save Analyte Plots

      for (n in (num_of_is + 1):length(name_vec)){

        folder <- "Analytes"
        name <- name_vec[n]

        #Analytes using RMT

        if (mi_df$description[n - num_of_is] != "mi"){

          font_size_1 <- 4
          font_size_2 <- 12

          is_index <- which(name_vec == mi_df$description[(n - num_of_is)])

          figure <- ggarrange(plot_function(eie_data = plot_list[[n]][[1]],
                                            annotation_data = plot_list[[n]][[2]],
                                            integration_data = plot_list[[n]][[3]],
                                            label_data = plot_list[[n]][[4]],
                                            x_axis_data = c(min(eie_df$mt.seconds), max(eie_df$mt.seconds)),
                                            y_axis_data = plot_list[[n]][[6]][2]),
                              plot_function(eie_data = plot_list[[n]][[1]],
                                            annotation_data = plot_list[[n]][[2]],
                                            integration_data = plot_list[[n]][[3]],
                                            label_data = plot_list[[n]][[4]],
                                            x_axis_data = plot_list[[n]][[5]],
                                            y_axis_data = plot_list[[n]][[6]]),
                              plot_function(eie_data = plot_list[[is_index]][[1]],
                                            annotation_data = plot_list[[is_index]][[2]],
                                            integration_data = plot_list[[is_index]][[3]],
                                            label_data = plot_list[[is_index]][[4]],
                                            x_axis_data = plot_list[[n]][[5]],
                                            y_axis_data = plot_list[[is_index]][[6]]),
                              ncol = 1, nrow = 3)

          ggsave(filename = paste(n, "_", name,".png",sep=""),
                 width = 16,
                 height = 9,
                 plot = figure,
                 path = paste(file_name, "/Plots/", folder, "/", file_stem, sep = ""))
        }

        #Analytes using MI

        if (mi_df$description[n - num_of_is] == "mi"){

          font_size_1 <- 4
          font_size_2 <- 12

          is_index <- which(name_vec == mi_df$description[(n - num_of_is)])

          figure <- ggarrange(plot_function(eie_data = plot_list[[n]][[1]],
                                            annotation_data = plot_list[[n]][[2]],
                                            integration_data = plot_list[[n]][[3]],
                                            label_data = plot_list[[n]][[4]],
                                            x_axis_data = c(min(eie_df$mt.seconds), max(eie_df$mt.seconds)),
                                            y_axis_data = plot_list[[n]][[6]][2]),
                              plot_function(eie_data = plot_list[[n]][[1]],
                                            annotation_data = plot_list[[n]][[2]],
                                            integration_data = plot_list[[n]][[3]],
                                            label_data = plot_list[[n]][[4]],
                                            x_axis_data = plot_list[[n]][[5]],
                                            y_axis_data = plot_list[[n]][[6]]),
                              ncol = 1, nrow = 2)

          ggsave(filename = paste(n, "_", name,".png",sep=""),
                 width = 16,
                 height = 9,
                 plot = figure,
                 path = paste(file_name, "/Plots/", folder, "/", file_stem, sep = ""))
        }
      }
    }

    if (parameters_df$plot.format == "Metabolite"){

      #Save plots to their respective folders within the "Plots" folder

      #Save Plots
      for (n in 1:length(name_vec)){

        folder <- name_vec[n]

        font_size_1 <- 7
        font_size_2 <- 25

        ggsave(filename = paste(file_stem,".png",sep=""),
               width = 16,
               height = 9,
               plot = plot_function(eie_data = plot_list[[n]][[1]],
                                    annotation_data = plot_list[[n]][[2]],
                                    integration_data = plot_list[[n]][[3]],
                                    label_data = plot_list[[n]][[4]],
                                    x_axis_data = plot_list[[n]][[5]],
                                    y_axis_data = plot_list[[n]][[6]]),
               path = paste(file_name, "/Plots/", folder, "/", sep = ""))

      }
    }

    invisible(NULL)
  }

  ######3.11.6 Save plots as editable plotly plots######
  # Build the editable Plotly objects without publishing or saving them.
  # Saving the assembled list is delegated to save_interactive_plots().
  build_interactive_plots <- function(plot_list, mi_df, name_vec, num_of_is, file_stem) {
    # Implementation of the Plotly factory referenced by section 3.11.3.
    plot_function_plotly <- function(eie_data, annotation_data, integration_data, label_data, x_axis_data, y_axis_data, source = "A") {
      plot_ly(source = source) %>%
        add_lines(
          x = ~eie_data[,1] / 60,
          y = ~eie_data[,2],
          name = 'Electropherogram',
          line = list(color = 'grey')
        ) %>%
        add_ribbons(
          x = ~integration_data$mt.seconds / 60,
          ymin = ~integration_data$baseline,
          ymax = ~integration_data$intensity,
          fillcolor = 'rgba(100,100,255,0.4)',
          line = list(color = 'rgba(100,100,255,0.4)'),
          name = 'Peak Integration'
        ) %>%
        add_text(
          x = ~annotation_data$peak.apex.seconds / 60,
          y = ~annotation_data$peak.height.counts + (0.1 * y_axis_data[1]),
          text = ~annotation_data$peak.number,
          showlegend = FALSE
        ) %>%
        add_text(
          x = ~annotation_data$peak.apex.seconds / 60,
          y = ~annotation_data$peak.height.counts + (0.2 * y_axis_data[1]),
          text = ~annotation_data$comment,
          showlegend = FALSE
        ) %>%
        layout(
          title = paste(label_data[1], " EIE", " (m/z =", label_data[2], ")"),
          xaxis = list(title = 'Migration Time (Minutes)'),
          yaxis = list(title = 'Ion Counts'),
          template = 'plotly_white',
          shapes = list(
            list(
              type = "line",
              x0 = 2,  #Initial position of the red line
              y0 = 0,
              x1 = 2,
              y1 = 1,
              xref = "x",
              yref = "paper",
              line = list(color = "Red", width = 2)
            ),
            list(
              type = "line",
              x0 = 4,  #Initial position of the blue line
              y0 = 0,
              x1 = 4,
              y1 = 1,
              xref = "x",
              yref = "paper",
              line = list(color = "Blue", width = 2)
            )
          )
        ) %>% config(editable = TRUE)
    }

    plotly_objects <- list()
    #Save Internal Standard Plots to a list
    plotly_plots <- lapply(1:num_of_is, function(n) {

      name <- name_vec[n]

      plot <- plot_function_plotly(eie_data = plot_list[[n]][[1]],
                                   annotation_data = plot_list[[n]][[2]],
                                   integration_data = plot_list[[n]][[3]],
                                   label_data = plot_list[[n]][[4]],
                                   x_axis_data = plot_list[[n]][[5]],
                                   y_axis_data = plot_list[[n]][[6]])
      return(plot)
    })

    names(plotly_plots) <- sapply(1:num_of_is, function(n) {
      paste0(file_stem, "_", name_vec[n])
    })

    plotly_objects <- c(plotly_objects, plotly_plots)

    #Save Analyte Plots as Plotly Objects
    for (n in (num_of_is + 1):length(name_vec)) {

      name <- name_vec[n]

      #Analytes using RMT
      if (mi_df$description[n - num_of_is] != "mi") {

        is_index <- which(name_vec == mi_df$description[(n - num_of_is)])

        plotly_figure <- plot_function_plotly(
            eie_data = plot_list[[n]][[1]],
            annotation_data = plot_list[[n]][[2]],
            integration_data = plot_list[[n]][[3]],
            label_data = plot_list[[n]][[4]],
            x_axis_data = plot_list[[n]][[5]],
            y_axis_data = plot_list[[n]][[6]])

        #Build plotly object before saving them
        plotly_figure <- plotly::plotly_build(plotly_figure)

        #Name plots based on the file being processed and the metabolite
        plot_name <- paste0(file_stem, "_", name_vec[n])

        #Save the plotly object
        plotly_objects[[plot_name]] <- plotly_figure
      }

      #Saving Analytes using MI as plotly objects
      if (mi_df$description[n - num_of_is] == "mi") {

        plotly3 <- plot_function_plotly(
            eie_data = plot_list[[n]][[1]],
            annotation_data = plot_list[[n]][[2]],
            integration_data = plot_list[[n]][[3]],
            label_data = plot_list[[n]][[4]],
            x_axis_data = plot_list[[n]][[5]],
            y_axis_data = plot_list[[n]][[6]])

        #Build plotly object before saving them
        plotly3 <- plotly::plotly_build(plotly3)

        #Name plots based on the file being processed and the metabolite
        plot_name <- paste0(file_stem, "_", name_vec[n])

        #Save the plotly object
        plotly_objects[[plot_name]] <- plotly3
      }
    }

    plotly_objects
  }

  #####3.12 Export Data#####
  # Build the peak-area and migration-time reports with existing annotations.
  build_result_tables <- function(peaks_df, comment_df, name_vec, num_of_injections, file_stem) {
    ######3.12.1 Generate peak area data frame######
    peak_area_df <- cbind("file.name" = c(file_stem, rep("", num_of_injections - 1)),
                          "peak.number" = c(1:num_of_injections),
                          peaks_df[,seq(from = 7, to = ncol(peaks_df), by = 7)])
    colnames(peak_area_df)[3:(length(name_vec) + 2)] <- name_vec

    #Update values to include <LOD and Interfered

    for (i in 1:num_of_injections){
      peak_area_df[i,3:ncol(peak_area_df)] <- ifelse(comment_df[i,] == "", peak_area_df[i, 3:ncol(peak_area_df)], comment_df[i,])
    }



    ######3.12.2 Generate peak migration time data frame######

    peak_mt_df <- cbind("file.name" = c(file_stem, rep("", num_of_injections - 1)),
                        "peak.number" = c(1:num_of_injections),
                        peaks_df[,seq(from = 2, to = ncol(peaks_df), by = 7)] / 60)
    colnames(peak_mt_df)[3:(length(name_vec) + 2)] <- name_vec

    list(peak_area_df = peak_area_df, peak_mt_df = peak_mt_df)
  }

  # Check a full snapshot before any save can replace existing traces or tables.
  validate_analysis_snapshot <- function(plot_list, peaks_df, mi_df, peak_mt_df, peak_area_df, comment_df) {
    tables <- list(peaks_df = peaks_df, mi_df = mi_df, peak_mt_df = peak_mt_df,
                   peak_area_df = peak_area_df, comment_df = comment_df)
    invalid <- names(tables)[!vapply(tables, function(x) is.data.frame(x) || is.matrix(x), logical(1))]
    if (length(invalid)) stop("Saved analysis was not changed: incomplete snapshot (",
                             paste(invalid, collapse = ", "), ").", call. = FALSE)
    if (!is.list(plot_list) || !length(plot_list) || is.null(names(plot_list)) ||
        anyNA(names(plot_list)) || any(!nzchar(names(plot_list))) || anyDuplicated(names(plot_list))) {
      stop("Saved analysis was not changed: the snapshot has no valid named electropherograms.",
           call. = FALSE)
    }
    for (metabolite in names(plot_list)) {
      read_saved_electropherogram(plot_list, metabolite, "snapshot to be saved")
    }
    invisible(TRUE)
  }

  # Save the named RData objects used by Visualization and database migration.
  save_analysis_snapshot <- function(subfolder_path, plot_list, peaks_df, mi_df, peak_mt_df, peak_area_df, comment_df) {
    validate_analysis_snapshot(plot_list, peaks_df, mi_df, peak_mt_df, peak_area_df, comment_df)
    temporary <- tempfile(".peakmeister-snapshot-", tmpdir = subfolder_path, fileext = ".RData")
    on.exit(unlink(temporary), add = TRUE)
    save(plot_list, peaks_df, mi_df, peak_mt_df, peak_area_df, comment_df,
         file = temporary)
    if (!file.rename(temporary, file.path(subfolder_path, "plot_list_data.RData"))) {
      stop("Could not replace the saved analysis snapshot. The previous snapshot was kept.")
    }
  }

  # Write the existing SQLite schema; always close this writer connection.
  save_analysis_database <- function(file_name, file_stem, plot_list, peaks_df, peak_area_df, peak_mt_df, comment_df, mi_df) {
    #Create SQL database if one doesnt exist and save all data to it for each file.
    db_path_pipeline <- get_db_path(file_name)
    pipeline_con <- dbConnect(SQLite(), db_path_pipeline)
    on.exit(dbDisconnect(pipeline_con), add = TRUE)
    dbExecute(pipeline_con, "PRAGMA journal_mode = WAL")

    initialize_db(pipeline_con)

    for (tbl in c("annotation_data", "integration_data","plot_axis_data", "peaks_df","peak_area_df","peak_mt_df")){
      dbExecute(pipeline_con,
                paste0("DELETE FROM ", tbl, " WHERE file_name = ?"),
                params = list(file_stem)
      )
    }
    #Write data to SQL database
    write_file_to_db(
      con          = pipeline_con,
      file_name    = file_stem,
      plot_list    = plot_list,
      peaks_df     = peaks_df,
      peak_area_df = peak_area_df,
      peak_mt_df   = peak_mt_df,
      comment_df   = comment_df,
      mi_df        = mi_df
    )

    print(paste("database write complete for:", file_stem))
  }

  ######3.12.3 Export data######
  # Export the per-file reports without changing their names or column formats.
  export_result_csvs <- function(file_name, peak_area_df, peak_mt_df) {
    write.csv(peak_area_df, file.path(file_name, "Metabolite Peak Areas.csv"), row.names = FALSE)
    write.csv(peak_mt_df, file.path(file_name, "Metabolite Migration Times.csv"), row.names = FALSE)
  }

  # Save the Plotly object list in the existing RData format.
  save_interactive_plots <- function(file_name, plotly_objects) {
    save(plotly_objects, file = file.path(file_name, "plotly_objects.RData"))
  }

  # Run one file through the task functions in the original processing order.
  process_mz5_file <- function(raw_path, filename, file_name, config, timing) {
    mass_df <- config$mass_df
    is_df <- config$is_df
    parameters_df <- config$parameters_df
    name_vec <- config$name_vec
    num_of_is <- config$num_of_is
    num_of_metabolites <- config$num_of_metabolites
    num_of_injections <- config$num_of_injections
    mi_df <- config$mi_df
    file_stem <- gsub(".mz5", "", filename, fixed = TRUE)
    subfolder_path <- file.path(file_name, "Data", filename)
    dir.create(subfolder_path, showWarnings = FALSE, recursive = TRUE)
    temporary_file <- paste(gsub(".mz5", "", raw_path), "temp.mz5", sep = "_")

    withProgress(message = paste("Processing data file:", filename), value = 0, {
      total_steps <- 7
      timing$stage("Copy mz5 file", filename)
      file.copy(raw_path, to = temporary_file)
      on.exit(unlink(temporary_file), add = TRUE)
      timing$stage("Read mz5 into memory", filename)
      run_data <- read_mz5_data(temporary_file, total_steps)
      timing$stage("Mass calibration (if enabled)", filename)
      run_data <- calibrate_masses(run_data, parameters_df, total_steps)

      timing$stage("Prepare extraction windows and spectra", filename)
      extraction <- prepare_extraction_spectra(run_data, is_df, mass_df, total_steps)
      timing$stage("Extract electropherograms", filename)
      electropherograms <- extract_electropherograms(extraction$run_data, extraction$mzr)
      mz_vec <- extraction$mz_vec
      timing$stage("Build eie_df", filename)
      eie_df <- build_eie_dataframe(electropherograms, name_vec)
      rm(run_data, extraction, electropherograms)
      timing$stage("Smooth electropherograms (if enabled)", filename)
      eie_df <- smooth_electropherograms(
        eie_df, is_df, mass_df, parameters_df, name_vec, total_steps)

      timing$stage("Internal standard peak detection, integration and filtering", filename)
      is_peaks_df <- process_internal_standard_peaks(
        eie_df, is_df, parameters_df, name_vec, num_of_is,
        num_of_injections, total_steps)
      is_mt_df <- is_peaks_df[, seq(from = 2, to = ncol(is_peaks_df), by = 7)]
      timing$stage("Metabolite peak detection, integration and filtering", filename)
      metabolite_peaks_df <- process_metabolite_peaks(
        eie_df, mass_df, is_df, is_mt_df, mi_df, name_vec, num_of_is,
        num_of_injections, total_steps)
      timing$stage("Filter peaks below LOD", filename)
      comment_df <- flag_peaks_below_lod(
        eie_df, metabolite_peaks_df, mass_df, num_of_is,
        num_of_metabolites, num_of_injections)
      timing$stage("Filter interfered peaks", filename)
      flagged <- flag_interfered_peaks(
        comment_df, is_peaks_df, metabolite_peaks_df, mass_df, is_df,
        name_vec, num_of_metabolites, num_of_injections)
      peaks_df <- flagged$peaks_df
      comment_df <- flagged$comment_df

      timing$stage("Generate and save plots", filename)
      incProgress(1/total_steps, detail = "Plotting & Exporting Electropherograms")
      plot_list <- build_plot_data(
        eie_df, peaks_df, comment_df, name_vec, mz_vec, num_of_injections)
      save_static_plots(plot_list, eie_df, mi_df, parameters_df,
                        name_vec, num_of_is, file_name, file_stem, raw_path)
      plotly_objects <- build_interactive_plots(plot_list, mi_df, name_vec, num_of_is, file_stem)
      plotly_data(plotly_objects)

      timing$stage("Prepare result tables", filename)
      tables <- build_result_tables(
        peaks_df, comment_df, name_vec, num_of_injections, file_stem)
      timing$stage("Save plot_list_data.RData", filename)
      save_analysis_snapshot(subfolder_path, plot_list, peaks_df, mi_df,
                             tables$peak_mt_df, tables$peak_area_df, comment_df)
      timing$stage("Write SQLite results", filename)
      save_analysis_database(file_name, file_stem, plot_list, peaks_df,
                             tables$peak_area_df, tables$peak_mt_df, comment_df, mi_df)
      timing$stage("Remove temporary mz5 file", filename)
      file.remove(temporary_file)
      timing$stage("Export CSV reports", filename)
      export_result_csvs(file_name, tables$peak_area_df, tables$peak_mt_df)
      timing$stage("Save plotly_objects.RData", filename)
      save_interactive_plots(file_name, plotly_objects)
      timing$finish()
    })
  }

  # Coordinate the uploaded files and preserve per-file timing/error reports.
  run_new_analysis <- function(files, mass_df, is_df, parameters_df, user_mti_df) {
    file_name <- create_results_folder(files$FileName[1])
    start_timer <- function(folder) {
      new_run_timer(file.path(folder, "run_timings.csv"), notify = function(stage, file) {
        if (nzchar(file)) shiny::setProgress(detail = stage)
      })
    }
    timing <- start_timer(file_name)
    tryCatch({
      timing$stage("Validate parameters and calculate migration indexes")
      config <- prepare_analysis_parameters(mass_df, is_df, parameters_df, user_mti_df)
      prepare_results_folder(file_name, mass_df, is_df, parameters_df, config$mi_df)
      for (d in seq_len(nrow(files))) {
        if (d > 1L) {
          file_name <- create_results_folder(files$FileName[d])
          timing <- start_timer(file_name)
          timing$stage("Prepare output folders")
          prepare_results_folder(file_name, mass_df, is_df, parameters_df, config$mi_df)
        }
        process_mz5_file(files$FilePath[d], files$FileName[d], file_name, config, timing)
      }
      timing$finish()
    }, error = function(e) {
      timing$finish("failed", conditionMessage(e))
      stop(e)
    }, interrupt = function(e) {
      timing$finish("interrupted", "Run interrupted")
      stop(e)
    })
  }

  # Initialize Run action for reorganized section 3.2: validate the selection,
  # then call the workflow. Its numbered marker remains before section 3.3.
  observe_action(input$initialize, {
    if (analysis_mode() != "new") {
      shiny::showNotification("Choose New analysis to process raw files.", type = "error")
      return(NULL)
    }
    files <- uploadedmz5()
    if (!nrow(files) || !valid_mz5_names(files$FileName) || any(files$Source != "upload") ||
        anyNA(files$FilePath) || !all(file.exists(files$FilePath))) {
      shiny::showNotification("Upload real .mz5 files for a new analysis. Saved-analysis selections cannot be processed.", type = "error")
      return(NULL)
    }

    run_new_analysis(files, massData(), refMassListData(), parametersData(), userMTI())
  })

  ####4. Visualization tab####
  
  #####4.1 Define reactive expressions and specific required functions#####
  ######4.1.1 Define Reactive expressions######
  plot_list_data_values <- reactiveValues(
    plot_list      = NULL,
    comment_df     = NULL,
    peaks_df       = NULL,
    peak_mt_df     = NULL,
    peak_area_df   = NULL,
    mi_df          = NULL,
    file_name      = NULL
  )
  
  #Define reactive values for storing information from plot_list_data.Rdata
  run_metadata <- reactiveValues(
    comment_df    = NULL,
    plot_list     = NULL,
    peaks_df      = NULL,
    peak_mt_df    = NULL,
    peak_area_df  = NULL,
    mi_df         = NULL,
    file_name     = NULL
  )
  
  #Define reactive expression to store unaltered peak information to allow users to undo a deletion if a peak is deleted accidentally 
  previous_metadata <- reactiveValues(
    comment_df    = NULL,
    plot_list     = NULL,
    peaks_df      = NULL,
    peak_mt_df    = NULL,
    peak_area_df  = NULL,
    mi_df         = NULL,
    file_name     = NULL
  )
  
  #Reactive expression to store the path to the selected results folder. Required to grab the correct annotation_data information from the subsequent runs and useful for processing data if you have closed the app.
  editing_context <- reactiveVal(NULL)
  edit_history_trigger <- reactiveVal(0L)
  peak_edit_in_progress <- reactiveVal(FALSE)

  main_folder <- reactive({
    context <- editing_context()
    if (!is.null(context) && identical(input$results_folder, context$selected_folder)) return(context$folder)
    req(input$results_folder, input$results_folder %in% results_folders_reactive() ||
          file.exists(file.path(input$results_folder, ".peakmeister-edit-copy.rds")))
    input$results_folder
  })
  
  #Reactive expression to store the path to the selected results folder
  plot_list_data <- reactive({
    req(main_folder(), input$file_selector)
    file_name <- input$file_selector
    subfolder_path <- file.path(main_folder(), "Data", file_name)
    
    #Check if the file exists before attempting to load it
    if (file.exists(file.path(subfolder_path, "plot_list_data.RData"))) {
      load(file.path(subfolder_path, "plot_list_data.RData"))
      return(list(plot_list = plot_list, peaks_df = peaks_df, peak_mt_df = peak_mt_df, peak_area_df = peak_area_df, comment_df = comment_df, mi_df = mi_df))
    } else {
      warning("File not found: ", file.path(subfolder_path, "plot_list_data.RData"))
      return(NULL)
    }
  })

  
  #Reactive expression to get the plot names associated with a specified .mz5 file from the SQL database, based on the naming pattern.
  filtered_plot_names <- reactive({
    req(db_con(), input$file_selector, main_folder())
    con       <- db_con()
    file_name <- sub("\\.mz5$", "", input$file_selector)
    tryCatch({
      metabolites <- dbGetQuery(con,
                                "SELECT DISTINCT metabolite FROM plot_axis_data
         WHERE file_name = ?
         ORDER BY metabolite",
                                params = list(file_name)
      )$metabolite
      #Return in same format as before: "<file>_<metabolite>"
      paste0(file_name, "_", metabolites)
    }, error = function(e) character(0))
  })
  
  
  #Variable to save edited plot names for rerendering without rerendering ALL plots
  modified_peak_plots <- reactiveValues(names = character())
  
  #Variable to trigger plots reloading after editing them
  plot_render_trigger <- reactiveVal(0)
  
  
  ######4.1.2 SQL Database functions######
  
  #Database path helper 
  get_db_path <- function(results_folder) {
    file.path(results_folder, "results.sqlite")
  }
  
  #Check if database exists in results folder
  db_exists <- function(results_folder){
    file.exists(get_db_path(results_folder))
  }
  
  #Function for connection to the database
  open_db <- function(results_folder){
    con <- dbConnect(RSQLite::SQLite(), get_db_path(results_folder))
    #enable write-ahead logging for better performance
    dbExecute(con, "PRAGMA journal_mode = WAL")
    return(con)
  }
  
  #Function for initializing the SQL database, creating all tables and indexes for increased efficiency.
  initialize_db <- function(con){
    
  #Create tables for storing all components of the plot_list_data RData file/ allrequired files generated from running the main peakmeister loop  
    #Table for annotation data
    dbExecute(con, "CREATE TABLE IF NOT EXISTS annotation_data (
              file_name       TEXT NOT NULL,
              metabolite      TEXT NOT NULL,
              peak_number      INTEGER NOT NULL,
              comment         TEXT,
              peak_apex_secs  REAL,
              peak_height     
              )")
    #Table for integration data
    dbExecute(con, "CREATE TABLE IF NOT EXISTS integration_data (
              file_name     TEXT NOT NULL,
              metabolite    TEXT NOT NULL,
              peak_number   INTEGER NOT NULL,
              mt_seconds    REAL NOT NULL,
              intensity     REAL NOT NULL,
              baseline      REAL NOT NULL
    )")
    #Table for storing x_axis_data, y_axis_data, and label_data components from plot_list
    dbExecute(con, "CREATE TABLE IF NOT EXISTS plot_axis_data (
              file_name     TEXT NOT NULL,
              metabolite    TEXT NOT NULL,
              x_start       REAL,
              x_end         REAL,
              y_max_annot   REAL,
              y_max_eie     REAL,
              label_name    TEXT,
              label_mz      TEXT
    )")
    #Table for storing peak_df from peakmeister enginine loop
    dbExecute(con, "CREATE TABLE IF NOT EXISTS peaks_df (
              file_name       TEXT NOT NULL,
              metabolite      TEXT NOT NULL,
              peak_number     INTEGER NOT NULL,
              start_seconds   REAL,
              apex_seconds    REAL,
              end_seconds     REAL,
              start_intensity REAL,
              apex_intensity  REAL,
              end_intensity   REAL,
              peak_area       TEXT
    )")
    #Table for storing peak_area_df information
    dbExecute(con, "CREATE TABLE IF NOT EXISTS peak_area_df (
              file_name     TEXT NOT NULL,
              peak_number   INTEGER NOT NULL,
              metabolite    TEXT NOT NULL,
              peak_area     TEXT
    )")
    #Table for storing peak_mt_df information
    dbExecute(con, "CREATE TABLE IF NOT EXISTS peak_mt_df (
              file_name       TEXT NOT NULL,
              peak_number     INTEGER NOT NULL,
              metabolite      TEXT NOT NULL,
              migration_time  REAL
    )")
    #Table for storing mi_df information
    dbExecute(con, "CREATE TABLE IF NOT EXISTS mi_df (
              metabolite    TEXT NOT NULL,
              left_is       TEXT,
              right_is      TEXT,
              description   TEXT,
              peak_indices  TEXT
    )")
    #Table for tracking edits
    dbExecute(con, "CREATE TABLE IF NOT EXISTS edit_log(
              id            INTEGER PRIMARY KEY AUTOINCREMENT,
              file_name     TEXT NOT NULL,
              metabolite    TEXT_NOT_NULL,
              edit_type     TEXT NOT NULL,
              edited_at     TEXT NOT NULL
    )")
    
    #Create indexes on (filename, metabolite) for every table for optimal data access 
    dbExecute(con, "CREATE INDEX IF NOT EXISTS idx_ann    ON annotation_data(file_name, metabolite)")
    dbExecute(con, "CREATE INDEX IF NOT EXISTS idx_intg   ON integration_data(file_name, metabolite)")
    dbExecute(con, "CREATE INDEX IF NOT EXISTS idx_axis   ON plot_axis_data(file_name, metabolite)")
    dbExecute(con, "CREATE INDEX IF NOT EXISTS idx_peaks  ON peaks_df(file_name, metabolite)")
    dbExecute(con, "CREATE INDEX IF NOT EXISTS idx_area   ON peak_area_df(file_name, metabolite)")
    dbExecute(con, "CREATE INDEX IF NOT EXISTS idx_mt     ON peak_mt_df(file_name, metabolite)")
  }
  
  #Function for wide -> long pivitors
  safe_col <- function(df, col){
    if (col %in% colnames(df)) df[[col]] else rep(NA_real_, nrow(df))
  }
  
  #Function to write/add each datafiles data into the SQL database, one datafile at a time as its generated in the main PeakMeister loop OR when generating a SQL file from preexisting .RData files
  write_file_to_db <- function(con, file_name, plot_list, peaks_df, peak_area_df, peak_mt_df, comment_df, mi_df) {
    metabolite_names <- names(plot_list)
    
    dbBegin(con)
    tryCatch({
      
      #annotation_data
      ann_all <- do.call(rbind,lapply(metabolite_names, function(metab) {
       ann <- plot_list[[metab]]$annotation_data
       ann_comments <- if (!is.null(comment_df) && metab %in% colnames(comment_df)){
         comment_df[ann$peak.number,metab]
       } else {
         ann$comment
       }
         data.frame(
           file_name        = file_name,
           metabolite       = metab,
           peak_number      = ann$peak.number,
           comment          = as.character(ann_comments),
           peak_apex_secs   = ann$peak.apex.seconds,
           peak_height      = ann$peak.height.counts,
           stringsAsFactors = FALSE
         )
      }))
      dbAppendTable(con, "annotation_data", ann_all)
      
      #integration_data
      intg_list <- lapply(metabolite_names, function(metab) {
        intg <- plot_list[[metab]]$integration_data
        if (is.null(intg) || nrow(intg) == 0) return(NULL)
        intg$peak.number <- as.numeric(as.character(intg$peak.number))
        data.frame(
          file_name   = file_name,
          metabolite  = metab,
          peak_number = intg$peak.number,
          mt_seconds  = intg$mt.seconds,
          intensity   = intg$intensity,
          baseline    = intg$baseline,
          stringsAsFactors = FALSE
        )
      })
      intg_all <- do.call(rbind, Filter(Negate(is.null), intg_list))
      if (!is.null(intg_all) && nrow(intg_all) > 0) {
        dbAppendTable(con, "integration_data", intg_all)
      }
      
      #plot axis data
      axis_all <- do.call(rbind, lapply(metabolite_names, function(metab){
        data.frame(
          file_name        = file_name,
          metabolite       = metab,
          x_start          = plot_list[[metab]]$x_axis_data[1],
          x_end            = plot_list[[metab]]$x_axis_data[2],
          y_max_annot      = plot_list[[metab]]$y_axis_data[1],
          y_max_eie        = plot_list[[metab]]$y_axis_data[2],
          label_name       = as.character(plot_list[[metab]]$label_data[1]),
          label_mz         = as.character(plot_list[[metab]]$label_data[2]),
          stringsAsFactors = FALSE
        )
      }))
      dbAppendTable(con, "plot_axis_data", axis_all)
      
      #Peaks_df data -> Need to pivot this data from wide format to long format
      num_peaks  <- nrow(peaks_df)
      peaks_long <- do.call(rbind, lapply(metabolite_names, function(metab) {
        data.frame(
          file_name       = file_name,
          metabolite      = metab,
          peak_number     = 1:num_peaks,
          start_seconds   = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(metab, ".start.seconds")))),
          apex_seconds    = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(metab, ".apex.seconds")))),
          end_seconds     = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(metab, ".end.seconds")))),
          start_intensity = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(metab, ".start_intensity")))),
          apex_intensity  = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(metab, ".apex_intensity")))),
          end_intensity   = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(metab, ".end_intensity")))),
          peak_area       = as.character(safe_col(peaks_df, paste0(metab, ".peak.area"))),
          stringsAsFactors = FALSE
        )
      }))
      dbAppendTable(con, "peaks_df", peaks_long)
      
      #peak_area_df datatable -> also need to change wide - long
      area_meta_cols <- colnames(peak_area_df)[
        !(colnames(peak_area_df) %in% c("file.name", "peak.number"))
      ]
      peak_area_df_chr <- as.data.frame(peak_area_df)
      peak_area_df_chr[area_meta_cols] <- lapply(
        peak_area_df_chr[area_meta_cols], as.character
      )
      area_long <- pivot_longer(
        peak_area_df_chr,
        cols = all_of(area_meta_cols),
        names_to = "metabolite", values_to = "peak_area"
      )
      area_long$file_name <- file_name
      area_long$peak_area <- as.character(area_long$peak_area)
      area_long <- area_long[, c("file_name", "peak.number", "metabolite", "peak_area")]
      colnames(area_long)[2] <- "peak_number"
      dbAppendTable(con, "peak_area_df", area_long)
      
      #peak_mt_df
      mt_meta_cols <- colnames(peak_mt_df)[
        !(colnames(peak_mt_df) %in% c("file.name","peak.number"))
      ]
      mt_long <- pivot_longer(
        as.data.frame(peak_mt_df),
        cols = all_of(mt_meta_cols),
        names_to = "metabolite", values_to = "migration_time"
      )
      mt_long$file_name <- file_name
      mt_long <- mt_long[, c("file_name","peak.number","metabolite","migration_time")]
      colnames(mt_long)[2] <- "peak_number"
      
      dbAppendTable(con, "peak_mt_df", mt_long)
      
      #mi_df
      existing_mi <- dbGetQuery(con, "SELECT COUNT(*) FROM mi_df")[[1]]
      if (existing_mi ==0){
        fixed_cols <- c("name", "left_is", "right_is","description")
        peak_cols <- colnames(mi_df)[!(colnames(mi_df) %in% fixed_cols)]
        mi_all <- do.call(rbind, lapply(1:nrow(mi_df), function(i){
          data.frame(
            metabolite = as.character(mi_df$name[i]),
            left_is    = as.character(mi_df$left_is[i]),
            right_is   = as.character(mi_df$right_is[i]),
            description = as.character(mi_df$description[i]),
            peak_indices = toJSON(
              as.list(mi_df[i, peak_cols, drop = FALSE]),
              auto_unbox = TRUE
            ), 
            stringsAsFactors = FALSE
          )
        }))
        dbAppendTable(con, "mi_df", mi_all)
      }
      
      dbCommit(con)
    }, error = function(e){
      tryCatch(dbRollback(con), error = function(e2) NULL)
      stop(paste("Database write failed for", file_name, ":", conditionMessage(e)))
    })
  }
  
  # Read immutable traces once when opening a file; editable data stays in SQLite.
  load_saved_plot_list <- function(results_folder, file_name) {
    rdata_path <- file.path(results_folder, "Data", paste0(file_name, ".mz5"),
                            "plot_list_data.RData")
    if (!file.exists(rdata_path)) stop("Saved plot data file is missing: ", rdata_path,
                                      call. = FALSE)
    env <- new.env(parent = emptyenv())
    load(rdata_path, envir = env)
    plots <- env[["plot_list"]]
    if (!is.list(plots) || !length(plots)) {
      stop("No saved plot_list was found in ", rdata_path, call. = FALSE)
    }
    plots
  }

  # Never guess by list position: names or the stored metabolite label must agree.
  read_saved_electropherogram <- function(plots, metabolite, rdata_path) {
    matches <- which(names(plots) == metabolite)
    if (!length(matches)) {
      matches <- which(vapply(plots, function(plot) {
        if (!is.list(plot)) return(FALSE)
        label <- plot[["label_data"]]
        length(label) > 0L && !is.na(label[1]) && identical(as.character(label[1]), metabolite)
      }, logical(1)))
    }
    problem <- function(detail) stop(
      "Cannot load saved electropherogram for '", metabolite, "': ", detail,
      ". File: ", rdata_path,
      ". The saved RData and results.sqlite must belong to the same analysis; keep both files together.",
      call. = FALSE)
    if (length(matches) != 1L) {
      problem(if (length(matches)) "multiple saved traces match this metabolite" else
                "the database metabolite has no matching saved trace")
    }
    plot <- plots[[matches]]
    if (!is.list(plot)) problem("the saved plot entry is invalid")
    trace <- plot[["eie_data"]]
    # Positional plot entries use the first component for the trace.
    if (is.null(trace) && is.null(names(plot)) && length(plot)) trace <- plot[[1]]
    if (!(is.data.frame(trace) || is.matrix(trace)) || ncol(trace) < 2L || nrow(trace) == 0L) {
      problem("the saved trace is missing or has no time/intensity columns")
    }
    times <- if (is.matrix(trace)) trace[, 1] else trace[[1]]
    intensities <- if (is.matrix(trace)) trace[, 2] else trace[[2]]
    if (!is.numeric(times) || !is.numeric(intensities) ||
        !any(is.finite(times) & is.finite(intensities))) {
      problem("the saved trace has no usable numeric time/intensity pairs")
    }
    data.frame(mt.seconds = times, intensity = intensities, stringsAsFactors = FALSE)
  }

  # Read one metabolite's editable plot data from SQLite and its saved trace.
  read_plot_data_from_db <- function(con, results_folder, file_name, metabolite, saved_plots = NULL) {
    rdata_path <- file.path(results_folder, "Data", paste0(file_name, ".mz5"),
                            "plot_list_data.RData")
    if (is.null(saved_plots)) saved_plots <- load_saved_plot_list(results_folder, file_name)
    eie_db <- read_saved_electropherogram(saved_plots, metabolite, rdata_path)
    colnames(eie_db)[2] <- paste(metabolite, "intensity")
    
    #annotation_data
    ann_db <- dbGetQuery(con,
                         "SELECT peak_number, comment, peak_apex_secs, peak_height
     FROM annotation_data
     WHERE file_name = ? AND metabolite = ?
     ORDER BY peak_number",
                         params = list(file_name, metabolite)
    )
    colnames(ann_db) <- c("peak.number", "comment",
                          "peak.apex.seconds", "peak.height.counts")
    
    #integration_data
    intg_db <- dbGetQuery(con,
                          "SELECT peak_number, mt_seconds, intensity, baseline
     FROM integration_data
     WHERE file_name = ? AND metabolite = ?
     ORDER BY peak_number, mt_seconds",
                          params = list(file_name, metabolite)
    )
    colnames(intg_db) <- c("peak.number", "mt.seconds", "intensity", "baseline")
    
    #axis + label data
    ax_db <- dbGetQuery(con,
                        "SELECT x_start, x_end, y_max_annot, y_max_eie, label_name, label_mz
     FROM plot_axis_data
     WHERE file_name = ? AND metabolite = ?",
                        params = list(file_name, metabolite)
    )
    
    #peaks_df for this metabolite (used by integration functions)
    peaks_db <- dbGetQuery(con,
                           "SELECT peak_number, start_seconds, apex_seconds, end_seconds,
            start_intensity, apex_intensity, end_intensity, peak_area
     FROM peaks_df
     WHERE file_name = ? AND metabolite = ?
     ORDER BY peak_number",
                           params = list(file_name, metabolite)
    )
    
    list(
      eie_data         = eie_db,
      annotation_data  = ann_db,
      integration_data = intg_db,
      label_data       = c(ax_db$label_name, ax_db$label_mz),
      x_axis_data      = c(ax_db$x_start, ax_db$x_end),
      y_axis_data      = c(ax_db$y_max_annot, ax_db$y_max_eie),
      peaks_df_metab   = peaks_db   
    )
  }
  
  #Write edit log entry function -> maintains a audit trail...
  log_edit <- function(con, file_name, metabolite, edit_type){
    dbExecute(con,
              "INSERT INTO edit_log (file_name, metabolite, edit_type, edited_at) VALUES (?, ?, ?, ?)",
              params = list(file_name, metabolite, edit_type,
                            format(Sys.time(), "%Y-%m-%d %H:%M:%S"))
              )
  }
  
  #Build SQL database from existing .Rdata files. Files already present are skipped.
  migrate_rdata_to_db <- function(results_folder, progress_callback = NULL) {
    
    db_path <- get_db_path(results_folder)
    con     <- dbConnect(RSQLite::SQLite(), db_path)
    initialize_db(con)
    
    data_dir    <- file.path(results_folder, "Data")
    subfolders  <- list.dirs(data_dir, full.names = TRUE, recursive = FALSE)
    rdata_files <- subfolders[file.exists(
      file.path(subfolders, "plot_list_data.RData")
    )]
    
    total   <- length(rdata_files)
    success <- 0
    failed  <- character(0)
    
    for (i in seq_along(rdata_files)) {
      subfolder  <- rdata_files[i]
      folder_name <- basename(subfolder)
      file_name   <- sub("\\.mz5$", "", folder_name)
      if (!is.null(progress_callback)) {
        progress_callback(i, total, file_name)
      }
      
      
      #Check if file is already in database and skip if need be.
      already <- dbGetQuery(con,
                            "SELECT COUNT(*) FROM plot_axis_data WHERE file_name = ?",
                            params = list(file_name)
      )[[1]]
      if (already > 0) {
        success <- success + 1
        next
      }
      
      env <- new.env()
      
      #Loop over files, marking files that failed to load and skipping them.
      tryCatch({
        load(file.path(subfolder, "plot_list_data.RData"), envir = env)
        write_file_to_db(
          con          = con,
          file_name    = file_name,
          plot_list    = env$plot_list,
          peaks_df     = env$peaks_df,
          peak_area_df = env$peak_area_df,
          peak_mt_df   = env$peak_mt_df,
          comment_df   = env$comment_df,
          mi_df        = env$mi_df
        )
        success <- success + 1
      }, error = function(e) {
        failed <<- c(failed, file_name)
        warning("Migration failed for ", file_name, ": ", conditionMessage(e))
      })
      rm(env); gc()
    }
    
    dbDisconnect(con)
    list(total = total, success = success, failed = failed)
  }
  
  
  #Load databases from SQL database for the selected file in wide format -> written to keep original logic
  load_wide_data_from_db <- function(con, file_name) {
    
    #peaks_df: pivot long -> wide. 7 columns per metabolite
    peaks_long <- dbGetQuery(con,
                             "SELECT * FROM peaks_df WHERE file_name = ? ORDER BY metabolite, peak_number",
                             params = list(file_name)
    )
    metabolites <- unique(peaks_long$metabolite)
    num_peaks   <- max(peaks_long$peak_number)
    
    #Make datamatix and fill column by column, matching column names to original peaks_df.
    peaks_wide <- matrix(NA_real_, nrow = num_peaks,
                         ncol = length(metabolites) * 7)
    col_names  <- character(length(metabolites) * 7)
    for (j in seq_along(metabolites)) {
      m   <- metabolites[j]
      sub <- peaks_long[peaks_long$metabolite == m, ]
      base <- (j - 1) * 7
      peaks_wide[sub$peak_number, base + 1] <- sub$start_seconds
      peaks_wide[sub$peak_number, base + 2] <- sub$apex_seconds
      peaks_wide[sub$peak_number, base + 3] <- sub$end_seconds
      peaks_wide[sub$peak_number, base + 4] <- sub$start_intensity
      peaks_wide[sub$peak_number, base + 5] <- sub$apex_intensity
      peaks_wide[sub$peak_number, base + 6] <- sub$end_intensity
      peaks_wide[sub$peak_number, base + 7] <- suppressWarnings(
        as.numeric(sub$peak_area)
      )
      col_names[base + (1:7)] <- paste0(m, c(".start.seconds", ".apex.seconds",
                                             ".end.seconds", ".start_intensity", ".apex_intensity",
                                             ".end_intensity", ".peak.area"))
    }
    peaks_wide_df           <- as.data.frame(peaks_wide)
    colnames(peaks_wide_df) <- col_names
    
    #peak_area_df: pivot long -> wide
    area_long <- dbGetQuery(con,
                            "SELECT peak_number, metabolite, peak_area FROM peak_area_df
       WHERE file_name = ? ORDER BY peak_number, metabolite",
                            params = list(file_name)
    )
    area_wide <- pivot_wider(
      area_long,
      names_from  = "metabolite",
      values_from = "peak_area"
    )
    area_wide <- cbind(
      "file.name"   = c(file_name, rep("", nrow(area_wide) - 1)),
      "peak.number" = area_wide$peak_number,
      area_wide[, -1]
    )
    
    #peak_mt_df: pivot long -> wide
    mt_long <- dbGetQuery(con,
                          "SELECT peak_number, metabolite, migration_time FROM peak_mt_df
       WHERE file_name = ? ORDER BY peak_number, metabolite",
                          params = list(file_name)
    )
    mt_wide <- pivot_wider(
      mt_long,
      names_from  = "metabolite",
      values_from = "migration_time"
    )
    mt_wide <- cbind(
      "file.name"   = c(file_name, rep("", nrow(mt_wide) - 1)),
      "peak.number" = mt_wide$peak_number,
      mt_wide[, -1]
    )
    
    #comment_df: derived from annotation_data
    ann_long <- dbGetQuery(con,
                           "SELECT peak_number, metabolite, comment FROM annotation_data
       WHERE file_name = ? ORDER BY peak_number, metabolite",
                           params = list(file_name))
    comment_wide <- pivot_wider(
      ann_long,
      names_from  = "metabolite",
      values_from = "comment",
      values_fill = "")
    comment_df <- as.data.frame(comment_wide[, -1])
    rownames(comment_df) <- comment_wide$peak_number
    
    #mi_df
    mi_db <- dbGetQuery(con, "SELECT * FROM mi_df")
    
    list(
      peaks_df     = peaks_wide_df,
      peak_area_df = area_wide,
      peak_mt_df   = mt_wide,
      comment_df   = comment_df,
      mi_df        = mi_db
    )
  }
  
  #Build full plot_list for current file from database + RData eie data. EIE data stored seperatley since we never need to change it, and it makes the stored SQL file smaller
  load_plot_list_from_db <- function(con, results_folder, file_name){
    metabolites <- dbGetQuery(con,
                              "SELECT DISTINCT metabolite FROM plot_axis_data WHERE file_name =?",
                              params = list(file_name)
                              )$metabolite
    if (!length(metabolites)) stop("No saved plot records found for ", file_name, call. = FALSE)
    saved_plots <- load_saved_plot_list(results_folder, file_name)
    plot_list <- lapply(metabolites, function(metab){
      read_plot_data_from_db(con, results_folder, file_name, metab, saved_plots)
    })
    names(plot_list) <- metabolites
    plot_list
  }
  
  
  #####4.2 Environmental initialization: File upload, and folder selection#####
  
  # Use uploaded filenames for new runs and saved-data filenames for reopening.
  observe_updates({
    files <- uploadedmz5()$FileName
    current <- isolate(input$file_selector)
    updateSelectInput(session, "file_selector", choices = files,
      selected = if (length(current) == 1L && current %in% files) current else head(files, 1L))
  })

  selected_results_filename <- reactive({
    files <- uploadedmz5()$FileName
    current <- input$file_selector
    if (!length(files)) return(character())
    if (length(current) == 1L && current %in% files) current else files[1]
  })

  # Inspect the matching filename parent and both earlier folder layouts only.
  # Checking Data/<filename>/plot_list_data.RData does not load raw mz5 contents.
  list_results_folders <- function(filename, run = character()) {
    if (length(filename) != 1L || !valid_mz5_names(filename)) return(character())
    parent <- tryCatch(mz5_result_parent(filename), error = function(e) NULL)
    if (is.null(parent)) return(character())
    if (length(run)) {
      if (length(run) != 1L || is.na(run) ||
          !identical(sub("\\.mz5$", "", filename, ignore.case = TRUE), run)) return(character())
      roots <- parent
    } else {
      legacy_parent <- file.path(".", basename(parent))
      roots <- unique(c(".", parent, legacy_parent))
    }
    roots <- roots[dir.exists(roots)]
    candidates <- unique(as.character(unlist(lapply(roots, function(path) {
      list.dirs(path, full.names = TRUE, recursive = FALSE)
    }), use.names = FALSE)))
    candidates <- candidates[grepl("^Results", basename(candidates))]
    candidates <- candidates[file.exists(file.path(candidates, "Data", filename, "plot_list_data.RData"))]
    sort(candidates)
  }

  results_folders_reactive <- reactivePoll(5000, session,
    checkFunc = function() list_results_folders(selected_results_filename(), selected_saved_run()),
    valueFunc = function() list_results_folders(selected_results_filename(), selected_saved_run()))

  latest_results_folder <- function(folders) {
    if (!length(folders)) return("")
    parts <- regmatches(basename(folders), regexec(
      "^Results ([0-9]{4}-[0-9]{2}-[0-9]{2})(?: ([0-9]+))?$", basename(folders), perl = TRUE))
    dates <- as.Date(vapply(parts, function(x) if (length(x)) x[2] else NA_character_,
      character(1)), format = "%Y-%m-%d")
    versions <- vapply(parts, function(x) {
      if (length(x) >= 3L && nzchar(x[3])) as.numeric(x[3]) else 1
    }, numeric(1))
    dated <- which(!is.na(dates))
    if (length(dated)) {
      return(folders[dated[order(dates[dated], versions[dated], folders[dated],
        decreasing = TRUE)[1]]])
    }
    # Retain support for saved folders with older, nonstandard names.
    folders[order(file.info(folders)$mtime, folders, decreasing = TRUE, na.last = TRUE)[1]]
  }

  output$results_folder_status <- renderText({
    filename <- selected_results_filename()
    if (!length(filename)) return("In Engine, select a saved run or upload files for a new analysis.")
    if (!length(results_folders_reactive())) {
      paste("No saved analyses found for", filename)
    } else paste("Saved analyses matching", filename)
  })

  last_results_filename <- reactiveVal(character())
  observe_action(list(selected_results_filename(), results_folders_reactive()), {
    filename <- selected_results_filename()
    folders <- results_folders_reactive()
    current <- input$results_folder
    same_file <- identical(filename, last_results_filename())
    last_results_filename(filename)
    choices <- c("Select a saved analysis" = "", analysis_folder_choices(folders))
    selected <- if (same_file && length(current) == 1L && current %in% folders) current else
      if (analysis_mode() == "existing" && length(selected_saved_run())) latest_results_folder(folders) else ""
    updateSelectInput(session, "results_folder", choices = choices, selected = selected)
  }, ignoreNULL = FALSE)

  db_con <- reactiveVal(NULL)

  # A marker distinguishes intentionally editable copies from original analyses.
  analysis_folder_choices <- function(folders) {
    edited <- file.exists(file.path(folders, ".peakmeister-edit-copy.rds"))
    stats::setNames(folders, paste0(basename(folders), ifelse(edited, " (edited)", "")))
  }

  initialize_peak_history <- function(con) {
    DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS peak_edit_history (
      step INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT NOT NULL,
      action TEXT NOT NULL, before_state BLOB NOT NULL, after_state BLOB NOT NULL,
      changed_plots BLOB NOT NULL, created_at TEXT NOT NULL)")
    DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS peak_edit_cursor (
      file_name TEXT PRIMARY KEY, step INTEGER NOT NULL)")
    DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS peak_edit_dirty_plots (
      file_name TEXT NOT NULL, plot_name TEXT NOT NULL, PRIMARY KEY (file_name, plot_name))")
  }

  pending_peak_plots <- function(con, file_name) {
    if (!DBI::dbExistsTable(con, "peak_edit_dirty_plots")) return(character())
    DBI::dbGetQuery(con, "SELECT plot_name FROM peak_edit_dirty_plots WHERE file_name = ? ORDER BY plot_name",
                    params = list(file_name))$plot_name
  }

  mark_pending_peak_plots <- function(con, file_name, plots) {
    for (plot in plots) DBI::dbExecute(con,
      "INSERT OR IGNORE INTO peak_edit_dirty_plots (file_name, plot_name) VALUES (?, ?)", params = list(file_name, plot))
  }

  peak_history_position <- function(con, file_name) {
    if (length(file_name) != 1L || is.null(con) || !DBI::dbIsValid(con) || !DBI::dbExistsTable(con, "peak_edit_history")) {
      return(list(step = 0L, undo = 0L, redo = 0L))
    }
    cursor <- DBI::dbGetQuery(con, "SELECT step FROM peak_edit_cursor WHERE file_name = ?", params = list(file_name))$step
    if (!length(cursor)) cursor <- 0L
    steps <- DBI::dbGetQuery(con, "SELECT step FROM peak_edit_history WHERE file_name = ?", params = list(file_name))$step
    list(step = cursor, undo = sum(steps <= cursor), redo = sum(steps > cursor))
  }

  # Copy the complete analysis and use SQLite's backup API to include WAL data.
  # The context bridges the first edit until the browser selects the new folder.
  ensure_editable_analysis <- function() {
    req(db_con(), input$file_selector)
    source <- main_folder()
    marker <- file.path(source, ".peakmeister-edit-copy.rds")
    if (file.exists(marker)) {
      initialize_peak_history(db_con())
      return(invisible(source))
    }
    validate_analysis_snapshot(plot_list_data_values$plot_list, plot_list_data_values$peaks_df,
      plot_list_data_values$mi_df, plot_list_data_values$peak_mt_df,
      plot_list_data_values$peak_area_df, plot_list_data_values$comment_df)
    target <- create_results_folder(input$file_selector)
    copied <- FALSE
    connection <- NULL
    on.exit(if (!copied) {
      if (!is.null(connection) && DBI::dbIsValid(connection)) DBI::dbDisconnect(connection)
      unlink(target, recursive = TRUE)
    }, add = TRUE)
    shiny::withProgress(message = "Creating an edited analysis copy", value = 0, {
      shiny::incProgress(0.1)
      entries <- list.files(source, all.files = TRUE, no.. = TRUE, full.names = TRUE)
      entries <- entries[!basename(entries) %in% c("results.sqlite", "results.sqlite-wal", "results.sqlite-shm")]
      if (length(entries) && !all(file.copy(entries, target, recursive = TRUE, copy.date = TRUE))) {
        stop("Could not create the editable analysis copy. Original results were kept.")
      }
      shiny::incProgress(0.7, detail = "Copying the result database")
      destination <- DBI::dbConnect(RSQLite::SQLite(), get_db_path(target))
      tryCatch(RSQLite::sqliteCopyDatabase(db_con(), destination), finally = DBI::dbDisconnect(destination))
      shiny::incProgress(0.2)
    })
    saveRDS(list(version = 1L, original = normalizePath(source), created_at = as.character(Sys.time())),
            file.path(target, ".peakmeister-edit-copy.rds"))
    connection <- open_db(target)
    initialize_peak_history(connection)
    old <- db_con()
    editing_context(list(selected_folder = input$results_folder, folder = target))
    db_con(connection)
    tryCatch(DBI::dbDisconnect(old), error = function(e) NULL)
    copied <- TRUE
    folders <- list_results_folders(input$file_selector, selected_saved_run())
    updateSelectInput(session, "results_folder", choices = c("Select a saved analysis" = "", analysis_folder_choices(folders)),
                      selected = target)
    updateSelectInput(session, "results_folder2", choices = c("Select a saved analysis" = "", analysis_folder_choices(folders)),
                      selected = target)
    showNotification(paste("Edits are saved in", basename(target), "(edited). The original analysis is preserved."), type = "message")
    invisible(target)
  }

  capture_peak_state <- function() {
    keys <- c("plot_list", "comment_df", "peaks_df", "peak_mt_df", "peak_area_df", "mi_df")
    state <- stats::setNames(lapply(keys, function(key) plot_list_data_values[[key]]), keys)
    state$modified <- modified_peak_plots$names
    # EIE vectors are immutable and can be large; only editable data goes in history.
    state$plot_list <- lapply(state$plot_list, function(plot) { plot$eie_data <- NULL; plot })
    state
  }

  apply_peak_state <- function(state, changed = character()) {
    traces <- lapply(plot_list_data_values$plot_list, function(plot) plot$eie_data)
    for (name in names(state$plot_list)) state$plot_list[[name]]$eie_data <- traces[[name]]
    validate_analysis_snapshot(state$plot_list, state$peaks_df, state$mi_df,
                               state$peak_mt_df, state$peak_area_df, state$comment_df)
    for (key in c("plot_list", "comment_df", "peaks_df", "peak_mt_df", "peak_area_df", "mi_df")) {
      plot_list_data_values[[key]] <- state[[key]]
      run_metadata[[key]] <- state[[key]]
    }
    modified_peak_plots$names <- unique(c(state$modified, changed))
  }

  save_current_peak_snapshot <- function() {
    save_analysis_snapshot(file.path(main_folder(), "Data", input$file_selector),
      plot_list_data_values$plot_list, plot_list_data_values$peaks_df, plot_list_data_values$mi_df,
      plot_list_data_values$peak_mt_df, plot_list_data_values$peak_area_df, plot_list_data_values$comment_df)
  }

  export_edited_peak_tables <- function() {
    # An export failure must not disguise a successfully committed edit/history step.
    with_action_error({ regenerate_metabolite_peak_areas(); regenerate_metabolite_migration_times() },
                       "Export edited peak tables")
  }

  perform_peak_edit <- function(action, callback) {
    req(db_con(), input$file_selector, plot_list_data_values$plot_list)
    ensure_editable_analysis()
    con <- db_con()
    file_name <- sub("\\.mz5$", "", input$file_selector)
    before <- capture_peak_state()
    DBI::dbBegin(con)
    peak_edit_in_progress(TRUE)
    completed <- FALSE
    on.exit(peak_edit_in_progress(FALSE), add = TRUE)
    on.exit(if (!completed) {
      tryCatch(DBI::dbRollback(con), error = function(e) NULL)
      apply_peak_state(before)
      tryCatch(save_current_peak_snapshot(), error = function(e) message("Snapshot rollback: ", conditionMessage(e)))
      plot_render_trigger(plot_render_trigger() + 1L)
    }, add = TRUE)
    value <- callback()
    after <- capture_peak_state()
    left <- before; right <- after; left$modified <- NULL; right$modified <- NULL
    if (identical(left, right)) {
      DBI::dbRollback(con)
      apply_peak_state(before)
      completed <- TRUE
      return(invisible(value))
    }
    changed <- names(after$plot_list)[!vapply(names(after$plot_list), function(name)
      identical(before$plot_list[[name]], after$plot_list[[name]]), logical(1))]
    changed <- paste0(file_name, "_", changed)
    cursor <- peak_history_position(con, file_name)$step
    DBI::dbExecute(con, "DELETE FROM peak_edit_history WHERE file_name = ? AND step > ?", params = list(file_name, cursor))
    DBI::dbExecute(con, "INSERT INTO peak_edit_history (file_name, action, before_state, after_state, changed_plots, created_at)
      VALUES (?, ?, ?, ?, ?, ?)", params = list(file_name, action, list(serialize(before, NULL)),
        list(serialize(after, NULL)), list(serialize(changed, NULL)), as.character(Sys.time())))
    step <- DBI::dbGetQuery(con, "SELECT last_insert_rowid() AS step")$step
    DBI::dbExecute(con, "INSERT OR REPLACE INTO peak_edit_cursor (file_name, step) VALUES (?, ?)", params = list(file_name, step))
    mark_pending_peak_plots(con, file_name, changed)
    save_current_peak_snapshot()
    DBI::dbCommit(con)
    completed <- TRUE
    apply_peak_state(after)
    modified_peak_plots$names <- pending_peak_plots(con, file_name)
    edit_history_trigger(edit_history_trigger() + 1L)
    plot_render_trigger(plot_render_trigger() + 1L)
    export_edited_peak_tables()
    invisible(value)
  }

  step_peak_history <- function(direction) {
    req(direction %in% c("undo", "redo"))
    con <- db_con()
    file_name <- sub("\\.mz5$", "", input$file_selector)
    position <- peak_history_position(con, file_name)
    if ((direction == "undo" && !position$undo) || (direction == "redo" && !position$redo)) {
      showNotification(paste("There are no changes to", direction, "for this analysis."), type = "message")
      return(invisible(FALSE))
    }
    req(plot_list_data_values$plot_list)
    query <- if (direction == "undo") "SELECT * FROM peak_edit_history WHERE file_name = ? AND step = ?" else
      "SELECT * FROM peak_edit_history WHERE file_name = ? AND step > ? ORDER BY step LIMIT 1"
    entry <- DBI::dbGetQuery(con, query, params = list(file_name, position$step))
    target <- unserialize(entry[[if (direction == "undo") "before_state" else "after_state"]][[1]])
    changed <- unserialize(entry$changed_plots[[1]])
    before <- capture_peak_state()
    DBI::dbBegin(con)
    peak_edit_in_progress(TRUE)
    completed <- FALSE
    on.exit(peak_edit_in_progress(FALSE), add = TRUE)
    on.exit(if (!completed) {
      tryCatch(DBI::dbRollback(con), error = function(e) NULL)
      apply_peak_state(before)
      tryCatch(save_current_peak_snapshot(), error = function(e) message("Snapshot rollback: ", conditionMessage(e)))
      plot_render_trigger(plot_render_trigger() + 1L)
    }, add = TRUE)
    apply_peak_state(target, changed)
    metabolites <- substring(changed, nchar(file_name) + 2L)
    for (name in intersect(names(plot_list_data_values$plot_list), metabolites)) {
      save_plot_data(name, refresh = FALSE)
    }
    step <- if (direction == "redo") entry$step else {
      previous <- DBI::dbGetQuery(con, "SELECT MAX(step) AS step FROM peak_edit_history WHERE file_name = ? AND step < ?",
                                 params = list(file_name, entry$step))$step
      if (is.na(previous)) 0L else previous
    }
    DBI::dbExecute(con, "UPDATE peak_edit_cursor SET step = ? WHERE file_name = ?", params = list(step, file_name))
    mark_pending_peak_plots(con, file_name, changed)
    save_current_peak_snapshot()
    DBI::dbCommit(con)
    completed <- TRUE
    modified_peak_plots$names <- pending_peak_plots(con, file_name)
    edit_history_trigger(edit_history_trigger() + 1L)
    plot_render_trigger(plot_render_trigger() + 1L)
    export_edited_peak_tables()
    showNotification(paste(if (direction == "undo") "Undid:" else "Redid:", entry$action), type = "message")
    invisible(TRUE)
  }

  output$edit_history_status <- renderText({
    edit_history_trigger()
    req(db_con(), input$file_selector)
    position <- peak_history_position(db_con(), sub("\\.mz5$", "", input$file_selector))
    if (!file.exists(file.path(main_folder(), ".peakmeister-edit-copy.rds"))) {
      return("Original analysis. Applying an edit creates a separate edited copy.")
    }
    paste0("Edited analysis — Undo: ", position$undo, " | Redo: ", position$redo)
  })

  clear_loaded_analysis <- function() {
    editing_context(NULL)
    edit_history_trigger(edit_history_trigger() + 1L)
    for (state in list(plot_list_data_values, run_metadata, previous_metadata)) {
      for (key in c("plot_list", "comment_df", "peaks_df", "peak_mt_df", "peak_area_df", "mi_df", "file_name")) {
        state[[key]] <- NULL
      }
    }
    modified_peak_plots$names <- character()
    plot_render_trigger(plot_render_trigger() + 1L)
  }

  #Deal with changing results folder and then load database or make database
  observe_action(input$results_folder, {
    #Close previous connection if open
    old_con <- db_con()
    if (!is.null(old_con)) {
      tryCatch(dbDisconnect(old_con), error = function(e) NULL)
      db_con(NULL)
    }
    
    clear_loaded_analysis()
    folder <- input$results_folder
    if (length(folder) != 1L || !nzchar(folder)) return()
    filename <- selected_results_filename()
    error <- tryCatch({ check_saved_analysis(folder, filename); NULL },
                      error = function(e) conditionMessage(e))
    if (!is.null(error)) {
      showNotification(error, type = "error", duration = 10)
      return()
    }
    updateSelectInput(session, "file_selector2", choices = uploadedmz5()$FileName, selected = filename)
    folders <- list_results_folders(filename, selected_saved_run())
    updateSelectInput(session, "results_folder2", choices = c("Select a saved analysis" = "",
                      analysis_folder_choices(folders)), selected = folder)

    if (db_exists(folder)) {
      #Database exists — open it and we're done
      con <- open_db(folder)
      db_con(con)
      cat("Database connected:", get_db_path(folder), "\n")
      
    } else {
      #No database found = count number of .Rdata files to be made into a SQL database.
      rdata_count <- length(list.dirs(
        file.path(folder, "Data"),
        full.names = TRUE, recursive = FALSE
      ))
      
      #Show modal and button options when no SQL database is found for migrating data over to SQL format.
      showModal(modalDialog(
        title = "Database Not Found",
        tags$p(
          "No database found for this Results folder.",
          tags$br(),
          paste0("Found ", rdata_count," processed data file(s) that can be migrated.")),
        tags$p(
          "Would you like to build the database now from your existing data?",
          tags$br(),
          tags$em("This only needs to be done once per Results folder.")),
        footer = tagList(
          modalButton("No — skip"),
          actionButton("confirm_migration", "Yes — build database", class = "btn-primary")),
        easyClose = FALSE
      ))
    }
  }, ignoreNULL = FALSE)

  # Clear stale editing/undo state only when the selected filename actually changes.
  last_visualization_filename <- reactiveVal(character())
  observe_action(selected_results_filename(), {
    filename <- selected_results_filename()
    if (identical(filename, last_visualization_filename())) return()
    last_visualization_filename(filename)
    con <- isolate(db_con())
    if (!is.null(con)) tryCatch(dbDisconnect(con), error = function(e) NULL)
    db_con(NULL)
    clear_loaded_analysis()
  }, ignoreNULL = FALSE, priority = 100)

  #Handle migration confirmation
  observe_action(input$confirm_migration, {
    removeModal()
    req(input$results_folder)
    folder <- input$results_folder
    error <- tryCatch({ check_saved_analysis(folder, selected_results_filename()); NULL },
                      error = function(e) conditionMessage(e))
    if (!is.null(error)) {
      showNotification(error, type = "error")
      return()
    }

    #Show progress modal
    showModal(modalDialog(
      title = "Building Database",
      tags$p("Migrating your existing data to the database..."),
      tags$p(id = "migration_progress", "Starting..."),
      footer = NULL,
      easyClose = FALSE
    ))
    
    withProgress(message = "Building database from existing data", value = 0, {
      result <- migrate_rdata_to_db(
        results_folder    = folder,
        progress_callback = function(i, total, file_name) {
          incProgress(
            amount  = 1 / total,
            detail  = paste("Processing:", file_name,
                            paste0("(", i, "/", total, ")"))
          )
        }
      )
    })
    
    removeModal()
    
    if (length(result$failed) == 0) {
      showNotification(
        paste0("Database built successfully! ",
               result$success, " file(s) migrated."),
        type     = "message",
        duration = 5
      )
    } else {
      showNotification(
        paste0("Migration complete. ", result$success, " succeeded, ",
               length(result$failed), " failed: ",
               paste(result$failed, collapse = ", ")),
        type     = "warning",
        duration = 10
      )
    }
    
    #Open new database with open_db and store connection in reactive variable.
    con <- open_db(folder)
    db_con(con)
    cat("Database built and connected:", get_db_path(folder), "\n")
  }, on_error = function() shiny::removeModal(session = session))
  
  #Clean up database connection when session ends
  session$onSessionEnded(function() {
    con <- isolate(db_con())
    if (!is.null(con)) {
      tryCatch(dbDisconnect(con), error = function(e) NULL)
    }
  })
  
  # One loader handles both opening a connection and switching the selected file.
  observe_action(list(db_con(), input$file_selector), {
    req(db_con(), input$file_selector)
    con       <- db_con()
    folder    <- main_folder()
    file_name <- sub("\\.mz5$", "", input$file_selector)

    #Checkto make sure file exists
    file_exists_in_db <- tryCatch({
      count <- dbGetQuery(con,
                          "SELECT COUNT(*) FROM plot_axis_data WHERE file_name = ?",
                          params = list(file_name))[[1]]
      count > 0
    }, error = function(e) FALSE)
    
    if (!file_exists_in_db) {
      cat("File not yet in database, skipping load:", file_name, "\n")
      return()
    }
    
    # Validate both sources before replacing any session state.
    plot_list <- load_plot_list_from_db(con, folder, file_name)

    #Load wide-format data for integration functions
    wide <- load_wide_data_from_db(con, file_name)

    #Populate reactive values
    plot_list_data_values$plot_list    <- plot_list
    plot_list_data_values$comment_df   <- wide$comment_df
    plot_list_data_values$peaks_df     <- wide$peaks_df
    plot_list_data_values$peak_mt_df   <- wide$peak_mt_df
    plot_list_data_values$peak_area_df <- wide$peak_area_df
    plot_list_data_values$mi_df        <- wide$mi_df
    plot_list_data_values$file_name    <- file_name

    run_metadata$plot_list    <- plot_list
    run_metadata$comment_df   <- wide$comment_df
    run_metadata$peaks_df     <- wide$peaks_df
    run_metadata$peak_mt_df   <- wide$peak_mt_df
    run_metadata$peak_area_df <- wide$peak_area_df
    run_metadata$mi_df        <- wide$mi_df
    run_metadata$file_name    <- input$file_selector
    modified_peak_plots$names <- pending_peak_plots(con, file_name)

    cat("Loaded from database:", file_name,
        "| metabolites:", length(plot_list), "\n")

    plot_render_trigger(plot_render_trigger() + 1)
  }, on_error = function() clear_loaded_analysis())


  #####4.3 Render and display plots and annotation information#####
  
  ######4.3.1 Populate plot table and render selected plot######
  #Populate the plot table
  output$plot_table <- DT::renderDataTable({
    plots <- filtered_plot_names()
    # Copying/switching versions of the same file should keep the current plot.
    selected <- if (identical(plots, session$userData$previous_peak_plot_names)) isolate(input$plot_table_rows_selected) else NULL
    session$userData$previous_peak_plot_names <- plots
    DT::datatable(data.frame(Plot = plots), selection = list(mode = "single", selected = selected))
  })

  
  #Render and construct plot on demand from SQL databse data
  # A nonempty browser event means its widget has rendered and registered events.
  # Reading event_data earlier produces warnings when no plot has been loaded yet.
  plot_event_data <- function(event, source) {
    req(input[[paste(event, source, sep = "-")]])
    plotly::event_data(event, source = source)
  }

  output$selected_plot <- renderPlotly({
    plot_render_trigger()
    req(input$plot_table_rows_selected, db_con())
    con       <- db_con()
    folder    <- main_folder()
    file_name <- sub("\\.mz5$", "", input$file_selector)
    
    selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
    metabolite         <- sub(paste0("^", file_name, "_"), "", selected_plot_name)
    
    plot_data <- tryCatch(
      read_plot_data_from_db(con, folder, file_name, metabolite),
      error = function(e) NULL
    )
    req(!is.null(plot_data))
    
    plot <- plot_function_plotly(
      eie_data         = plot_data$eie_data,
      annotation_data  = plot_data$annotation_data,
      integration_data = plot_data$integration_data,
      label_data       = plot_data$label_data,
      x_axis_data      = plot_data$x_axis_data,
      y_axis_data      = plot_data$y_axis_data,
      source           = "peakmeister_selected"
    )
    
    #Restore zoom state if one exists -> so that the plot doesnt reset every single time you make an edit.
    if (!is.null(zoom_state$xmin)) {
      plot <- plot %>% layout(
        xaxis = list(range = c(zoom_state$xmin, zoom_state$xmax)),
        yaxis = list(range = c(zoom_state$ymin, zoom_state$ymax))
      )
    }
    
    plot %>%
      layout(dragmode = "zoom") %>%
      config(modeBarButtonsToAdd = list("drawrect")) %>%
      event_register("plotly_click") %>%
      event_register("plotly_relayout")
  })
  
  
  
  ######4.3.2 Functions for dealing with moveable lines on plotlyplots######
  #Define logic for toggling between drag mode and draw mode for integrating.
  drag_mode <- reactiveVal("zoom")
  
  #Button toggle logic
  observe_action(input$draw_mode, {
    
    #Mode for drawing boxes on plot to highlight regions to integrate between 
    if (input$draw_mode) {
      drag_mode("drawrect")
      print("Mode switched to: drawrect")
      plotlyProxy("selected_plot", session) %>%
        plotlyProxyInvoke("relayout", list(dragmode = "drawrect"))
    } else {
      
      #Regular zoom mode for zooming in on peaks
      drag_mode("zoom")
      print("Mode switched to: zoom")
      plotlyProxy("selected_plot", session) %>%
        plotlyProxyInvoke("relayout", list(dragmode = "zoom"))
    }
  })
  
  #Store zoom state reactively when user zooms so we can regenerate the plots without zooming out -> required for efficiency
  zoom_state <- reactiveValues(
    xmin = NULL, xmax = NULL,
    ymin = NULL, ymax = NULL
  )
  
  #Capture zoom from relayout events for regenerating plot.
  observe_action(plot_event_data("plotly_relayout", "peakmeister_selected"), {
    rd <- plot_event_data("plotly_relayout", "peakmeister_selected")
    if (!is.null(rd[["xaxis.range[0]"]])) {
      zoom_state$xmin <- rd[["xaxis.range[0]"]]
      zoom_state$xmax <- rd[["xaxis.range[1]"]]
      zoom_state$ymin <- rd[["yaxis.range[0]"]]
      zoom_state$ymax <- rd[["yaxis.range[1]"]]
    }
    # Reset on double-click (autosize)
    if (!is.null(rd[["xaxis.autorange"]])) {
      zoom_state$xmin <- NULL
      zoom_state$xmax <- NULL
      zoom_state$ymin <- NULL
      zoom_state$ymax <- NULL
    }
  })
  
  #Reset zoom when switching metabolites
  observe_action(input$plot_table_rows_selected, {
    zoom_state$xmin <- NULL
    zoom_state$xmax <- NULL
    zoom_state$ymin <- NULL
    zoom_state$ymax <- NULL
  }) 
  
  #Deal with events occuring on the plot (drawing boxes)
  observe_action(plot_event_data("plotly_relayout", "peakmeister_selected"), {
    relayout_data <- plot_event_data("plotly_relayout", "peakmeister_selected")
    print(paste("Current drag_mode:", drag_mode()))
    print(relayout_data)
    
    #Lets user keep drawing after first rectangle drawn
    if (drag_mode() == "drawrect") {
      print("Re-asserting drawrect mode")
      plotlyProxy("selected_plot", session) %>%
        plotlyProxyInvoke("relayout", list(dragmode = "drawrect"))
    }
    
    #Deal with manual dragging of red and blue lines
    if (!is.null(relayout_data[["shapes[0].x0"]])) {
      line_positions$red <- relayout_data[["shapes[0].x0"]]
      print(paste("Red line updated to:", relayout_data[["shapes[0].x0"]]))
    }
    if (!is.null(relayout_data[["shapes[1].x0"]])) {
      line_positions$blue <- relayout_data[["shapes[1].x0"]]
      print(paste("Blue line updated to:", relayout_data[["shapes[1].x0"]]))
    }
    
    #Draw rectangle to dictate start and end integration points
    if (!is.null(relayout_data[["shapes"]]) && 
        any(relayout_data[["shapes"]]$type == "rect")) {
      
      shapes_df <- relayout_data[["shapes"]]
      rect_row <- shapes_df[shapes_df$type == "rect", ]
      
      x_start <- min(rect_row$x0, rect_row$x1)
      x_end   <- max(rect_row$x0, rect_row$x1)
      
      print(paste("Rectangle captured - x_start:", x_start, "x_end:", x_end))
      
      line_positions$red  <- x_start
      line_positions$blue <- x_end
      
      #Remove rectangle, update red/blue lines
      plotlyProxy("selected_plot", session) %>%
        plotlyProxyInvoke("relayout", list(
          shapes = list(
            list(
              type = "line",
              x0 = x_start, x1 = x_start,
              y0 = 0, y1 = 1,
              xref = "x", yref = "paper",
              line = list(color = "Red", width = 2)
            ),
            list(
              type = "line",
              x0 = x_end, x1 = x_end,
              y0 = 0, y1 = 1,
              xref = "x", yref = "paper",
              line = list(color = "Blue", width = 2)
            )
          )
        ))
    }
  })
  
  
  #Output red and blue line positions.
  output$red_line_position <- renderText({
    paste("Red Line Position (Left Boundary):", line_positions$red)
  })
  output$blue_line_position <- renderText({
    paste("Blue Line Position (Right Boundary):", line_positions$blue)
  })
  

  ######4.3.3 Render the annotation data table associated with selecetd plot######
  output$peak_info_table <- DT::renderDataTable({
    plot_render_trigger()
    req(input$plot_table_rows_selected, db_con())
    con       <- db_con()
    file_name <- sub("\\.mz5$", "", input$file_selector)
    
    #Extract metabolite name
    selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
    metabolite <- sub(paste0("^", file_name, "_"), "", selected_plot_name)
    
    #get annotation data for specified file and metabolite from database
    ann <- dbGetQuery(con,
                      "SELECT peak_number, comment, peak_apex_secs, peak_height
     FROM annotation_data
     WHERE file_name = ? AND metabolite = ?
     ORDER BY peak_number",
                      params = list(file_name, metabolite)
    )
    
    #rename columns
    colnames(ann) <- c("peak.number", "comment", "peak.apex.seconds", "peak.height.counts")
    ann
  }, options = list(pageLength = 13), selection = "multiple")
  
  
  #####4.4 Delete Peaks and Update Metadata#####
  ######4.4.1 Initialize environment, define reactive expressions, and define functions######
  
  #Function for saving and updating raw data aftyer any edit to a plot. Writes edited data for a single metabolite into the SQL database and then rerenders plot with new data. Also keeps writing .Rdata as a backup.
  save_plot_data <- function(plotname, refresh = TRUE) {
    req(db_con())
    if (!isTRUE(peak_edit_in_progress())) stop("Peak changes must be applied through edit history.")
    con       <- db_con()
    file_name <- plot_list_data_values$file_name
    folder    <- main_folder()
    validate_analysis_snapshot(plot_list_data_values$plot_list, plot_list_data_values$peaks_df,
      plot_list_data_values$mi_df, plot_list_data_values$peak_mt_df,
      plot_list_data_values$peak_area_df, plot_list_data_values$comment_df)
    
    #Update existing annotation data
    ann <- plot_list_data_values$plot_list[[plotname]]$annotation_data
    dbExecute(con,
              "DELETE FROM annotation_data WHERE file_name = ? AND metabolite = ?",
              params = list(file_name, plotname)
    )
    ann_db <- data.frame(
      file_name      = file_name,
      metabolite     = plotname,
      peak_number    = ann$peak.number,
      comment        = as.character(ann$comment),
      peak_apex_secs = ann$peak.apex.seconds,
      peak_height    = ann$peak.height.counts,
      stringsAsFactors = FALSE
    )
    dbAppendTable(con, "annotation_data", ann_db)
    
    #Update integration data
    intg <- plot_list_data_values$plot_list[[plotname]]$integration_data
    dbExecute(con,
              "DELETE FROM integration_data WHERE file_name = ? AND metabolite = ?",
              params = list(file_name, plotname)
    )
    if (!is.null(intg) && nrow(intg) > 0) {
      intg$peak.number <- as.numeric(as.character(intg$peak.number))
      intg_db <- data.frame(
        file_name   = file_name,
        metabolite  = plotname,
        peak_number = intg$peak.number,
        mt_seconds  = intg$mt.seconds,
        intensity   = intg$intensity,
        baseline    = intg$baseline,
        stringsAsFactors = FALSE
      )
      dbAppendTable(con, "integration_data", intg_db)
    }
    
    #Update peaks_df
    peaks_df  <- plot_list_data_values$peaks_df
    num_peaks <- nrow(peaks_df)
    dbExecute(con,
              "DELETE FROM peaks_df WHERE file_name = ? AND metabolite = ?",
              params = list(file_name, plotname)
    )
    peaks_db <- data.frame(
      file_name       = file_name,
      metabolite      = plotname,
      peak_number     = 1:num_peaks,
      start_seconds   = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(plotname, ".start.seconds")))),
      apex_seconds    = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(plotname, ".apex.seconds")))),
      end_seconds     = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(plotname, ".end.seconds")))),
      start_intensity = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(plotname, ".start_intensity")))),
      apex_intensity  = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(plotname, ".apex_intensity")))),
      end_intensity   = suppressWarnings(as.numeric(safe_col(peaks_df, paste0(plotname, ".end_intensity")))),
      peak_area       = as.character(safe_col(peaks_df, paste0(plotname, ".peak.area"))),
      stringsAsFactors = FALSE
    )
    dbAppendTable(con, "peaks_df", peaks_db)
    
    #Update peak area entries
    peak_area_df <- plot_list_data_values$peak_area_df
    dbExecute(con,"DELETE FROM peak_area_df WHERE file_name = ? AND metabolite = ?",params = list(file_name, plotname))
    
    area_db <- data.frame(
      file_name   = file_name,
      peak_number = 1:num_peaks,
      metabolite  = plotname,
      peak_area   = as.character(peak_area_df[, plotname]),
      stringsAsFactors = FALSE
    )
    dbAppendTable(con, "peak_area_df", area_db)

    # Keep migration-time exports and Undo/Redo consistent with moved peak apices.
    dbExecute(con, "DELETE FROM peak_mt_df WHERE file_name = ? AND metabolite = ?", params = list(file_name, plotname))
    dbAppendTable(con, "peak_mt_df", data.frame(file_name = file_name, peak_number = seq_len(num_peaks),
      metabolite = plotname, migration_time = as.numeric(plot_list_data_values$peak_mt_df[, plotname])))
    
    #Record data edit in edit_log trail.
    log_edit(con, file_name, plotname, "save")
    
    # The action transaction writes the full RData snapshot once, after all edits.
    
    #Update reactive values with new metabolite data.
    # Undo/Redo already has validated state and immutable traces in memory.
    # Do not reload the large RData file once for every restored metabolite.
    if (refresh) {
      updated_plot_data <- read_plot_data_from_db(con, folder, file_name, plotname)
      plot_list_data_values$plot_list[[plotname]] <- updated_plot_data
      run_metadata$plot_list[[plotname]]          <- updated_plot_data
      plot_render_trigger(plot_render_trigger() + 1)
    }
  }
  
  
  #reload_plot_data: now just re-reads from database into reactive values. Kept for backward compatibility with any code that calls it
  reload_plot_data <- function(subfolder_path = NULL) {
    req(db_con())
    con       <- db_con()
    folder    <- main_folder()
    file_name <- plot_list_data_values$file_name
    req(!is.null(file_name))
    
    wide <- load_wide_data_from_db(con, file_name)
    plot_list_data_values$comment_df   <- wide$comment_df
    plot_list_data_values$peaks_df     <- wide$peaks_df
    plot_list_data_values$peak_mt_df   <- wide$peak_mt_df
    plot_list_data_values$peak_area_df <- wide$peak_area_df
    run_metadata$comment_df            <- wide$comment_df
    run_metadata$peaks_df              <- wide$peaks_df
    run_metadata$peak_mt_df            <- wide$peak_mt_df
    run_metadata$peak_area_df          <- wide$peak_area_df
  }
  
  
  
  ######4.4.2 Server logic for deleting peaks in plots######
  # Session action called by the delete_peak button.
  delete_selected_peaks <- function() {
    if (!length(input$peak_info_table_rows_selected)) {
      showNotification("Select peak rows in the Peak Position Information table first.", type = "message")
      return(invisible(FALSE))
    }

    req(input$plot_table_rows_selected)
    perform_peak_edit("Delete selected peaks", function() {
      req(input$peak_info_table_rows_selected)

      selected_rows <- input$peak_info_table_rows_selected

      #Extract the current annotation_data
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
      plot_list <- plot_list_data_values$plot_list

      #Mark the plot as edited so only plots that have been edited can be regenerated later
      modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

      if (plotname %in% names(plot_list)) {
        annotation_data <- plot_list[[plotname]]$annotation_data
        integration_data <- plot_list[[plotname]]$integration_data

        #Loop through each selected row
        for (selected_row in selected_rows) {
          #Get the peak number from the selected row to allow matching accross various acccesible data streams
          peak_number <- annotation_data$peak.number[selected_row]

          #Update the comment column for the selected peak
          annotation_data$comment[selected_row] <- "NPD"

          #Update comment_df so peak areas can be recauculated/reintegrated later on
          if (plotname %in% colnames(plot_list_data_values$comment_df)) {
            plot_list_data_values$comment_df[peak_number, plotname] <- "NPD"
          }

          if (plotname %in% colnames(plot_list_data_values$peak_area_df)) {
            plot_list_data_values$peak_area_df[peak_number, plotname] <- "NPD"
          }

          #Remove all integration_data associated with the relevant peak number so regenerated plots will update with the deleted peaks once regenerated
          integration_data <- integration_data[integration_data$peak.number != peak_number, ]
        }

        #Update the plot_list with the modified annotation_data
        plot_list[[plotname]]$annotation_data <- annotation_data
        plot_list[[plotname]]$integration_data <- integration_data

        #Update the reactive plot_list_data
        plot_list_data_values$plot_list <- plot_list
      }

      #Save changes
      save_plot_data(plotname)

      #Reload the updated data
      subfolder_path <- file.path(main_folder(), "Data", run_metadata$file_name)
      reload_plot_data(subfolder_path)

      #Update reactive values directly
      plot_list_data_values$plot_list <- plot_list
      plot_list_data_values$comment_df <- plot_list_data_values$comment_df


      #Update the peak_info_table
      output$peak_info_table <- DT::renderDataTable({
        req(input$plot_table_rows_selected)
        selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]

        base_file_name <- sub("\\.mz5$", "", input$file_selector)
        plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
        plot_list <- plot_list_data_values$plot_list

        #Ensure the plotname exists in the plot_list
        if (plotname %in% names(plot_list)) {
          annotation_data <- plot_list[[plotname]]$annotation_data
          annotation_data
        } else {
          data.frame()
        }
      }, options = list(pageLength = 13), selection = 'multiple')

    })
  }

  observe_action(input$delete_peak, {
    delete_selected_peaks()
  })
  

  ######4.4.3 Button for deleting all but the first and last peaks######
  # Session action called by the deletemiddlepeaks button.
  delete_middle_peaks <- function() {
    req(input$plot_table_rows_selected)
    perform_peak_edit("Delete middle peaks", function() {
      req(input$plot_table_rows_selected)

      #Extract the current plot name
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
      plot_list <- plot_list_data_values$plot_list

      #Mark the plot as edited so only plots that have been edited can be regenerated later
      modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

      if (plotname %in% names(plot_list)) {
        annotation_data <- plot_list[[plotname]]$annotation_data
        integration_data <- plot_list[[plotname]]$integration_data

        #Identify the first and last peak numbers
        first_peak <- annotation_data$peak.number[1]
        last_peak <- annotation_data$peak.number[nrow(annotation_data)]

        #Update the comment column for all peaks except the first and last
        annotation_data$comment[-c(1, nrow(annotation_data))] <- "NPD"

        #Update comment_df so peak areas can be recalculated/reintegrated later on
        if (plotname %in% colnames(plot_list_data_values$comment_df)) {
          plot_list_data_values$comment_df[-c(first_peak, last_peak), plotname] <- "NPD"
        }

        if (plotname %in% colnames(plot_list_data_values$peak_area_df)) {
          plot_list_data_values$peak_area_df[-c(first_peak, last_peak), plotname] <- "NPD"
        }

        #Remove all integration_data associated with peaks except the first and last
        integration_data <- integration_data[integration_data$peak.number %in% c(first_peak, last_peak), ]

        #Update the plot_list with the modified annotation_data
        plot_list[[plotname]]$annotation_data <- annotation_data
        plot_list[[plotname]]$integration_data <- integration_data

        #Update the reactive plot_list_data
        plot_list_data_values$plot_list <- plot_list

        #Save changes
        save_plot_data(plotname)

        #Reload the updated data
        subfolder_path <- file.path(main_folder(), "Data", run_metadata$file_name)
        reload_plot_data(subfolder_path)

        #Update reactive values directly
        plot_list_data_values$plot_list <- plot_list
        plot_list_data_values$comment_df <- plot_list_data_values$comment_df

        #Update the peak_info_table
        output$peak_info_table <- DT::renderDataTable({
          req(input$plot_table_rows_selected)
          selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]

          base_file_name <- sub("\\.mz5$", "", input$file_selector)
          plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
          plot_list <- plot_list_data_values$plot_list

          #Ensure the plotname exists in the plot_list
          if (plotname %in% names(plot_list)) {
            annotation_data <- plot_list[[plotname]]$annotation_data
            annotation_data
          } else {
            data.frame()
          }
        }, options = list(pageLength = 13), selection = 'multiple')
      }

    })
  }

  observe_action(input$deletemiddlepeaks, {
    delete_middle_peaks()
  })
  
  ######4.4.4 Button for deleting ALL peaks in a plot######
  # Session action called by the deleteallpeaks button.
  delete_all_peaks <- function() {
    req(input$plot_table_rows_selected)
    perform_peak_edit("Delete all peaks", function() {
      req(input$plot_table_rows_selected)

      #Extract the current plot name
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
      plot_list <- plot_list_data_values$plot_list

      #Mark the plot as edited so only plots that have been edited can be regenerated later
      modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

      if (plotname %in% names(plot_list)) {
        annotation_data <- plot_list[[plotname]]$annotation_data
        integration_data <- plot_list[[plotname]]$integration_data

        #Update the comment column for all peaks
        annotation_data$comment <- "NPD"

        #Update comment_df so peak areas can be recalculated/reintegrated later on
        if (plotname %in% colnames(plot_list_data_values$comment_df)) {
          plot_list_data_values$comment_df[, plotname] <- "NPD"
        }

        if (plotname %in% colnames(plot_list_data_values$peak_area_df)) {
          plot_list_data_values$peak_area_df[, plotname] <- "NPD"
        }

        #Remove all integration_data
        integration_data <- integration_data[0, ]

        #Update the plot_list with the modified annotation_data
        plot_list[[plotname]]$annotation_data <- annotation_data
        plot_list[[plotname]]$integration_data <- integration_data

        #Update the reactive plot_list_data
        plot_list_data_values$plot_list <- plot_list

        #Save changes
        save_plot_data(plotname)

        #Reload the updated data
        subfolder_path <- file.path(main_folder(), "Data", run_metadata$file_name)
        reload_plot_data(subfolder_path)

        #Update reactive values directly
        plot_list_data_values$plot_list <- plot_list
        plot_list_data_values$comment_df <- plot_list_data_values$comment_df

        #Update the peak_info_table
        output$peak_info_table <- DT::renderDataTable({
          req(input$plot_table_rows_selected)
          selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]

          base_file_name <- sub("\\.mz5$", "", input$file_selector)
          plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
          plot_list <- plot_list_data_values$plot_list

          #Ensure the plotname exists in the plot_list
          if (plotname %in% names(plot_list)) {
            annotation_data <- plot_list[[plotname]]$annotation_data
            annotation_data
          } else {
            data.frame()
          }
        }, options = list(pageLength = 13), selection = 'multiple')
      }

    })
  }

  observe_action(input$deleteallpeaks, {
    delete_all_peaks()
  })
  
     
  #####4.5 Undo peak deletion#####
  # Session action called by the undo button.
  undo_peak_deletion <- function() {
    step_peak_history("undo")
  }

  observe_action(input$undo, { undo_peak_deletion() })
  observe_action(input$redo, { step_peak_history("redo") })

  #####4.6 Regenerate plots#####

  ######4.6.1 Defining Plotting Functions######
   #ggplot function
   plot_function <- function(eie_data, annotation_data, integration_data, label_data, x_axis_data, y_axis_data, base_file_name, font_size_1, font_size_2){
  
     extra_space <- ifelse(x_axis_data[1] > 70, 1, 0)
  
     #Convert peak.number to factor
     integration_data$peak.number <- as.factor(integration_data$peak.number)
     
     ggplot(data = eie_data) +
      geom_line(aes(x = mt.seconds / 60, y = eie_data[,2]), colour = "grey50") +
       theme_classic() +
       coord_cartesian(xlim = c(x_axis_data[1] / 60 - extra_space, x_axis_data[2] / 60 + extra_space),
                       ylim = c(0, 1.5 * y_axis_data[1])) +
       scale_y_continuous(name = "Ion Counts",
                          labels = function(x) format(x, scientific = TRUE),
                          expand = c(0,0),
                          breaks = scales::pretty_breaks(n = 10)) +
       scale_x_continuous(name = "Migration Time (Minutes)",
                          breaks = scales::pretty_breaks(n = 10))+
       ggtitle(paste(label_data[1], " EIE", " (m/z = ", label_data[2],")",sep = ""),
              subtitle = paste("Data File: ", base_file_name)) +
       geom_ribbon(data = integration_data,
                   aes(x = mt.seconds/60, ymax = intensity, ymin = baseline, fill = peak.number),
                   alpha =0.4) +
       geom_text(data = annotation_data,
                 label = annotation_data$peak.number,
                 size  = font_size_1,
                 family = "sans",
                 aes(x = peak.apex.seconds/60,
                     y = peak.height.counts + 0.1 * y_axis_data[1])) +
       geom_text(data = annotation_data,
                 label = annotation_data$comment,
                 size  = font_size_1,
                 family = "sans",
                 aes(x = peak.apex.seconds/60,
                     y = peak.height.counts + 0.2 * y_axis_data[1])) +
       theme(legend.position = "none",
             text = element_text(size = font_size_2, family = "sans"))
   }
  
   #plotly function
   plot_function_plotly <- function(eie_data, annotation_data, integration_data, label_data, x_axis_data, y_axis_data, source = "A") {
     plot_ly(source = source) %>%
       add_lines(
         x = ~eie_data[,1] / 60,
         y = ~eie_data[,2],
         name = 'Electropherogram',
         line = list(color = 'grey')
       ) %>%
       add_ribbons(
         x = ~integration_data$mt.seconds / 60,
         ymin = ~integration_data$baseline,
         ymax = ~integration_data$intensity,
         fillcolor = 'rgba(100,100,255,0.4)',
         line = list(color = 'rgba(100,100,255,0.4)'),
         name = 'Peak Integration'
       ) %>%
       add_text(
         x = ~annotation_data$peak.apex.seconds / 60,
         y = ~annotation_data$peak.height.counts + (0.1 * y_axis_data[1]),
         text = ~annotation_data$peak.number,
         showlegend = FALSE
       ) %>%
       add_text(
         x = ~annotation_data$peak.apex.seconds / 60,
         y = ~annotation_data$peak.height.counts + (0.2 * y_axis_data[1]),
         text = ~annotation_data$comment,
         showlegend = FALSE
       ) %>%
       layout(
         title = paste(label_data[1], " EIE", " (m/z =", label_data[2], ")"),
         xaxis = list(title = 'Migration Time (Minutes)'),
         yaxis = list(title = 'Ion Counts'),
         template = 'plotly_white',
         shapes = list(
           list(
             type = "line",
             x0 = 2,  #Initial position of the red line
             y0 = 0,
             x1 = 2,
             y1 = 1,
             xref = "x",
             yref = "paper",
             line = list(color = "Red", width = 2)
           ),
           list(
             type = "line",
             x0 = 4,  #Initial position of the blue line
             y0 = 0,
             x1 = 4,
             y1 = 1,
             xref = "x",
             yref = "paper",
             line = list(color = "Blue", width = 2)
           )
         )
       ) %>% config(editable = TRUE)
   }
  
   ######4.6.2 Defining functions for modifying saved peak area information######
   regenerate_metabolite_peak_areas <- function() {
     ensure_editable_analysis()
     req(db_con())
     con       <- db_con()
     file_name <- plot_list_data_values$file_name
     
     #Pull all peak areas from database across all files in this Results folder
     area_long <- dbGetQuery(con,
                             "SELECT file_name, peak_number, metabolite, peak_area FROM peak_area_df
       ORDER BY file_name, peak_number"
     )
     
     #Pivot to wide format matching original CSV structure
     area_wide <- tidyr::pivot_wider(
       area_long,
       names_from  = "metabolite",
       values_from = "peak_area"
     )
     area_wide <- cbind(
       "file.name"   = area_wide$file_name,
       "peak.number" = area_wide$peak_number,
       area_wide[, !(colnames(area_wide) %in% c("file_name", "peak_number"))]
     )
     
     write.csv(area_wide,
               file      = file.path(main_folder(), "Metabolite Peak Areas.csv"),
               row.names = FALSE)
   }
   
  ######4.6.3 Function for regenerating plotly plots######
   regenerate_plots <- function() {
     ensure_editable_analysis()
     #Define font sizes for plotting functions
     font_size_1 <- 7
     font_size_2 <- 25
     
     #Get the list of all folders in the Data directory
     data_subfolders <- list.dirs(path = file.path(main_folder(), "Data"), full.names = TRUE, recursive = FALSE)
     
     #Initialize an empty list to store all plotly objects
     plotly_objects <- list()
     
     for (subfolder_path in data_subfolders) {
       #Extract the base file name from the subfolder name
       base_file_name <- sub("\\.mz5$", "", basename(subfolder_path))
       
       #Load the plot_list_data.RData file
       if (file.exists(file.path(subfolder_path, "plot_list_data.RData"))) {
         load(file.path(subfolder_path, "plot_list_data.RData"))
         
         for (plotname in names(plot_list)) {
           #Print the name of the plot being worked on
           print(paste("Regenerating plot:", plotname))
           
           #Retrieve the plot data for the current plotname
           plot_data <- plot_list[[plotname]]
           
           plot <- plot_function_plotly(
             eie_data = plot_data$eie_data,
             annotation_data = plot_data$annotation_data,
             integration_data = plot_data$integration_data,
             label_data = plot_data$label_data,
             x_axis_data = plot_data$x_axis_data,
             y_axis_data = plot_data$y_axis_data
           )
           
           plot <- event_register(plot, "plotly_click")
           
           #This is necessary to save plots correctly
           plotly_copy <- plotly::plotly_build(plot)
           
           #Name the plot to match with existing plots
           plot_name <- paste0(base_file_name, "_", plotname)
           
           #Update or add the regenerated plot in the plotly_objects list
           plotly_objects[[plot_name]] <- plotly_copy
         }
         plotly_data(plotly_objects)
       }
     }
     
     
     #Save all plotly objects to a single .RData file
     save(plotly_objects, file = file.path(main_folder(), "plotly_objects.RData"), compress = "xz")
     print("Finished regenerating and compressing all plots!")
   }

   ######4.6.4 Function for regenerating ggplots plots and saving them to specified locations######
   regenerate_ggplot <- function() {
     ensure_editable_analysis()
     #Define plotting housekeeping variables
     plot_format <- parametersData()$plot.format
     name_vec <- c(refMassListData()$name, massData()$name)
     num_of_metabolites <- nrow(massData())
     num_of_is <- nrow(refMassListData())
     
     #Get the list of all folders in the Data directory
     data_subfolders <- list.dirs(path = file.path(main_folder(), "Data"), full.names = TRUE, recursive = FALSE)
     
     for (subfolder_path in data_subfolders) {
       #Extract the base file name from the subfolder name and remove the .mz5 extension
       base_file_name <- sub("\\.mz5$", "", basename(subfolder_path))
       
       #Load the plot_list_data.RData file
       if (file.exists(file.path(subfolder_path, "plot_list_data.RData"))) {
         load(file.path(subfolder_path, "plot_list_data.RData"))
         
         #Load data for plotting along with mi_df to determine which metabolites use MI and which use RMTs
         plot_list <- get("plot_list")
         mi_df <- get("mi_df")
         
         modified_plot_names <- sapply(modified_peak_plots$names, function(name) {
           sub(paste0("^", base_file_name, "_"), "", name)
         })
         
         modified_plots <- intersect(names(plot_list), modified_plot_names)
         
         
         #Regenerate plots according to "Sample" format
         if (plot_format == "Sample") {
           for (plotname in modified_plots) {
             
             print(paste("Regenerating plot:", plotname, "from file:", base_file_name))
             
             #Load plot data
             plot_data <- plot_list[[plotname]]
             
             #Define index for correctly naming saved files
             plot_index <- which(name_vec == plotname)
             
             #Plot both internal standard and analyte plots
             if (plotname %in% name_vec[1:num_of_is]) {
               font_size_1 <- 7
               font_size_2 <- 25
               
               #Save internal standard plots
               folder <- "Internal Standards"
               ggsave(filename = paste(plot_index, "_", plotname, ".png", sep = ""),
                      width = 16,
                      height = 9,
                      plot = plot_function(eie_data = plot_data$eie_data,
                                           annotation_data = plot_data$annotation_data,
                                           integration_data = plot_data$integration_data,
                                           label_data = plot_data$label_data,
                                           x_axis_data = plot_data$x_axis_data,
                                           y_axis_data = plot_data$y_axis_data,
                                           base_file_name = base_file_name,
                                           font_size_1 = font_size_1,
                                           font_size_2 = font_size_2),
                      path = paste(main_folder(), "/Plots/", folder, "/", base_file_name, sep = ""))
             } else {
               folder <- "Analytes"
               
               #Analytes using RMT
               if (mi_df$description[which(name_vec == plotname) - num_of_is] != "mi") {
                 font_size_1 <- 4
                 font_size_2 <- 12
                 is_index <- which(name_vec == mi_df$description[which(name_vec == plotname) - num_of_is])
                 
                 figure <- ggarrange(plot_function(eie_data = plot_data$eie_data,
                                                   annotation_data = plot_data$annotation_data,
                                                   integration_data = plot_data$integration_data,
                                                   label_data = plot_data$label_data,
                                                   x_axis_data = c(min(plot_data$eie_data$mt.seconds), max(plot_data$eie_data$mt.seconds)),
                                                   y_axis_data = plot_data$y_axis_data,
                                                   base_file_name = base_file_name,
                                                   font_size_1 = font_size_1,
                                                   font_size_2 = font_size_2),
                                     plot_function(eie_data = plot_data$eie_data,
                                                   annotation_data = plot_data$annotation_data,
                                                   integration_data = plot_data$integration_data,
                                                   label_data = plot_data$label_data,
                                                   x_axis_data = plot_data$x_axis_data,
                                                   y_axis_data = plot_data$y_axis_data,
                                                   base_file_name = base_file_name,
                                                   font_size_1 = font_size_1,
                                                   font_size_2 = font_size_2),
                                     plot_function(eie_data = plot_list[[is_index]]$eie_data,
                                                   annotation_data = plot_list[[is_index]]$annotation_data,
                                                   integration_data = plot_list[[is_index]]$integration_data,
                                                   label_data = plot_list[[is_index]]$label_data,
                                                   x_axis_data = plot_list[[is_index]]$x_axis_data,
                                                   y_axis_data = plot_list[[is_index]]$y_axis_data,
                                                   base_file_name = base_file_name,
                                                   font_size_1 = font_size_1,
                                                   font_size_2 = font_size_2),
                                     ncol = 1, nrow = 3)
                 ggsave(filename = paste(plot_index, "_", plotname, ".png", sep = ""),
                        width = 16,
                        height = 9,
                        plot = figure,
                        path = paste(main_folder(), "/Plots/", folder, "/", base_file_name, sep = ""))
               } else {
                 font_size_1 <- 4
                 font_size_2 <- 12
                 figure <- ggarrange(plot_function(eie_data = plot_data$eie_data,
                                                   annotation_data = plot_data$annotation_data,
                                                   integration_data = plot_data$integration_data,
                                                   label_data = plot_data$label_data,
                                                   x_axis_data = c(min(plot_data$eie_data$mt.seconds), max(plot_data$eie_data$mt.seconds)),
                                                   y_axis_data = plot_data$y_axis_data,
                                                   base_file_name = base_file_name,
                                                   font_size_1 = font_size_1,
                                                   font_size_2 = font_size_2),
                                     plot_function(eie_data = plot_data$eie_data,
                                                   annotation_data = plot_data$annotation_data,
                                                   integration_data = plot_data$integration_data,
                                                   label_data = plot_data$label_data,
                                                   x_axis_data = plot_data$x_axis_data,
                                                   y_axis_data = plot_data$y_axis_data,
                                                   base_file_name = base_file_name,
                                                   font_size_1 = font_size_1,
                                                   font_size_2 = font_size_2),
                                     ncol = 1, nrow = 2)
                 ggsave(filename = paste(plot_index, "_", plotname, ".png", sep = ""),
                        width = 16,
                        height = 9,
                        plot = figure,
                        path = paste(main_folder(), "/Plots/", folder, "/", base_file_name, sep = ""))
               }
             }
           }
         }
         
         #Regenerate plots according to "Metabolite" format
         if (plot_format == "Metabolite") {
           for (n in 1:length(name_vec)) {
             plotname <- name_vec[n]
             if (plotname %in% modified_plot_names) {
               folder <- plotname
               ggsave(filename = paste(base_file_name, ".png", sep = ""),
                      width = 16,
                      height = 9,
                      plot = plot_function(eie_data = plot_list[[n]]$eie_data,
                                           annotation_data = plot_list[[n]]$annotation_data,
                                           integration_data = plot_list[[n]]$integration_data,
                                           label_data = plot_list[[n]]$label_data,
                                           x_axis_data = plot_list[[n]]$x_axis_data,
                                           y_axis_data = plot_list[[n]]$y_axis_data),
                      path = paste(main_folder(), "/Plots/", folder, "/", sep = ""))
             }
           }
         }
       }
     }
   }
   
   ######4.6.5 Function for Regenerating Migration time file#####
   regenerate_metabolite_migration_times <- function() {
     ensure_editable_analysis()
     req(db_con())
     con <- db_con()
     
     # Stored/report migration times are minutes, matching new-analysis CSVs.
     mt_long <- dbGetQuery(con,
                           "SELECT file_name, peak_number, metabolite, migration_time AS peak_apex_secs
     FROM peak_mt_df
     ORDER BY file_name, peak_number"
     )
     
     # Pivot to wide format
     mt_wide <- tidyr::pivot_wider(
       mt_long,
       names_from  = "metabolite",
       values_from = "peak_apex_secs"
     )
     mt_wide <- cbind(
       "file.name"   = mt_wide$file_name,
       "peak.number" = mt_wide$peak_number,
       mt_wide[, !(colnames(mt_wide) %in% c("file_name", "peak_number"))]
     )
     
     write.csv(mt_wide,
               file      = file.path(main_folder(), "Metabolite Migration Times.csv"),
               row.names = FALSE)
   }


   ######4.6.6 Applying functions######
#Loading messages for loading screen
   loading_messages <- c(
     "Training squirrels to redraw plots...", 
     "Bribing CE ghosts to cooperate...",
     "Praying to the R gods that the code will work...",
     "Plotting revenge against noisy data...",
     "Summoning peak integration spirits...",
     "Sacrificing the old plots for better results...",
     "Convincing peaks they really do exist...",
     "Making a blood sacrifice to the R gods...",
     "Offering a peace treaty to signal noise...",
     "Selling soul for a perfectly integrated peak...",
     "Syncing plotting preferences with your Spotify...",
     "Telling algorithm to 'just work'...",
     "Praying the plots havent unionized...",
     "Debugging... or just staring at the screen intensely...",
     "Gaslighting peaks into aligning properly...",
     "Performing an exorcism on the previous plots...",
     "Pleading with the R gods for mercy...",
     "Recalculating everything... again...",
     "Casting a circle of salt around the data...",
     "Begging...",
     "Hoping that everything is still there at the end",
     "I feel like we are suposed to be loading something",
     "Integrating something completly random...",
     "Woah! Look at it go",
     "Our premium plan is faster...",
     "Trying not to crash, burn, and die",
     "Avoiding a crashout...",
     "Loading sounds...",
     "Discovering new ways to make you wait",
     "Try holding your breath through this"
   )
   
   #Modal for other button that creates modal with three other buttons
   observe_action(input$other_options, {
     showModal(modalDialog(
       title = "Additional Options",
       h5("Select an action:"),
       br(),
       fluidRow(
         column(12,
                actionButton("regenerateplots", "Regenerate Changed Plots"),
                actionButton("rebuild_peak_areas_modal", "Rebuild Peak Area CSV"),
                actionButton("rebuild_mig_times_modal", "Rebuild Peak Migration Time CSV")
         )
       ),
       footer = modalButton("Close"),
       easyClose = TRUE
     ))
   })

  #Action button for regenerating plots
  # Session action called by the regenerateplots button.
  regenerate_changed_plots <- function() {
    #remove modal
      removeModal()

      #Initialize waiter loading screen
      initial_message <- sample(loading_messages, 1)
      waiter_show(
        html = tagList(
          spin_flower(),
          h4(id = "loading-message", initial_message, style = "color:black;")
        ),
        color = "rgba(210,210,210,0.7)"
      )

      #Java script for switching between different loading messages
      js_script <- sprintf("
      setTimeout(function() {
        var messages = %s;
        function updateMessage() {
          var elem = document.getElementById('loading-message');
          if (elem) {
            var newMessage = messages[Math.floor(Math.random() * messages.length)];
            elem.innerText = newMessage;
          }
        }
        setInterval(updateMessage, 4000); // Update every 5 seconds
      }, 2000);
    ", jsonlite::toJSON(loading_messages, auto_unbox = TRUE))
      runjs(js_script)

      #Apply plotting and area functions
      regenerate_metabolite_peak_areas()
      print("Finished applying peak area function")

      #Check if required data is populated before running regenerate_ggplot
      if (nrow(massData()) == 0 || nrow(refMassListData()) == 0 || nrow(parametersData()) == 0) {
        showNotification("Upload Mass List and Parameters Information!", type = "error")
      } else {
        regenerate_ggplot()
        showNotification("Successfully regenerated plots and updated metadata", type = "message")
        modified_peak_plots$names <- character()
        dbExecute(db_con(), "DELETE FROM peak_edit_dirty_plots WHERE file_name = ?",
                  params = list(sub("\\.mz5$", "", input$file_selector)))
      }

      waiter_hide()
  }

  observe_action(input$regenerateplots, {
    regenerate_changed_plots()
  })
  
  #Table to list modified plots that will be regenerated
  output$modified_peak_plots_table <- DT::renderDataTable({
    data.frame(Modified_Plots = modified_peak_plots$names)
  }, selection = 'single')
  
  #Rebuild peak area csv
  observe_action(input$rebuild_peak_areas_modal, {
    removeModal()
    tryCatch({
      regenerate_metabolite_peak_areas()
      showNotification("Metabolite Peak Areas CSV rebuilt successfully!", type = "message")
    }, error = function(e) {
      showNotification(paste("Error rebuilding peak areas:", e$message), type = "error")
    })
  })
  
  #Rebuild migration CSV
  observe_action(input$rebuild_mig_times_modal, {
    removeModal()
    tryCatch({
      regenerate_metabolite_migration_times()
      showNotification("Metabolite Migration Times CSV rebuilt successfully!", type = "message")
    }, error = function(e) {
      showNotification(paste("Error rebuilding migration times:", e$message), type = "error")
    })
  })
  
  #####4.7 Adjusting integration and adding peaks#####
  ######4.7.1 Function for manual peak number input######
  peak_input_modal <- function() {
    showModal(modalDialog(
      title = "Manual Peak Input",
      textInput("manual_peak_number", "Enter peak number of peak you are modifying:", ""),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("confirm_peak_number", "Confirm")
      )
    ))
  }

  
  ######4.7.2 Integration function######
  manual_peak_integration <- function(peak_number){
    if (length(peak_number) != 1L || is.na(suppressWarnings(as.numeric(peak_number)))) {
      showNotification("Select one peak row, or enter one valid peak number.", type = "message")
      return(invisible(FALSE))
    }

    req(input$plot_table_rows_selected)
    perform_peak_edit("Adjust peak integration", function() {

      #define variables required for plotting
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)

      #load plot data
      plot_data <- plot_list_data_values$plot_list[[plotname]]
      eie_df <- plot_data$eie_data
      peaks_df <- plot_list_data_values$peaks_df
      peak_area_df <- plot_list_data_values$peak_area_df

      #Get the start and end positions from the reactive line_positions
      red_line <- line_positions$red #start
      blue_line <- line_positions$blue #end

      #Convert from minutes to seconds
      red_line <- as.numeric(red_line) * 60
      blue_line <- as.numeric(blue_line) *60

      #Filter the data between the red and blue lines. This defines the integration boundaries
      integrated_data <- eie_df[eie_df$mt.seconds >= red_line & eie_df$mt.seconds <= blue_line, ]

      #Define name that will macth to existing metadata.
      intensity_column <- paste(plotname, "intensity", sep = " ")
      print("starting integration")

      #Load variables used for integrating
      time <- integrated_data$mt.seconds
      intensity <- integrated_data[[intensity_column]]

       #Find the peak apex within the range
       apex_index <- which.max(intensity)
       apex_time <- time[apex_index]
       apex_intensity <- intensity[apex_index]

       #Calculate the area using the trapezoidal rule
       area <- tryCatch({
         AUC(time,
             intensity,
             method = "trapezoid",
             from = min(time),
             to = max(time),
             absolutearea = FALSE,
             na.rm = FALSE)
       }, error = function(e) {
         showNotification(paste("Error in AUC calculation:", e), type = "error")
         return(NA)
       })

       #Check is error is NA or not
       if (is.na(area)) {
         showNotification("Error: Area calculation returned NA", type = "error")
         return(NA)
       }

       #Adjust for baseline
       baseline_adjustment <- (blue_line - red_line) * min(intensity)
       area <- area - baseline_adjustment

       #Determine the peak number to use
       selected_peak_index <- if (!is.null(peak_number)) {
         as.numeric(peak_number)
       } else {
         input$peak_info_table_rows_selected
       }

       #Update the specific row in peaks_df with the new integration data
       peaks_df[selected_peak_index, paste0(plotname, ".start.seconds")] <- red_line
       peaks_df[selected_peak_index, paste0(plotname, ".apex.seconds")] <- apex_time
       peaks_df[selected_peak_index, paste0(plotname, ".end.seconds")] <- blue_line
       peaks_df[selected_peak_index, paste0(plotname, ".start_intensity")] <- min(intensity)
       peaks_df[selected_peak_index, paste0(plotname, ".apex_intensity")] <- apex_intensity
       peaks_df[selected_peak_index, paste0(plotname, ".end_intensity")] <- min(intensity)
       peaks_df[selected_peak_index, paste0(plotname, ".peak.area")] <- area

       #Update comment_df to remove any comments for the metabolite
       comment_df <- plot_list_data_values$comment_df
       if (plotname %in% colnames(comment_df)) {
         comment_df[selected_peak_index, plotname] <- ""}

       #Update peak_area_df with the new peak area
       peak_area_df[selected_peak_index, paste0(plotname)] <- area
       plot_list_data_values$peak_mt_df[selected_peak_index, plotname] <- apex_time / 60

       #Create temporary integration_data for the manually integrated peak to add to existing integration-data later
       temp_integration_data <- data.frame(
         "peak.number" = selected_peak_index,
         "mt.seconds" = time,
         "intensity" = intensity,
         "baseline" = min(intensity)
       )

       #Load existing integration_data. Convert the peak number from factor to character
       integration_data <- plot_data$integration_data
         integration_data <- as.data.frame(lapply(integration_data, function(x) if(is.factor(x)) as.character(x) else x))

       #Check if the peak number exists in the existing integration_data and replace existing data if peak is already there
       if (selected_peak_index %in% integration_data$peak.number) {
         integration_data <- integration_data[integration_data$peak.number != selected_peak_index, ]
       }

       #Add the temporary integration_data to the existing integration_data
       integration_data <- rbind(integration_data, temp_integration_data)

       #Update annotation_data with the new peak.apex.seconds and peak.height.counts
       annotation_data <- plot_data$annotation_data
       annotation_data$peak.apex.seconds[selected_peak_index] <- apex_time
       annotation_data$peak.height.counts[selected_peak_index] <- apex_intensity
       annotation_data$comment[selected_peak_index] <- ""

       #Update values with new data
       plot_list_data_values$plot_list[[plotname]]$integration_data <- integration_data
       plot_list_data_values$plot_list[[plotname]]$annotation_data <- annotation_data
       plot_list_data_values$comment_df <- comment_df
       plot_list_data_values$peak_area_df <- peak_area_df
       plot_list_data_values$peaks_df <- peaks_df

       #Mark the plot as modified
       modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

       #Save the updated peaks_df back to the plot_list_data.RData file
       save_plot_data(plotname)

       #Clear workspace
       rm(list = c())
       gc()

       showNotification("Integration Successful. Metadata updated", type = "message")

    })
  }
  
  
  ######4.7.3 Applying Integration Functions######
  observe_action(input$manual_integrate, {
    #Check to see if the user has selected a row in the peak info table. If not, launch modal function.
    if (is.null(input$peak_info_table_rows_selected) || length(input$peak_info_table_rows_selected) == 0) {peak_input_modal()} else {
      manual_peak_integration(input$peak_info_table_rows_selected)
    }
    
    #Update the UI to reflect new data
    output$peak_info_table <- DT::renderDataTable({
      req(input$plot_table_rows_selected)
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", run_metadata$file_name)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
      plot_list <- run_metadata$plot_list
      
      if (plotname %in% names(plot_list)) {
        annotation_data <- plot_list[[plotname]]$annotation_data
        annotation_data
      } else {
        data.frame()  
      }
    }, options = list(pageLength = 13), selection = 'multiple')
  })
  
  #Button for if user uses modal peak selection
  observe_action(input$confirm_peak_number, {
    removeModal()
    manual_peak_integration(input$manual_peak_number)
    
    #Update the UI to reflect new data
    output$peak_info_table <- DT::renderDataTable({
      req(input$plot_table_rows_selected)
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", run_metadata$file_name)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
      plot_list <- run_metadata$plot_list
      
      if (plotname %in% names(plot_list)) {
        annotation_data <- plot_list[[plotname]]$annotation_data
        annotation_data
      } else {
        data.frame()  
      }
    }, options = list(pageLength = 13), selection = 'multiple')
  })
  
  ######4.7.4 Logic for Adjusting Individual Integration baselines######
  #Reactive value for turning the baseline adjustment mode on or off for individual adjustment.
  baseline_adjustment_mode <- reactiveVal(FALSE)
  plotbaseline_adjustment_mode <- reactiveVal(FALSE)
  
  #Modal Function for specifying which peak you are editing if user fails to select a peak.
  peak_input_modal_adjustment <- function() {
    showModal(modalDialog(
      title = "Manual Peak Input",
      textInput("baseline_peak_number", "Enter peak number of peak you are adjusting:", ""),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("baseline_peak_number_adjustment", "Confirm")
      )))}
  
  #Function for adjusting individual baseline
  adjust_individual_baseline <- function(peak_index = NULL){
    req(input$plot_table_rows_selected)
    perform_peak_edit("Adjust individual baseline", function() {

      #define variables required for plotting
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)

      #Mark the plot as modified
      modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

      #Use clicked Y value as the new baseline
      new_baseline <- session$userData$clicked_position$y
      print(paste("New baseline:", new_baseline))

      #load plot data
      plot_data <- plot_list_data_values$plot_list[[plotname]]
      eie_df <- plot_data$eie_data
      peaks_df <- plot_list_data_values$peaks_df
      peak_area_df <- plot_list_data_values$peak_area_df

      #Determine the peak from the selected row in the peak info table or from the modal input
      if (is.null(peak_index)) {
        peak_index <- input$peak_info_table_rows_selected
      } else {
        peak_index <- as.numeric(peak_index)
      }

      #Get the integration boundaries from peaks_df
      left_boundary <- peaks_df[peak_index, paste0(plotname, ".start.seconds")]
      right_boundary <- peaks_df[peak_index, paste0(plotname, ".end.seconds")]

      #Filter the data between the left and right boundaries
      integrated_data <- eie_df[eie_df$mt.seconds >= left_boundary & eie_df$mt.seconds <= right_boundary, ]

      #Define name that will match to existing metadata
      intensity_column <- paste(plotname, "intensity", sep = " ")

      #Load variables used for integrating
      time <- integrated_data$mt.seconds
      intensity <- integrated_data[[intensity_column]]

      #Calculate the area using the trapezoidal rule with the new baseline
      area <- tryCatch({
        AUC(time,
            intensity,
            method = "trapezoid",
            from = min(time),
            to = max(time),
            absolutearea = FALSE,
            na.rm = FALSE)
      }, error = function(e) {
        showNotification(paste("Error in AUC calculation:", e), type = "error")
        return(NA)
      })

      #Check if error is NA or not
      if (is.na(area)) {
        showNotification("Error: Area calculation returned NA", type = "error")
        return(NA)
      }

      #Adjust for baseline
      baseline_adjustment <- (right_boundary - left_boundary) * new_baseline
      area <- area - baseline_adjustment

      #Update the specific row in peaks_df with the new integration data
      peaks_df[peak_index, paste0(plotname, ".start_intensity")] <- min(intensity)
      peaks_df[peak_index, paste0(plotname, ".end_intensity")] <- min(intensity)
      peaks_df[peak_index, paste0(plotname, ".peak.area")] <- area

      #Update peak_area_df with the new peak area
      peak_area_df[peak_index, paste0(plotname)] <- area

      #Create temporary integration_data for the manually integrated peak to add to existing integration-data later
      temp_integration_data <- data.frame(
        "peak.number" = peak_index,
        "mt.seconds" = time,
        "intensity" = intensity,
        "baseline" = new_baseline)

      #Load existing integration_data. Convert the peak number from factor to character
      integration_data <- plot_data$integration_data

      integration_data <- as.data.frame(lapply(integration_data, function(x) if(is.factor(x)) as.character(x) else x))

      #Check if the peak number exists in the existing integration_data and replace existing data if peak is already there
      if (peak_index %in% integration_data$peak.number) {
        integration_data <- integration_data[integration_data$peak.number != peak_index, ]
      }

      #Add the temporary integration_data to the existing integration_data with the new baseline
      integration_data <- rbind(integration_data, temp_integration_data)

      #Update values with new data
      plot_list_data_values$plot_list[[plotname]]$integration_data <- integration_data
      plot_list_data_values$peak_area_df <- peak_area_df
      plot_list_data_values$peaks_df <- peaks_df


      #Save the updated peaks_df back to the plot_list_data.RData file
      save_plot_data(plotname)

      #Clear workspace
      rm(list = c())
      gc()

      showNotification("Baseline adjusted for individual peak. Area Updated. Metadata updated", type = "message")

    })
  }
  
  ######4.7.5 Applying manual basline adjustment on individual peaks######
  #Toggle baseline adjustment mode for individual peaks
  observe_action(input$adjust_indiv_baseline, {
    baseline_adjustment_mode(TRUE)
    plotbaseline_adjustment_mode(FALSE)
    showNotification("Baseline adjustment mode activated", type = "message")
    showNotification("Click on the plot to define the baseline for the individual peak", type = "message")
  })
  
  #Observe click events on the plot only when baseline adjustment mode is active
  observe_action(plot_event_data("plotly_click", "peakmeister_selected"), {
    if (baseline_adjustment_mode()) {
      click_data <- plot_event_data("plotly_click", "peakmeister_selected")
      if (!is.null(click_data)) {
        clicked_x <- click_data$x
        clicked_y <- click_data$y
        
        print(paste("Clicked at:", clicked_x, clicked_y))
        #Store the clicked position for baseline adjustment
        session$userData$clicked_position <- list(x = clicked_x, y = clicked_y)
        
        #Check if a peak is selected
        if (is.null(input$peak_info_table_rows_selected) || length(input$peak_info_table_rows_selected) == 0) {peak_input_modal_adjustment()} else {adjust_individual_baseline(input$peak_info_table_rows_selected)
        }
        
        #Deactivate baseline adjustment mode after handling the click
        baseline_adjustment_mode(FALSE)
      } else {
        showNotification("No valid click data received.", type = "error")
        showNotification("Error: No click detected on the plot.", type = "error")
      }
    } else {
      showNotification("Baseline adjustment mode is inactive.", type = "message")  
    }
  })
  
  #Button for if user uses modal peak selection for baseline adjustment
  observe_action(input$baseline_peak_number_adjustment, {
    removeModal()
    adjust_individual_baseline(input$baseline_peak_number)
  })
  
  
  ######4.7.6 Logic for Adjusting baseline across all peaks in selcetd plot######
  #Modal to render plot to adjust baseline on
  show_adjust_all_baselines_modal <- function() {
    showModal(modalDialog(
      title = "Adjust All Baselines",
      plotlyOutput("adjust_baseline_plot"),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("confirm_adjust_all_baselines", "Confirm")
      )
    ))
    plotbaseline_adjustment_mode(TRUE)
  }
  
  #Function to adjust all baselines in the plot
  adjust_plot_baseline <- function(plot_baseline) {
    req(input$plot_table_rows_selected)
    perform_peak_edit("Adjust all baselines", function() {

      #Initialize variables and load data
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)

      #Mark the plot as modified
      modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

      plot_data <- plot_list_data_values$plot_list[[plotname]]
      eie_df <- plot_data$eie_data
      peaks_df <- plot_list_data_values$peaks_df
      peak_area_df <- plot_list_data_values$peak_area_df
      integration_data <- plot_data$integration_data

      #Loop through all peaks
      for (peak_index in 1:nrow(peaks_df)) {

        #Get boundaries of the individual peaks to integrate between
        left_boundary <- peaks_df[peak_index, paste0(plotname, ".start.seconds")]
        right_boundary <- peaks_df[peak_index, paste0(plotname, ".end.seconds")]

        integrated_data <- eie_df[eie_df$mt.seconds >= left_boundary & eie_df$mt.seconds <= right_boundary, ]
        intensity_column <- paste(plotname, "intensity", sep = " ")
        time <- integrated_data$mt.seconds
        intensity <- integrated_data[[intensity_column]]

        #Area function
        area <- tryCatch({
          AUC(time,
              intensity,
              method = "trapezoid",
              from = min(time),
              to = max(time),
              absolutearea = FALSE,
              na.rm = FALSE)
        }, error = function(e) {
          showNotification(paste("Error in AUC calculation:", e), type = "error")
          return(NA)})

        #Check if area is NA
        if (is.na(area)) {
          showNotification("Error: Area calculation returned NA", type = "error")
          next
        }

        #Adjust baseline and update area
        baseline_adjustment <- (right_boundary - left_boundary) * plot_baseline
        area <- area - baseline_adjustment

        peaks_df[peak_index, paste0(plotname, ".peak.area")] <- area
        peak_area_df[peak_index, paste0(plotname)] <- area

        #Update integration data
        temp_integration_data <- data.frame(
          "peak.number" = peak_index,
          "mt.seconds" = time,
          "intensity" = intensity,
          "baseline" = plot_baseline)

        integration_data <- as.data.frame(lapply(integration_data, function(x) if(is.factor(x)) as.character(x) else x))
        if (peak_index %in% integration_data$peak.number) {
          integration_data <- integration_data[integration_data$peak.number != peak_index, ]
        }
        integration_data <- rbind(integration_data, temp_integration_data)
      }

      #Update metadata
      plot_list_data_values$plot_list[[plotname]]$integration_data <- integration_data
      plot_list_data_values$peak_area_df <- peak_area_df
      plot_list_data_values$peaks_df <- peaks_df

      save_plot_data(plotname)

      showNotification("All baselines adjusted. Areas and metadata updated.", type = "message")

    })
  }
  
  ######4.7.7 Applying baseline correction across all peaks in selected plot######
  #Button for the "adjust_all_baselines" button
  observe_action(input$adjust_all_baselines, {
    plotbaseline_adjustment_mode(TRUE)
    baseline_adjustment_mode(FALSE) 
    show_adjust_all_baselines_modal()
    showNotification("Baseline adjustment mode for all peaks activated", type = "message")
    showNotification("Click on the plot to define the baseline for all peaks", type = "message")
  })
  
  #Function for rendering the selected plot in the modal
  output$adjust_baseline_plot <- renderPlotly({
    req(input$plot_table_rows_selected, db_con())
    con       <- db_con()
    folder    <- main_folder()
    file_name <- sub("\\.mz5$", "", input$file_selector)
    selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
    metabolite <- sub(paste0("^", file_name, "_"), "", selected_plot_name)
    
    plot_data <- tryCatch(
      read_plot_data_from_db(con, folder, file_name, metabolite),
      error = function(e) NULL
    )
    req(!is.null(plot_data))
    
    #generate plot
    plot <- plot_function_plotly(
      eie_data         = plot_data$eie_data,
      annotation_data  = plot_data$annotation_data,
      integration_data = plot_data$integration_data,
      label_data       = plot_data$label_data,
      x_axis_data      = plot_data$x_axis_data,
      y_axis_data      = plot_data$y_axis_data,
      source           = "peakmeister_baseline"
    )
    
    plot %>%
      layout(dragmode = "select") %>%
      event_register("plotly_click")
  })
  
  #Observer for handling click data events on the plotly plot rendered in the modal to acquire the new baseline
  observe_action(plot_event_data("plotly_click", "peakmeister_baseline"), {
    if (plotbaseline_adjustment_mode()) {
      click_data <- plot_event_data("plotly_click", "peakmeister_baseline")
      if (!is.null(click_data)) {
        plot_baseline <- click_data$y
        
        #Update all baselines with the new value and apply the baseline fun ction
        adjust_plot_baseline(plot_baseline)
        plotbaseline_adjustment_mode(FALSE)
        
        #Performance notifications 
        showNotification("New baseline set. All baselines adjusted.", type = "message")
      } else {
        showNotification("No valid click data received.", type = "error")
        showNotification("Error: No click detected on the plot.", type = "error")}
    } else {
      showNotification("Baseline adjustment mode is inactive.", type = "message")}
  })
  
  #Observer for the "confirm_adjust_all_baselines" button
  observe_action(input$confirm_adjust_all_baselines, {
    removeModal()
  })
  
  #####4.8 Server logic for dual EIE viewing.#####
  #Populate plot tables of plots you wish you display
  output$plottable1 <- renderDataTable({
    data.frame(Plot = filtered_plot_names())
  }, selection = 'single')
  
  output$plottable2 <- renderDataTable({
    data.frame(Plot = filtered_plot_names())
  }, selection = 'single')
  
  output$plottable3 <- renderDataTable({
    data.frame(Plot = filtered_plot_names())
  }, selection = 'single')

  
  #Observe selected plots and render a combined subplot of these functions to zoom in on peaks
    observe_updates({
      sel1 <- input$plottable1_rows_selected
      sel2 <- input$plottable2_rows_selected
      sel3 <- input$plottable3_rows_selected
      
      selected_indices <- unique(na.omit(c(sel1, sel2, sel3)))
      
      #generate combined plot depending on if 2 OR 3 plots are selected.
      if (length(selected_indices) >= 2) {
        req(db_con())
        con            <- db_con()
        folder         <- main_folder()
        file_name      <- sub("\\.mz5$", "", input$file_selector)
        selected_names <- filtered_plot_names()[selected_indices]
        
        #Generate each plot from SQL database on demand
        plots <- lapply(selected_names, function(name) {
          metabolite <- sub(paste0("^", file_name, "_"), "", name)
          plot_data  <- tryCatch(
            read_plot_data_from_db(con, folder, file_name, metabolite),
            error = function(e) NULL
          )
          if (is.null(plot_data)) return(NULL)
          plot_function_plotly(
            eie_data         = plot_data$eie_data,
            annotation_data  = plot_data$annotation_data,
            integration_data = plot_data$integration_data,
            label_data       = plot_data$label_data,
            x_axis_data      = plot_data$x_axis_data,
            y_axis_data      = plot_data$y_axis_data
          )
        })
        
        #Remove any plots that failed to load
        plots <- Filter(Negate(is.null), plots)
        
        #render if successful and combine plot names into one title 
        if (length(plots) == length(selected_names)) {
          cleaned_names  <- sub(paste0("^", file_name, "_"), "", selected_names)
          combined_title <- paste("EIE of", paste(cleaned_names, collapse = ", "))
          
          #combine individual plots into stacked subplots with shared x axis
          output$combined_plot <- renderPlotly({
            subplot(plots, nrows = length(plots), 
                    shareX = TRUE, titleX = TRUE, titleY = TRUE) %>%
              layout(title = combined_title)
          })
        }
      }
    })    
  
  #####4.9 Marking Interferences#####
  # Session action called by the interferences button.
  mark_peak_interferences <- function() {
    if (!length(input$peak_info_table_rows_selected)) {
      showNotification("Select peak rows in the Peak Position Information table first.", type = "message")
      return(invisible(FALSE))
    }

    req(input$plot_table_rows_selected)
    perform_peak_edit("Mark peak interference", function() {
      req(input$peak_info_table_rows_selected)

      selected_rows <- input$peak_info_table_rows_selected

      #Extract the current annotation_data
      selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]
      base_file_name <- sub("\\.mz5$", "", input$file_selector)
      plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
      plot_list <- plot_list_data_values$plot_list

      #Mark the plot as edited so only plots that have been edited can be regenerated later
      modified_peak_plots$names <- unique(c(modified_peak_plots$names, selected_plot_name))

      if (plotname %in% names(plot_list)) {
        annotation_data <- plot_list[[plotname]]$annotation_data
        integration_data <- plot_list[[plotname]]$integration_data

        #Loop through each selected row
        for (selected_row in selected_rows) {
          #Get the peak number from the selected row to allow matching accross various acccesible data streams
          peak_number <- annotation_data$peak.number[selected_row]

          #Update the comment column for the selected peak
          annotation_data$comment[selected_row] <- "Interferred"

          #Update comment_df so peak areas can be recauculated/reintegrated later on
          if (plotname %in% colnames(plot_list_data_values$comment_df)) {
            plot_list_data_values$comment_df[peak_number, plotname] <- "Interferred"
          }

          #Remove all integration_data associated with the relevant peak number so regenerated plots will update with the interferred peaks once regenerated
          integration_data <- integration_data[integration_data$peak.number != peak_number, ]
        }

        #Update the plot_list with the modified annotation_data
        plot_list[[plotname]]$annotation_data <- annotation_data
        plot_list[[plotname]]$integration_data <- integration_data

        #Update the reactive plot_list_data
        plot_list_data_values$plot_list <- plot_list
      }

      save_plot_data(plotname)

      #Reload the updated data
      subfolder_path <- file.path(main_folder(), "Data", run_metadata$file_name)
      reload_plot_data(subfolder_path)

      #Update reactive values directly
      plot_list_data_values$plot_list <- plot_list
      plot_list_data_values$comment_df <- plot_list_data_values$comment_df


      #Update the peak_info_table
      output$peak_info_table <- DT::renderDataTable({
        req(input$plot_table_rows_selected)
        selected_plot_name <- filtered_plot_names()[input$plot_table_rows_selected]

        base_file_name <- sub("\\.mz5$", "", input$file_selector)
        plotname <- sub(paste0("^", base_file_name, "_"), "", selected_plot_name)
        plot_list <- plot_list_data_values$plot_list

        #Ensure the plotname exists in the plot_list
        if (plotname %in% names(plot_list)) {
          annotation_data <- plot_list[[plotname]]$annotation_data
          annotation_data
        } else {
          data.frame()
        }
      }, options = list(pageLength = 13), selection = 'multiple')

    })
  }

  observe_action(input$interferences, {
    mark_peak_interferences()
  })
  
####5. Downstream Processing ####   
  #####5.1 Initializing Environment for loading peak area and migration time data#####
  #Define the function to load files
  grab_metabolite_files <- function(results_folder2) {
    peak_areas_path <- file.path(results_folder2, "Metabolite Peak Areas.csv")
    migration_times_path <- file.path(results_folder2, "Metabolite Migration Times.csv")
    
    peak_areas <- if (file.exists(peak_areas_path)) {
      read.csv(peak_areas_path, stringsAsFactors = FALSE, check.names = FALSE)} else {
      warning("File not found: ", peak_areas_path)
      NULL}
    
    migration_times <- if (file.exists(migration_times_path)) {
      read.csv(migration_times_path, stringsAsFactors = FALSE, check.names = FALSE)} else {
      warning("File not found: ", migration_times_path)
      NULL}
  
    list(peak_areas = peak_areas, migration_times = migration_times)
  }
  
  #Define reactive variables for the dataframes
  peak_areas_data <- reactiveVal(NULL)
  migration_times_data <- reactiveVal(NULL)

  # A different saved analysis must be loaded before downstream transformations.
  observe_action(input$results_folder2, {
    peak_areas_data(NULL)
    migration_times_data(NULL)
  }, ignoreNULL = FALSE, priority = 100)
  
  #Observer for the action button
  observe_action(input$load_migration_area, {
    req(input$results_folder2)
    files <- grab_metabolite_files(input$results_folder2)
    peak_areas_data(files$peak_areas)
    migration_times_data(files$migration_times)
    
    showNotification("Data loaded", type = "message")
  })
  
  #Set results folder to work out of
  main_folder2 <- reactive({
      req(input$results_folder2)
      input$results_folder2
    })
  
  #Observe functions for selecting files and results folders to work with
  observe_updates({
    results_folders_reactive()  # Refresh when completed results are discovered.
    files <- uploadedmz5()$FileName
    filename <- input$file_selector2
    if (length(filename) != 1L || !filename %in% files) filename <- head(files, 1L)
    folders <- list_results_folders(filename, selected_saved_run())
    current <- isolate(input$results_folder2)
    visualization <- isolate(input$results_folder)
    updateSelectInput(session, "results_folder2", choices = c("Select a saved analysis" = "",
                      analysis_folder_choices(folders)),
      selected = if (length(current) == 1L && current %in% folders) current else
        if (length(visualization) == 1L && visualization %in% folders) visualization else "")
  })
  observe_updates({
    files <- uploadedmz5()$FileName
    current <- isolate(input$file_selector2)
    updateSelectInput(session, "file_selector2", choices = files,
      selected = if (length(current) == 1L && current %in% files) current else head(files, 1L))
  })
  
  
  #####5.2 Plot for m/z vs migration time #####
  #Function to extract m/z and names from the name vector
  extract_mass <- function(name_vec) {
    mz <- as.numeric(sub("_.*", "", name_vec))
    names <- sub("^[^_]*_", "", name_vec)
    data.frame(mz = mz, name = names)
  }
  
  #Reactive expression to create a data frame for plotting
  mzMT_data <- reactive({
    
    #Initialize variables 
    name_vec <- c(refMassListData()$name, massData()$name)
    req(migration_times_data(), name_vec, input$peak_number)
    mz_df <- extract_mass(name_vec)
    migration_times <- migration_times_data()
    base_file_name <- sub("\\.mz5$", "", input$file_selector2)
    
    #Filter data
    start_row <- which(migration_times$file.name == base_file_name)
    next_file_row <- which(migration_times$file.name != "" & migration_times$file.name != base_file_name & seq_along(migration_times$file.name) > start_row)[1]
    end_row <- ifelse(is.na(next_file_row), nrow(migration_times), next_file_row - 1)
    
    #Filter the data for the selected base file name block
    filtered_migration_time <- migration_times[start_row:end_row, ]
    migration_times_filtered <- filtered_migration_time[filtered_migration_time$peak.number == input$peak_number, ]
    migration_times_filtered <- migration_times_filtered[, !colnames(migration_times_filtered) %in% c("file.name", "peak.number")]
    
    #Extract m/z values from the column names in migration_times_filtered and match them
    mz_values <- as.numeric(sub("^([0-9.]+)_.*", "\\1", colnames(migration_times_filtered)))
    matched_columns <- colnames(migration_times_filtered)[match(mz_df$mz, mz_values)]
    
    #Extract names from metadata to colour code metabolites and internal standards
    ref_names <- sub("^[0-9.]+_", "", refMassListData()$name)
    
    #Create a data frame for plotting
    plot_df <- data.frame(
      mz = mz_df$mz,
      migration_time = unlist(migration_times_filtered[, matched_columns]),
      name = mz_df$name,
      Type = ifelse(mz_df$name %in% ref_names, "Internal Standard", "Metabolite")
    )
  })
  
  #Make plotly plot of m/z vs. migration time. 
  output$mz_vs_migration_plot <- renderPlotly({
    plot_df <- mzMT_data()
    
    #Make the plot
    p <- ggplot(plot_df, aes(x = migration_time, y = mz, text = name, fill = Type)) +
      geom_point(shape = 21, size = 3, alpha = 0.7, color = "black") + 
      scale_fill_manual(values = c("Metabolite" = "green", "Internal Standard" = "darkorange")) +
      labs(title = "m/z versus Migration Time (min) for all analytes", x = "Migration Time (min)", y = "m/z") +
      scale_x_continuous(limits = c(0, 40), breaks = seq(0, 50, by = 2)) +
      theme_classic() +  theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5, size = 16))
    
    ggplotly(p, tooltip = "text") %>% layout(legend = list(orientation = "h", x = 0.4, y = -0.2))
  })
  
  #Render the peak number selector
  output$peak_number_selector <- renderUI({
    num_peaks <- parametersData()$number.of.injections
    selectInput("peak_number", "Select Peak Number:", choices = 1:num_peaks)
  })
  
  
  # Normalize the selected columns using one reference metabolite.
  normalize_peak_areas <- function(data, normalize_by, name_vec) {
    if (!(normalize_by %in% name_vec)) {
      showNotification("Selected normalization metabolite not found in data columns.", type = "error")
      return(data)}

    #Convert non-numeric values to NA and ensure all columns are now numeric
    data <- data %>%
      mutate(across(all_of(name_vec), ~ suppressWarnings(ifelse(grepl("^[0-9.]+$", .), as.numeric(.), NA_real_))))
    if (all(is.na(data[[normalize_by]]))) {
      showNotification("Normalization column does not contain any numeric values.", type = "error")
      return(data)}

    #Normalize each row by the corresponding area for the metabolite you are using to normalize.
    data <- data %>%
      rowwise() %>%
      mutate(across(all_of(name_vec), ~ ifelse(!is.na(.data[[normalize_by]]) & !is.na(.), . / .data[[normalize_by]], .)))
    return(data)
  }

  #####5.3 Normalize to Creatine, F-Phe, or Cl-Tyr#####
  #Show modal for normalization options
  observe_action(input$normalize, {
    showModal(modalDialog(
      title = "Normalization Options",
      selectInput("normalize_by", "Normalize By", choices = c("114.0667_Creatinine", "184.0774_F-Phe", "216.0427_Cl-Tyr", "182.0617_F-Phe","198.0566_F-Tyr", "214.0271_Cl-Tyr","207.0115_NMS", "212.9412_Bromohypoxanthine")),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("confirm_normalize", "Normalize")
      ),
      easyClose = TRUE
    ))
  })
  
  #Event handler for normalizing the data.
  observe_action(input$confirm_normalize, {
    removeModal()
    
    #Load data and initialize the environment youre working in.
    name_vec <- c(refMassListData()$name, massData()$name)
    results_folder2 <- main_folder2()
    area <- peak_areas_data()
    
    #Check if data is NULL or empty to prevent crashing 
    if (is.null(area) || nrow(area) == 0) {
      showNotification("No data uploaded. Please upload data before proceeding.", type = "error")
      return()
    }
    

    
    #Apply function to data
    normalized_data <- normalize_peak_areas(area, input$normalize_by, name_vec)
    
    #Update reactive data
    peak_areas_data(normalized_data)
     
    #Save normalized data to a new CSV file so original datafile is preserved
    write.csv(normalized_data, file.path(results_folder2, "Normalized Metabolite Peak Areas.csv"), row.names = FALSE, fileEncoding = "UTF-8")
    showNotification("Data successfully normalized", type = "message")
  })
  
  
  # Apply the chosen existing missing-value replacement rule.
  replace_missing_peak_areas <- function(data, name_vec, method) {
    #Convert non-numeric values to NA
    data <- data %>%
      mutate(across(all_of(name_vec), ~ suppressWarnings(ifelse(grepl("^[0-9.]+$", .), as.numeric(.), NA_real_))))

    #Replace missing values with the minimum/five
    if (method == "Minimum Values/5") {
      for (col in name_vec) {
        min_value <- min(data[[col]], na.rm = TRUE) / 5
        data[[col]][is.na(data[[col]])] <- min_value}
    }

    #Replace missing values values with 0
    else if (method == "Missing values = 0") {
      data[is.na(data)] <- 0}

    data
  }

  #####5.4 Replacing missing values in data#####
  observe_action(input$missing_data, {
    
    #Intialize environment, define variables
    results_folder2 <- main_folder2()
    data <- peak_areas_data()
    name_vec <- c(refMassListData()$name, massData()$name)
    
    #Check if data is NULL or empty to prevent crashing 
    if (is.null(data) || nrow(data) == 0) {
      showNotification("No data uploaded. Please upload data before proceeding.", type = "error")
      return()
    }
    
    data <- replace_missing_peak_areas(data, name_vec, input$missing_data_method)

    #Update reactive data
    peak_areas_data(data)
    
    #Save to a .CSV file
    write.csv(data, file.path(results_folder2, "Corrected Missing Values Metabolite Peak Areas.csv"), row.names = FALSE, fileEncoding = "UTF-8")
    showNotification("Data successfully corrected", type = "message")
  })
  
  
  # Assign sample IDs by data-file name and injection/peak number.
  connect_peak_area_metadata <- function(area, metadata) {
    #identify peak columns in metadata file. Designed to by dynamic with changing peak numbers
    peak_columns <- grep("^[0-9]+$", names(metadata), value = TRUE)

    #Remove empty columns (just in case) and transform data to long format
    metadata <- metadata[, colSums(is.na(metadata)) < nrow(metadata)]
    metadata_long <- metadata %>%
      pivot_longer(cols = all_of(peak_columns), names_to = "peak.number", values_to = "PBM Sample ID") %>%
      select(`Data file`, peak.number, `PBM Sample ID`)

    #Filter metadata file to connect filenames in actual results with the samples IDs for each file & peak
    filter_data_by_file_name <- function(data, file_name) {
      start_row <- which(data$file.name == file_name)
      next_file_row <- which(data$file.name != "" & data$file.name != file_name & seq_along(data$file.name) > start_row)[1]
      end_row <- ifelse(is.na(next_file_row), nrow(data), next_file_row - 1)
      data[start_row:end_row, ]}

    merged_data <- do.call(rbind, lapply(unique(area$file.name[area$file.name != ""]), function(file_name) {
      filtered_area <- filter_data_by_file_name(area, file_name)
      filtered_metadata <- metadata_long[metadata_long$`Data file` == file_name, ]
      merged <- merge(filtered_area, filtered_metadata, by.x = "peak.number", by.y = "peak.number", all.x = TRUE)
      merged <- merged %>% select(-`Data file`) %>% relocate(`PBM Sample ID`, .after = file.name)
      return(merged)
    }))

    #Trim any leading or trailing whitespace (found in some of the metadata files for unknown resason)
    merged_data$`PBM Sample ID` <- trimws(merged_data$`PBM Sample ID`, whitespace = "[\\h\\v]")

    merged_data
  }

  #####5.5 Connect Peak Position with Metadata#####

  # Resolve from the selected analysis path, independently of other file selectors.
  metadata_file_paths <- function(results_path) {
    folder <- normalizePath(results_path, winslash = "/", mustWork = TRUE)
    paths <- file.path(folder, "Data", "metadata.csv")
    run_folder <- dirname(folder)
    if (identical(basename(dirname(run_folder)), "Results") &&
        grepl("^Results", basename(folder))) {
      paths <- c(file.path(run_folder, "metadata.csv"), paths)
    }
    paths
  }
  
  #Observe action button for connecting metadata
  observe_action(input$connect_metadata, {
    results_path <- main_folder2()
    paths <- metadata_file_paths(results_path)
    available <- paths[file.exists(paths) & !dir.exists(paths)]
    
    if (!length(available)) {
      showNotification(paste("metadata.csv not found. Place it at", paths[1]),
                       type = "warning", duration = 10)
      return(NULL)
    }
    metadata_path <- available[1]
    
    #Load data
    metadata <- read.csv(metadata_path, check.names = FALSE)
    area <- peak_areas_data()
    
    #Check if metadata is NULL or empty 
    if (is.null(metadata) || nrow(metadata) == 0) {
      showNotification("No metadata uploaded. Please upload data before proceeding.", type = "error")
      return()
    }
    
    #Check if data is NULL or empty 
    if (is.null(area) || nrow(area) == 0) {
      showNotification("No data uploaded. Please upload data before proceeding.", type = "error")
      return()
    }
    
    merged_data <- connect_peak_area_metadata(area, metadata)

    #Add merged data to reactive data file and save it to a .CSV
    peak_areas_data(merged_data)
    
    write.csv(merged_data, file.path(results_path, "merged_peak_area.csv"), row.names = FALSE, fileEncoding = "UTF-8")
    source <- if (length(paths) > 1L && identical(metadata_path, paths[1])) {
      "the shared run metadata.csv"
    } else "the analysis Data/metadata.csv"
    showNotification(paste("Metadata successfully connected from", source), type = "message")
  })
  
  
  # Plot peak areas, their mean and the three-standard-deviation limits.
  build_control_chart <- function(areas, selected_metabolite, data_label) {
    plot_ly() %>%
      add_trace(x = seq_along(areas), y = areas, type = 'scatter', mode = 'lines+markers', name = 'Metabolite Peak Area') %>%
      add_lines(x = seq_along(areas), y = mean(areas), line = list(color = 'blue'), name = 'Mean') %>%
      add_lines(x = seq_along(areas), y = mean(areas) + 3 * sd(areas), line = list(color = 'black', dash = 'dash'), name = 'Upper Control Limit') %>%
      add_lines(x = seq_along(areas), y = mean(areas) - 3 * sd(areas), line = list(color = 'black', dash = 'dash'), name = 'Lower Control Limit') %>%
      layout(title = paste("Control Chart for", selected_metabolite, data_label),
             xaxis = list(title = "Sample", showgrid =FALSE, dtick = 5),
             yaxis = list(title = "Peak Area", showgrid =FALSE),
             legend = list(orientation = 'h', x = 0.5, xanchor = 'center', y = -0.2),
             font = list(family = "sans-serif"))
  }

  #####5.6 Control Charts#####
  #Update the selectInput choices based on the reactive value
  observe_updates({
    ref_data <- refMassListData()
    if (!is.null(ref_data) && nrow(ref_data) > 0) {
      updateSelectInput(session, "selected_metabolite", choices = ref_data$name)
    }
  })
  
  ######5.6.1 Control Charts for Non-normalized data######
  observe_action(input$create_control_chart, {
    req(input$selected_metabolite)
    
    #Initialize environment, load data, acquire names of selected metabolite for control chart
    selected_metabolite <- input$selected_metabolite
    results_path <- main_folder2()
    files <- grab_metabolite_files(results_path)
    
    #Load basic raw matrix. This data wont have any correction for missing values or anything normalized
    raw_peak_areas <- files$peak_areas
    
    #Extract the data for the selected metabolite
    raw_metabolite_areas <- raw_peak_areas[[selected_metabolite]]
    
    #Generate control chart
    output$control_chart_raw <- renderPlotly({
      build_control_chart(raw_metabolite_areas, selected_metabolite, "(Raw Data)")
    })
    showNotification("Control Chart Generated", type = "message")
  })
  
  
  ######5.6.2 Control Charts for normalized data######
  observe_action(input$create_control_chart, {
    req(input$selected_metabolite)
    
    #Initialize environment, load data, acquire names of selected metabolite for control chart
    selected_metabolite <- input$selected_metabolite
    peak_areas <- peak_areas_data()
    metabolite_data <- peak_areas[[selected_metabolite]]
    
    #Generate control chart
    output$control_chart_processed <- renderPlotly({
      build_control_chart(metabolite_data, selected_metabolite, "(Processed Data)")
    })
  })
  
  
  #####5.7 CV and PCA determination for QC variance checks#####
  ######5.7.1 Define functions to calculate CV######
  
  #CV calculation function 
  calculate_cv <- function(data){
    apply(as.matrix(data), 2, function(x) {
      if (length(x) < 2L || any(!is.finite(x)) || mean(x) == 0) return(NA_real_)
      sd(x) / mean(x) * 100
    })
  }
  
  #Reactive expression to calculate CVs
  cv_data <- reactive({
    data <- peak_areas_data()
    metabolite_data <- data[, 4:ncol(data)]
    cv <- calculate_cv(metabolite_data)
    return(cv)
  })
  
  ######5.7.2 Define functions for creating PCA plots######
  #Function to perform Pareto scaling
  pareto_scale <- function(data) {
    scaled_data <- scale(data, center = TRUE, scale = sqrt(apply(data, 2, sd)))
    return(scaled_data)
  }
  
  #Function for removing columns with zero variance
  remove_zero_variance <- function(data) {
    data_matrix <- as.matrix(data)
    variances <- apply(data_matrix, 2, var)
    data_matrix[, is.finite(variances) & variances > 0, drop = FALSE]
  }
  
  #Function to perform PCA with additional checks
  perform_pca <- function(data) {
    tryCatch({
      data <- as.data.frame(data)
      if (nrow(data) < 3L || !ncol(data) ||
          !all(vapply(data, is.numeric, logical(1))) ||
          any(!is.finite(as.matrix(data)))) {
        stop("PCA requires at least three samples and finite numeric metabolite values.")
      }
      sample_names <- rownames(data)
      data <- remove_zero_variance(data)
      if (ncol(data) < 2L) {
        stop("PCA needs at least two metabolites with nonzero variance.")
      }

      scaled_data <- pareto_scale(data)
      # Preserve the previous PCA(scaled_data, scale.unit = TRUE) behavior:
      # center again and divide by population standard deviations before SVD.
      centered <- scale(scaled_data, center = TRUE, scale = FALSE)
      population_sd <- sqrt(colMeans(centered^2))
      population_sd[population_sd <= 1e-16] <- 1
      standardized <- sweep(centered, 2, population_sd, "/")
      ncp <- min(5L, nrow(standardized) - 1L, ncol(standardized))
      fit <- stats::prcomp(standardized, center = FALSE, scale. = FALSE, rank. = ncp)
      if (sum(fit$sdev > fit$sdev[1] * sqrt(.Machine$double.eps)) < 2L) {
        stop("PCA needs at least two independent components; these data have fewer.")
      }
      # Match the existing orientation and the two fields used by the GUI.
      direction <- sign(colSums(fit$rotation))
      direction[direction == 0] <- 1
      coordinates <- sweep(fit$x, 2, direction, "*")
      rownames(coordinates) <- sample_names
      colnames(coordinates) <- paste0("Dim.", seq_len(ncp))
      eigenvalues <- fit$sdev^2 * (nrow(standardized) - 1) / nrow(standardized)
      percent <- eigenvalues[seq_len(ncp)] / sum(eigenvalues) * 100
      eig <- cbind(eigenvalue = eigenvalues[seq_len(ncp)],
                   "percentage of variance" = percent,
                   "cumulative percentage of variance" = cumsum(percent))
      rownames(eig) <- paste("comp", seq_len(ncp))
      list(ind = list(coord = coordinates), eig = eig)
    }, error = function(e) {
      showNotification(paste("PCA unavailable:", conditionMessage(e),
                             "CV results are still available."),
                       type = "warning", duration = 10)
      NULL
    })
  }
  
  #PCA expression
  pca_data <- reactive({
    data <- peak_areas_data()
    metabolite_data <- data[, 4:ncol(data)]
    print(head(metabolite_data))
    pca_result <- perform_pca(metabolite_data)
    return(pca_result)
  })
  
  ######5.7.3 Function for extracting QC and non-QC catagories from user input######
  #Separate QCs and other samples based on user input
  # Split QC/sample groups, calculate CVs and prepare the PCA result.
  compute_quality_metrics <- function(data, category_input, exclude_ids) {
    if (is.null(data) || !nrow(data)) {
      showNotification("Load peak-area data before calculating CVs.", type = "error")
      return(NULL)
    }
    if (!"PBM Sample ID" %in% colnames(data)) {
      showNotification("Column 'PBM Sample ID' not found in data. Please connect metadata to results", type = "error")
      return(NULL)
    }
    categories <- strsplit(if (is.null(category_input)) "" else category_input, ",", fixed = TRUE)[[1]]
    pairs <- lapply(categories, function(x) trimws(strsplit(x, "=", fixed = TRUE)[[1]]))
    qc <- Filter(function(x) length(x) == 2L && identical(x[1], "QC"), pairs)
    pattern <- if (length(qc) == 1L) trimws(gsub("['\"]", "", qc[[1]][2])) else ""
    if (!nzchar(pattern)) {
      showNotification("Enter a QC identifier such as QC=NIST; QC= alone is incomplete.", type = "error")
      return(NULL)
    }
    excluded <- trimws(strsplit(if (is.null(exclude_ids)) "" else exclude_ids, ",", fixed = TRUE)[[1]])
    data <- data[!data$`PBM Sample ID` %in% excluded[nzchar(excluded)], , drop = FALSE]
    if (anyNA(data$`PBM Sample ID`) || any(!nzchar(trimws(data$`PBM Sample ID`)))) {
      showNotification("Some sample IDs are missing. Check that metadata Data file names match the results, then reconnect metadata.", type = "error", duration = 10)
      return(NULL)
    }
    is_qc <- tryCatch(suppressWarnings(grepl(pattern, data$`PBM Sample ID`, ignore.case = TRUE)),
                      error = function(e) NULL)
    if (is.null(is_qc)) {
      showNotification("The QC identifier contains an invalid matching pattern.", type = "error")
      return(NULL)
    }
    if (sum(is_qc) < 2L || sum(!is_qc) < 2L) {
      showNotification(sprintf("At least two QC and two non-QC samples are needed for this comparison (found %d QC and %d non-QC after exclusions). Check the QC identifier and excluded IDs.", sum(is_qc), sum(!is_qc)),
                       type = "error", duration = 10)
      return(NULL)
    }
    metabolites <- setdiff(names(data), c("file.name", "peak.number", "PBM Sample ID"))
    if (!length(metabolites)) {
      showNotification("No metabolite columns are available for CV calculation.", type = "error")
      return(NULL)
    }
    for (name in metabolites) {
      data[[name]] <- suppressWarnings(as.numeric(as.character(data[[name]])))
    }
    # Exclude a column only when one group has no finite measurements at all.
    unusable <- vapply(data[, metabolites, drop = FALSE], function(x) {
      all(!is.finite(x[is_qc])) || all(!is.finite(x[!is_qc]))
    }, logical(1))
    if (any(unusable)) {
      showNotification(paste("Excluding metabolites with no finite values in QC or non-QC samples:",
                             paste(metabolites[unusable], collapse = ", ")),
                       type = "warning", duration = 10)
      metabolites <- metabolites[!unusable]
    }
    if (!length(metabolites)) {
      showNotification("No usable metabolite columns remain for CV calculation.", type = "error")
      return(NULL)
    }
    if (any(!is.finite(as.matrix(data[, metabolites, drop = FALSE])))) {
      showNotification("Peak areas contain missing, nonnumeric or infinite values. Replace missing values or correct the affected data before calculating CVs.", type = "error", duration = 10)
      return(NULL)
    }
    metadata_columns <- intersect(names(data), c("file.name", "peak.number", "PBM Sample ID"))
    data <- data[, c(metadata_columns, metabolites), drop = FALSE]
    qc_samples <- data[is_qc, , drop = FALSE]
    non_qc_samples <- data[!is_qc, , drop = FALSE]
    qc_cv <- calculate_cv(qc_samples[, metabolites, drop = FALSE])
    non_qc_cv <- calculate_cv(non_qc_samples[, metabolites, drop = FALSE])
    average_finite <- function(x) if (any(is.finite(x))) mean(x[is.finite(x)]) else NA_real_
    combined_data <- rbind(qc_samples, non_qc_samples)
    pca_result <- perform_pca(combined_data[, metabolites, drop = FALSE])
    list(qc_cv = average_finite(qc_cv), non_qc_cv = average_finite(non_qc_cv),
         non_qc_cv_values = non_qc_cv, qc_cv_values = qc_cv,
         pca_result = pca_result, qc_samples = qc_samples, non_qc_samples = non_qc_samples)
  }

  average_cv <- reactive({
    compute_quality_metrics(peak_areas_data(), input$category_input, input$exclude_ids)
  })

  # Keep QC and non-QC values attached to the same metabolites after filtering/sorting.
  build_quality_cv_plot <- function(metrics) {
    metabolites <- names(metrics$non_qc_cv_values)
    plot_data <- suppressWarnings(extract_mass(metabolites))
    plot_data$qc_cv <- unname(metrics$qc_cv_values[metabolites])
    plot_data$non_qc_cv <- unname(metrics$non_qc_cv_values[metabolites])
    plot_data <- plot_data[is.finite(plot_data$mz) &
      (is.finite(plot_data$qc_cv) | is.finite(plot_data$non_qc_cv)), , drop = FALSE]
    plot_data <- plot_data[order(plot_data$mz), , drop = FALSE]
    if (!nrow(plot_data)) {
      showNotification("No finite CVs with m/z-labelled metabolites are available to plot.", type = "warning")
      return(NULL)
    }
    plot <- plot_ly(plot_data, x = ~mz, y = ~non_qc_cv, type = "scatter",
      mode = "lines+markers", text = ~name, hoverinfo = "text+x+y", name = "Non-QC CV") %>%
      add_trace(x = ~mz, y = ~qc_cv, type = "scatter", mode = "lines+markers",
        marker = list(color = "#780116"), line = list(color = "#780116"), name = "QC CV")
    for (group in c("non_qc_cv", "qc_cv")) {
      values <- metrics[[paste0(group, "_values")]]
      if (any(is.finite(values))) {
        plot <- add_trace(plot, x = plot_data$mz,
          y = rep(median(values[is.finite(values)]), nrow(plot_data)),
          type = "scatter", mode = "lines", inherit = FALSE,
          line = list(dash = "dash", color = if (group == "qc_cv") "green" else "black"),
          name = if (group == "qc_cv") "Median QC CV" else "Median Non-QC CV")
      }
    }
    plot %>% layout(title = "CV per Metabolite (QC and non-QC samples)",
      xaxis = list(title = "m/z"), yaxis = list(title = "CV (%)"),
      legend = list(orientation = "h", x = 0.5, xanchor = "center", y = -0.2))
  }

  # Only draw confidence ellipses for groups with enough independent observations.
  build_quality_pca_plot <- function(metrics) {
    if (is.null(metrics$pca_result)) return(NULL)
    pca_data <- data.frame(metrics$pca_result$ind$coord)
    pca_data$SampleType <- rep(c("QC", "Non-QC"),
      c(nrow(metrics$qc_samples), nrow(metrics$non_qc_samples)))
    variance_explained <- metrics$pca_result$eig[1:2, 2]
    plot <- ggplot(pca_data, aes(x = Dim.1, y = Dim.2, color = SampleType)) +
      geom_point() +
      scale_color_manual(values = c("QC" = "#38A700", "Non-QC" = "#780116")) +
      theme_classic() +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        axis.text = element_text(size = 14), axis.title = element_text(size = 16),
        legend.text = element_text(size = 14), legend.title = element_text(size = 16),
        plot.title = element_text(hjust = 0.5, size = 16, face = "bold")) +
      geom_hline(yintercept = 0, linetype = "dashed", color = "grey") +
      geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +
      labs(title = "Quality Control PCA Plot for QCs and Non-QC Samples (PC1 & PC2)",
        x = paste0("PC1 (", round(variance_explained[1], 2), "%)"),
        y = paste0("PC2 (", round(variance_explained[2], 2), "%)"), colour = "Sample Type")
    groups <- Filter(function(group) {
      nrow(group) >= 4L &&
        qr(scale(as.matrix(group[, c("Dim.1", "Dim.2")]), scale = FALSE))$rank == 2L
    }, split(pca_data, pca_data$SampleType))
    if (length(groups)) plot <- plot + stat_ellipse(data = do.call(rbind, groups))
    plot
  }
  
  
  ######5.7.4 Output for CV processing######
  observe_action(input$compute_cv, {
    #######5.7.4.1 CV plot#######
    # CV plot construction is delegated to build_quality_cv_plot() above.
    # Clear previous results so rejected inputs cannot leave stale plots visible.
    output$average_cv_table <- renderTable(NULL)
    output$cv_plot <- renderPlotly(NULL)
    output$pca_plot <- renderPlot(NULL)
    avg_cv <- tryCatch(average_cv(), error = function(e) {
      showNotification(paste("Could not calculate quality metrics:", conditionMessage(e)),
                       type = "error", duration = 10)
      NULL
    })
    if (is.null(avg_cv)) return()

    output$average_cv_table <- renderTable({
      data.frame(Type = c("Technical CV (%)", "Biological CV (%)"),
                 `Average CV` = c(avg_cv$qc_cv, avg_cv$non_qc_cv))
    })
    output$cv_plot <- renderPlotly({ build_quality_cv_plot(avg_cv) })
    #######5.7.4.2 Create PCA plot#######
    # PCA plot construction is delegated to build_quality_pca_plot() above.
    output$pca_plot <- renderPlot({
      shiny::validate(shiny::need(!is.null(avg_cv$pca_result),
        "PCA is unavailable for these data. CV results are shown separately."))
      pca_plot <- build_quality_pca_plot(avg_cv)
      data_folder <- file.path(main_folder2(), "Data")
      tryCatch({
        ggsave(file.path(data_folder, "QC_PCA_plot.png"), plot = pca_plot,
               width = 9, height = 6, dpi = 300)
      }, error = function(e) {
        showNotification(paste("PCA is displayed but its PNG could not be saved:",
                               conditionMessage(e)), type = "warning")
      })
      pca_plot
    })
  })

  #####5.8 Display Data#####
  #Display data
  output$peak_area_table <- renderDT({
    datatable(peak_areas_data(), extensions = 'FixedColumns', options = list(
      scrollX = TRUE,
      scrollY = "400px",
      scrollCollapse = TRUE,
      paging = FALSE,
      pageLength = 20,
      lengthMenu = c(20, 50, 100, "All"),
      fixedColumns = list(leftColumns = 4)  
    ))
  })
  
  #####5.9 Integrated Batch Correction#####
  ######5.9.1 Initialize Environment######
  # Session action called by the load_batchcorr_packages button.
  load_batch_correction_packages <- function() {
    #Note: I am aware that installing packages when the ShinyApp is already running is not ideal. However, for some reason, to install the package RcppArmadillo, which is a dependency of ChemometricsWithR and BatchCorrMetabolomics which we need to run the Batch Correction, R requires a C++ compiler of C++14. The only way I was able to achieve this was by finding the file Makevars.win located where R is stored on your computer and adding the line: CXX_STD=CXX14. Since the app crashes without this, I didnt want to include this as a requirement on setup... Also, BatchCorr wont be done with every run so why load it before?

    showNotification("Don't forget to type Yes/No or Y/N in R console to install packages", type = "warning")

    #Install packages
    if (!requireNamespace("RcppArmadillo", quietly = TRUE)) {
      install.packages("RcppArmadillo")}
    library(RcppArmadillo)

    #Install ChemometricWithR. If you just try to have R download this when installing BatchCorrMetabolomics, it fails. Hence the separation
    if (!requireNamespace("ChemometricsWithR", quietly = TRUE)) {
      remotes::install_github("rwehrens/ChemometricsWithR")}
    library(ChemometricsWithR)

    #Install BatchCorrMetabolomics after installing troublesome and required dependencies 
    if (!requireNamespace("BatchCorrMetabolomics", quietly = TRUE)) {
      remotes::install_github("rwehrens/BatchCorrMetabolomics")}
    library(BatchCorrMetabolomics)

    showNotification("Environemnt Initialized", type = "message")
  }

  observe_action(input$load_batchcorr_packages,{
    load_batch_correction_packages()
  })
  
  #Load Batch Corr Order
  batch_order <- reactive({
    req(input$batch_corr_order)  #Ensure file is uploaded
    read.csv(input$batch_corr_order$datapath, stringsAsFactors = FALSE)
  })
  
  
  ######5.9.2 Perform Batch Correction######
  # Session action called by the batch_corr button.
  apply_batch_correction <- function() {
    #Load data.
    Rawdata <- peak_areas_data()
    batch_metadata <- batch_order()

    #Perform log10 transform on raw data before correction
    data_BatchCorr <- Rawdata

    #Define which columns are your metabolites
    metCols <- 4:ncol(data_BatchCorr)

    #Apply log10 in place
    data_BatchCorr[ , metCols] <- log10(data_BatchCorr[ , metCols])

    #Create variables necessary for batch correction with initial conditions
    minBatchOccurrence.Ave <- 2
    minBatchOccurrence.Line <- 2
    conditions <- c("")           #Replace missing variables with not available
    experiments <- c(t(outer(c("Q", "S"), conditions, paste, sep = "")))

    methods <- rep("lm", length(experiments))
    methods[grep("c", experiments)] <- "tobit"
    LOD <- as.numeric(as.character(min(data_BatchCorr[ , metCols][!is.na(data_BatchCorr[ , metCols])])))
    imputeValues  <- rep(NA, length(experiments))

    refSamples <- list(
      "Q" = which(batch_metadata$SCode == "ref"),
      "S" = which(batch_metadata$SCode != "ref")
    )
    strategies <- rep(c("Q", "S"), each = length(conditions))

    #Perform batch correction ONLY on numeric metabolite columns
    print("Test 1")
    BatchCorrResults <- lapply(seq(along = experiments), function(ii)
      apply(data_BatchCorr[ , metCols], 2, doBC,
            ref.idx   = refSamples[[ strategies[[ii]] ]],
            batch.idx = batch_metadata$Batch,
            minBsamp  = minBatchOccurrence.Line,
            seq.idx   = batch_metadata$Seq,
            method    = methods[ii],
            imputeVal = imputeValues[ii])
    )
    print("Test 2")

    #Naming list items with the type of correction
    names(BatchCorrResults) <- experiments

    #Anti-log of corrected results
    BatchCorrResultsAntilog <- BatchCorrResults
    BatchCorrResultsAntilog$Q <- 10^(BatchCorrResultsAntilog$Q)
    BatchCorrResultsAntilog$S <- 10^(BatchCorrResultsAntilog$S)

    #Write corrected results to CSV files
    write.csv(BatchCorrResults,        file = "BatchCorrResults.csv")
    write.csv(BatchCorrResultsAntilog, file = "BatchCorrResultsAntilog.csv")
  }

  observe_action(input$batch_corr,{
    apply_batch_correction()
  })
  
  ####6. Reporting####
  #Create reactive variable for storing the Matrix to display it.
  MetaboloMatrix <- reactiveVal(NULL)
  
  # Transpose the sample matrix and assign the configured CLASS labels.
  build_metaboanalyst_matrix <- function(data, category_input) {
    #Remove unnecessary columns, transpose the data, and acquire sampleIDs 
    data <- data[, !names(data) %in% c("peak.number", "file.name")]
    transposed_data <- t(data)
    transposed_df <- as.data.frame(transposed_data)
    sampleIDs <- transposed_df["PBM Sample ID", ]

    #Parse user-specified categories
    user_categories <- strsplit(category_input, ",")[[1]]
    user_categories <- sapply(user_categories, function(x) {
      kv <- strsplit(x, "=")[[1]]
      setNames(trimws(gsub("'", "", kv[2])), trimws(kv[1]))
    }, USE.NAMES = FALSE)

    #Create CLASS row based on dynamic criteria specified by text input. Allows for dynamic categorizers
    class_row <- sapply(1:ncol(transposed_df), function(i) {
      entry <- sampleIDs[i]

      #Check if entry is numeric and if a numeric category is specified
      if ("Numeric" %in% names(user_categories) && suppressWarnings(!is.na(as.numeric(entry)))) {
        return(user_categories[["Numeric"]])
      }

      #Check user-specified categories from text input
      for (pattern in names(user_categories)) {
        if (pattern != "Numeric" && grepl(pattern, entry, ignore.case = TRUE)) {
          return(user_categories[[pattern]])
        }
      }

      #If a class assignment is missing, assign a blank value to it.
      return("")
    })

    #Add class row to transposed data.
    transposed_df <- rbind(class_row, transposed_df)
    rownames(transposed_df)[1] <- "CLASS"

    #fix order so CLASS is second row
    transposed_df <- transposed_df[c("PBM Sample ID", "CLASS", rownames(transposed_df)[!rownames(transposed_df) %in% c("PBM Sample ID", "CLASS")]),]

    transposed_df
  }

  #####6.1 Generating Data Matrix for MetaboAnalyst#####
  observe_action(input$generate_matrix, {

    #Initialize environment
    data <- peak_areas_data()
    if (is.null(data) || nrow(data) == 0) {
      showNotification("No data available to generate matrix", type = "error")
      return(NULL)}
    results_path <- main_folder2()
    
    transposed_df <- build_metaboanalyst_matrix(data, input$category_input)

    #Save Data
    MetaboloMatrix(transposed_df)
    tryCatch({
      write.table(transposed_df, file.path(results_path, "Metaboanalyst_matrix.csv"), row.names = TRUE, col.names = FALSE, sep = ",", fileEncoding = "UTF-8")
      showNotification("Matrix Made", type = "message")
    }, error = function(e) {
      showNotification(paste("Failed to save matrix:", conditionMessage(e)), type = "error")
    })
  })
  
  
  #Render the Matrix 
  output$matrix_table <- renderDataTable({
    datatable(MetaboloMatrix(), options = list(
      scrollX = TRUE,
      scrollY = "400px",
      paging = FALSE
    ))
  })
  
  
  
  ####7. Drug Analysis Tab####
  #for now i think I will start from the adherence data structure -> will build in the adherence code later?
  #7.1 Load data and define reactive values
  
  #Reactive values
  adherence_patient_data <- reactiveVal(NULL)
  drugbank_db <- reactiveVal(NULL)
  twosides_db <- reactiveVal(NULL)
  
  
  #Load adherence data
  observe_action(input$adherence_results,
               {
                req(input$adherence_results)
                 #load data from uploaded file
                 adherence_patient_data(readxl::read_excel(input$adherence_results$datapath))
               })
  

  #Load drug data 
  # Session action called by the drug_databases button.
  load_drug_databases <- function() {
    #Load TWOSIDES database
    twosides_db(parseTWOSIDES("Drug_Data/TWOSIDES.csv.gz"))
    print("Loaded TWOSIDES")

    print("Checking for Drug Databank")

    #Check for .rds DrugBank file
    #If present, load into reactive value
    if (file.exists("Drug_Data/drugbank_db.rds")){
      drugbank_db(readRDS("Drug_Data/drugbank_db.rds"))

      print(".RDS found. Data loaded")
    } else{
      print("Data not found, parse?")
      #Show modal for asking if users want to parse the database
      showModal(modalDialog(
        title = "DrugBank Database Not Found", "Parse now?",
        tags$br(), tags$br(),
        tags$b("Estimated time: 30-40 min."),
        footer = tagList(
          modalButton("No (skip)"),
          actionButton("confirm_parse_drugbank", "Yes, parse now",class = "btn-primary")
        )
      ))
    }
  }

  observe_action(input$drug_databases, {
    load_drug_databases()
  })
  
  # Session action called by the confirm_parse_drugbank button.
  parse_and_save_drugbank <- function() {
    removeModal()

      #Initialize waiter loading screen
      initial_message <- sample(loading_messages, 1)
      waiter_show(
        html = tagList(
          spin_flower(),
          h4(id = "loading-message", initial_message, style = "color:black;")
        ),
        color = "rgba(210,210,210,0.7)"
      )

      #Java script for switching between different loading messages
      js_script <- sprintf("
      setTimeout(function() {
        var messages = %s;
        function updateMessage() {
          var elem = document.getElementById('loading-message');
          if (elem) {
            var newMessage = messages[Math.floor(Math.random() * messages.length)];
            elem.innerText = newMessage;
          }
        }
        setInterval(updateMessage, 4000); // Update every 5 seconds
      }, 2000);
    ", jsonlite::toJSON(loading_messages, auto_unbox = TRUE))
      runjs(js_script)

      #Exclude drugabnk catagories we dont need
      exclude <- c("manufacturers", "prices", "atc_codes", "international_brands",
                   "mixtures", "packagers", "calculated_properties", "pdb_entries","patents","external_links", "atc_codes","sequences","external_identifiers","pdb_entries","ahfs_codes","snp_adverse_reactions", "snp_effects")

      #parse drugbank
      drugbank <- parseDrugBank(
        db_path = "Drug_Data/full database.xml",
        drug_options = setdiff(drug_node_options(), exclude),
        parse_salts = FALSE,
        parse_products = FALSE,
        references_options = NULL,
        cett_options = c("targets", "enzymes", "transporters")
      )

      #Save file
      saveRDS(drugbank, "Drug_Data/drugbank_db.rds")
      drugbank_db(drugbank)

      #hide waiter and confirm
      waiter_hide()
      showNotification("DrugBank loaded and saved successfully!", type = "message")
  }

  observe_action(input$confirm_parse_drugbank,{
    parse_and_save_drugbank()
  })
  
    
}#Closing bracket
  
